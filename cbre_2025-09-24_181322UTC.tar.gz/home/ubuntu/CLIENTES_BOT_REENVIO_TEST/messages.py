# ~/CLIENTES_BOT_REENVIO_TEST/manager/messages.py
MESSAGES = {
    "es": {
        "MSG_WELCOME_GUEST": (
            "👋 **¡Bienvenido(a)!**\n"
            "Aún no estás registrado en el sistema. Para comenzar, contacta a tu reseller o escribe a nuestro soporte en @{support_contact}.\n"
            "¡Estamos aquí para ayudarte!"
        ),
        "MSG_WELCOME_BOSS": (
            "👑 **Panel del Boss**\n\n"
            "🛠 **Comandos disponibles**:\n"
            "• ➕ Crear cliente\n"
            "• 👥 Ver clientes\n"
            "• 💸 Pagos\n"
            "• ⚙️ Configuración"
        ),
        "MSG_WELCOME_RESELLER": (
            "🤝 **Panel de Reseller**\n\n"
            "🛠 **Comandos disponibles**:\n"
            "• ➕ Crear cliente\n"
            "• 👥 Mis clientes\n"
            "• 💸 Pagos\n"
            "• 📊 Estado"
        ),
        "MSG_WELCOME_CLIENT": (
            "👋 **Bienvenido, {username}!**\n\n"
            "📦 **Plan**: {plan}\n"
            "📅 **Vence**: {expires}\n"
            "🔧 **Slug**: `{slug}`\n\n"
            "🛠 **Comandos disponibles**:\n"
            "• ⚙️ Provisionar - Configurar tu bot\n"
            "• 📊 Estado - Ver detalles\n"
            "• ℹ️ Ayuda - Mostrar ayuda"
        ),
        "MSG_EXPIRED": (
            "⏰ **Tu plan ha vencido**\n\n"
            "📅 **Venció**: {expires}\n"
            "🔧 **Slug**: `{slug}`\n\n"
            "📞 **Contacta a soporte** para renovar: @frankosmel"
        ),
        "MSG_ERROR_NO_PERMISSION": (
            "⛔ **No tienes permisos para esta acción**.\n"
            "📞 Contacta a soporte: @frankosmel"
        ),
        "MSG_ERROR_INVALID_ID": (
            "❌ **ID inválido**\n"
            "Por favor, envía un ID numérico válido."
        ),
        "MSG_CLIENT_CREATED": (
            "✅ **Cliente creado exitosamente**\n\n"
            "🔧 **Slug**: `{slug}`\n"
            "📦 **Plan**: {plan}\n"
            "📅 **Vence**: {expires}\n"
            "👤 **Reseller ID**: {rid}\n\n"
            "🔔 El cliente ha sido notificado."
        ),
    },
    "en": {
        # Agregar traducciones si es necesario
    }
}
