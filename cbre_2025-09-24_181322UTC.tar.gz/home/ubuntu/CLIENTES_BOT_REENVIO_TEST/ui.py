# ~/CLIENTES_BOT_REENVIO_TEST/manager/ui.py
from telethon import Button
from .messages import MESSAGES

def kb_boss():
    return [
        [Button.text("➕ Crear cliente"), Button.text("👥 Ver clientes")],
        [Button.text("💸 Pagos"), Button.text("⚙️ Configuración")]
    ]

def kb_reseller():
    return [
        [Button.text("➕ Crear cliente"), Button.text("👥 Mis clientes")],
        [Button.text("💸 Pagos"), Button.text("📊 Estado")]
    ]

def kb_client():
    return [
        [Button.text("⚙️ Provisionar"), Button.text("📊 Estado")],
        [Button.text("ℹ️ Ayuda")]
    ]

def inline_client_plans():
    return [
        [Button.inline("🎁 Trial", b"plan:plan_trial")],
        [Button.inline("📦 Estándar", b"plan:plan_estandar"), Button.inline("⭐ Plus", b"plan:plan_plus")],
        [Button.inline("👑 Pro", b"plan:plan_pro")],
        [Button.inline("❌ Cancelar", b"plan:cancel")]
    ]

def inline_client_terms(prices):
    btns = [
        [Button.inline("📅 30 días", b"pay:c:30")],
        [Button.inline("📅 90 días", b"pay:c:90"), Button.inline("📅 365 días", b"pay:c:365")],
        [Button.inline("❌ Cancelar", b"pay:c:cancel")]
    ]
    txt = "⏰ **Selecciona la duración del plan:**\n\n"
    for k, v in prices.items():
        txt += f"🏷 **{k.replace('plan_', '').title()}**:\n"
        for term, price in v.items():
            txt += f"  • {term} días: ${price:.2f}\n"
    return txt, btns

def add_provision_messages():
    MESSAGES["es"].update({
        "MSG_NEW_CLIENT_BOSS": (
            "🆕 **Crear Cliente como Boss**\n"
            "Envía el **ID numérico** del cliente final:"
        ),
        "MSG_SELECT_PLAN": (
            "🏷 **Selecciona el plan para el cliente:**"
        ),
        "MSG_PROVISION_TOKEN": (
            "🚀 **Configurando tu bot**\n\n"
            "📦 **Plan**: {plan}\n"
            "🔧 **Slug**: `{slug}`\n"
            "📅 **Vence**: {expires}\n\n"
            "🤖 **Paso 1/2**: Pega tu **BOT_TOKEN** (obténlo desde @BotFather):\n"
            "Formato: `123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11`"
        ),
        "MSG_INVALID_TOKEN": (
            "❌ **BOT_TOKEN inválido**\n"
            "El formato debe ser: `123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11`\n"
            "Obtén tu token desde @BotFather e inténtalo de nuevo."
        ),
        "MSG_PROVISION_CLONING": (
            "⏳ **Paso 1/4**: Clonando plantilla..."
        ),
        "MSG_PROVISION_ENV": (
            "⏳ **Paso 2/4**: Configurando variables de entorno..."
        ),
        "MSG_PROVISION_DEPENDENCIES": (
            "⏳ **Paso 3/4**: Instalando dependencias..."
        ),
        "MSG_PROVISION_SERVICE": (
            "⏳ **Paso 4/4**: Activando servicio..."
        ),
        "MSG_PROVISION_SUCCESS": (
            "✅ **¡Instancia creada exitosamente!**\n\n"
            "🤖 **Tu bot**: {bot_info}\n"
            "📁 **Directorio**: `{workdir}`\n"
            "🛎️ **Servicio**: `reenvio-test@{slug}.service`\n"
            "🟢 **Estado**: Activo\n\n"
            "📋 **Comandos útiles**:\n"
            "• /status - Ver estado detallado\n"
            "• /provision - Reinstalar si es necesario\n\n"
            "❓ **Soporte**: @frankosmel"
        ),
        "MSG_PROVISION_ERROR": (
            "❌ **Error en la provisión**\n"
            "Detalles: `{error}`\n"
            "Contacta a @frankosmel para soporte."
        ),
    })

add_provision_messages()
