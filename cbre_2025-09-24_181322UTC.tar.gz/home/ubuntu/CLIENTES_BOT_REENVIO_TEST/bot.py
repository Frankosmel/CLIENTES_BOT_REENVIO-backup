# ~/CLIENTES_BOT_REENVIO_TEST/manager/bot.py
import asyncio
import datetime as dt
import re
import shutil
import subprocess
from pathlib import Path
from telethon import TelegramClient, events, Button
from .config import SET
from .models_db import (
    init_db, cx, get_setting, set_setting, role_for, limits, prices,
    prorate, ensure_client_workdir, slugify, new_id, iso_now
)
from .ui import (
    kb_boss, kb_reseller, kb_client,
    inline_client_plans, inline_client_terms
)
from .messages import MESSAGES
import logging

# Configuración de logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filename=str(SET.data_dir / "logs" / "bot.log")
)
logger = logging.getLogger(__name__)

# Directorios base
ROOT = SET.data_dir
TEMPL_DIR = ROOT / "TEMPLATES"
CLIENTS_DIR = ROOT / "clients"
CLIENTS_DIR.mkdir(parents=True, exist_ok=True)

# Mapa de planes a plantillas
TEMPL = {
    "plan_estandar": TEMPL_DIR / "plan_estandar",
    "plan_plus": TEMPL_DIR / "plan_plus",
    "plan_pro": TEMPL_DIR / "plan_pro",
    "plan_trial": TEMPL_DIR / "plan_estandar"
}

# Estado de flujos de conversación
flows = {}

# Cliente de Telegram
bot = TelegramClient("reseller_mgr_test", SET.api_id, SET.api_hash)

def get_message(key: str, lang: str = None, **kwargs) -> str:
    lang = lang or get_setting("language", "es")
    msg = MESSAGES.get(lang, MESSAGES["es"]).get(key, "Mensaje no encontrado")
    return msg.format(**kwargs)

async def reply(ev, key: str, buttons=None, parse_mode: str = "markdown", **kwargs) -> None:
    try:
        message = get_message(key, **kwargs)
        await ev.reply(message, buttons=buttons or Button.clear(), parse_mode=parse_mode)
        logger.info(f"Mensaje enviado a {ev.sender_id}: {message[:50]}...")
    except Exception as e:
        logger.error(f"Error al enviar mensaje a {ev.sender_id}: {e}")

def run(cmd: str) -> str:
    try:
        p = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        return p.stdout
    except subprocess.CalledProcessError as e:
        logger.error(f"Error ejecutando comando: {cmd}\nSTDOUT: {e.stdout}\nSTDERR: {e.stderr}")
        raise RuntimeError(f"RC={e.returncode} CMD={cmd}\nSTDOUT:\n{e.stdout}\nSTDERR:\n{e.stderr}")

def validate_bot_token(token: str) -> bool:
    pattern = r"^\d+:[A-Za-z0-9_-]{35}$"
    return bool(re.match(pattern, token.strip()))

def clone_template(plan: str, workdir: Path):
    if plan not in TEMPL:
        raise RuntimeError(f"❌ Plan inválido: {plan}")
    if workdir.exists():
        shutil.rmtree(workdir)
    shutil.copytree(TEMPL[plan], workdir)
    logger.info(f"Plantilla {plan} clonada en {workdir}")

def write_env(workdir: Path, bot_token: str, owner_id: int, slug: str, tz: str = "UTC"):
    env_content = f"""API_ID={SET.api_id}
API_HASH={SET.api_hash}
BOT_TOKEN={bot_token}
OWNER_ID={owner_id}
USER_SESSION={slug}_user
BOT_SESSION={slug}panel
STATE_FILE=state{slug}.json
TIMEZONE={tz}
QUIET_START=00:30
QUIET_END=07:00
"""
    (workdir / ".env").write_text(env_content)
    logger.info(f"Archivo .env escrito en {workdir}")

def manage_service(slug: str, action: str):
    svc = f"reenvio-test@{slug}.service"
    if action in ("enable", "start"):
        run("sudo -n /usr/bin/systemctl daemon-reload")
        run(f"sudo -n /usr/bin/systemctl enable --now '{svc}'")
    elif action == "stop":
        run(f"sudo -n /usr/bin/systemctl stop '{svc}' || true")
    elif action == "disable":
        run(f"sudo -n /usr/bin/systemctl disable --now '{svc}' || true")
    logger.info(f"Servicio {svc} {action} ejecutado")

def _get_bot_meta(token: str) -> dict:
    try:
        import requests
        r = requests.get(f"https://api.telegram.org/bot{token}/getMe", timeout=6)
        j = r.json()
        if j.get("ok"):
            res = j.get("result", {})
            return {"ok": True, "username": res.get("username"), "id": res.get("id")}
        return {"ok": False, "username": None, "id": None}
    except Exception as e:
        logger.error(f"Error obteniendo metadatos del bot: {e}")
        return {"ok": False, "username": None, "id": None}

@bot.on(events.NewMessage(pattern=r"^/start$"))
async def start(ev):
    init_db()
    user_id = ev.sender_id
    role = role_for(user_id)
    logger.info(f"Comando /start ejecutado por {user_id} (rol: {role})")

    if role == "guest":
        await reply(ev, "MSG_WELCOME_GUEST", support_contact=get_setting("support_contact", "frankosmel"))
    elif role == "boss":
        await reply(ev, "MSG_WELCOME_BOSS", kb_boss())
    elif role == "reseller":
        await reply(ev, "MSG_WELCOME_RESELLER", kb_reseller())
    elif role == "client":
        with cx() as c:
            cur = c.cursor()
            cur.execute("SELECT slug, plan, expires, username FROM clients WHERE owner_id=?", (user_id,))
            row = cur.fetchone()
        if row:
            await reply(ev, "MSG_WELCOME_CLIENT", kb_client(),
                        username=row["username"] or f"Usuario {user_id}",
                        plan=row["plan"], expires=row["expires"], slug=row["slug"])
        else:
            await reply(ev, "MSG_ERROR_NO_PERMISSION", kb_client())

@bot.on(events.NewMessage(pattern=r"^➕ Crear cliente$"))
async def boss_create_client(ev):
    if role_for(ev.sender_id) != "boss":
        await reply(ev, "MSG_ERROR_NO_PERMISSION")
        return
    flows[ev.sender_id] = {"mode": "newcli_boss", "step": "client_id", "rid": str(ev.sender_id)}
    await reply(ev, "MSG_NEW_CLIENT_BOSS", kb_boss())
    logger.info(f"Boss {ev.sender_id} inició creación de cliente")

@bot.on(events.NewMessage(pattern=r"^⚙️ Provisionar$"))
async def cli_provision(ev):
    if role_for(ev.sender_id) != "client":
        await reply(ev, "MSG_ERROR_NO_PERMISSION")
        return
    with cx() as c:
        cur = c.cursor()
        cur.execute("SELECT slug, plan, expires FROM clients WHERE owner_id=?", (ev.sender_id,))
        row = cur.fetchone()
    if not row:
        await reply(ev, "MSG_ERROR_NO_PERMISSION", kb_client())
        return
    if row["expires"] and row["expires"] < dt.date.today().isoformat():
        await reply(ev, "MSG_EXPIRED", kb_client(), slug=row["slug"], expires=row["expires"])
        return

    flows[ev.sender_id] = {
        "mode": "provision",
        "slug": row["slug"],
        "plan": row["plan"],
        "step": "token"
    }
    await reply(ev, "MSG_PROVISION_TOKEN", kb_client(),
                slug=row["slug"], plan=row["plan"], expires=row["expires"])
    logger.info(f"Cliente {ev.sender_id} inició flujo de provisión")

@bot.on(events.NewMessage)
async def flows_input(ev):
    user_id = ev.sender_id
    if user_id not in flows:
        return
    f = flows[user_id]

    if f.get("mode") == "newcli_boss" and f.get("step") == "client_id":
        try:
            cid = int((ev.raw_text or "").strip())
        except ValueError:
            await reply(ev, "MSG_ERROR_INVALID_ID", kb_boss())
            return
        with cx() as c:
            cur = c.cursor()
            slug = slugify(str(cid))
            base = slug
            i = 2
            while True:
                cur.execute("SELECT 1 FROM clients WHERE slug=?", (slug,))
                if not cur.fetchone():
                    break
                slug = f"{base}{i}"
                i += 1
            wdir = ensure_client_workdir(slug)
        f.update({"client_id": cid, "slug": slug, "workdir": str(wdir), "step": "plan_select"})
        await reply(ev, "MSG_SELECT_PLAN", buttons=inline_client_plans())
        logger.info(f"Boss {user_id} proporcionó ID de cliente: {cid}, slug={slug}")
        return

    if f.get("mode") == "provision" and f.get("step") == "token":
        token = (ev.raw_text or "").strip()
        if not validate_bot_token(token):
            await reply(ev, "MSG_INVALID_TOKEN", kb_client())
            return
        slug = f["slug"]
        plan = f["plan"]
        workdir = Path(CLIENTS_DIR / slug)
        try:
            await reply(ev, "MSG_PROVISION_CLONING", kb_client())
            clone_template(plan, workdir)

            await reply(ev, "MSG_PROVISION_ENV", kb_client())
            write_env(workdir, bot_token=token, owner_id=user_id, slug=slug)

            await reply(ev, "MSG_PROVISION_DEPENDENCIES", kb_client())
            run(f"python3 -m venv '{workdir / 'venv'}'")
            run(f"'{workdir / 'venv/bin/pip'}' install --upgrade pip")
            run(f"'{workdir / 'venv/bin/pip'}' install telethon==1.36.0 python-dotenv==1.0.1")

            await reply(ev, "MSG_PROVISION_SERVICE", kb_client())
            manage_service(slug, "enable")

            bot_meta = _get_bot_meta(token)
            bot_info = f"@{bot_meta.get('username', 'Error verificando')}" if bot_meta.get("ok") else "⚠️ Token inválido"
            await reply(ev, "MSG_PROVISION_SUCCESS", kb_client(),
                        slug=slug, bot_info=bot_info, workdir=str(workdir))
            logger.info(f"Provisión completada para cliente {user_id}: slug={slug}")
        except Exception as e:
            await reply(ev, "MSG_PROVISION_ERROR", kb_client(), error=str(e)[:100])
            logger.error(f"Error en provisión para {user_id}: {e}")
        finally:
            flows.pop(user_id, None)
        return

@bot.on(events.CallbackQuery)
async def cb(ev):
    user_id = ev.sender_id
    role = role_for(user_id)
    data = (ev.data or b"").decode()
    logger.debug(f"Callback recibido de {user_id}: {data}")

    if user_id not in flows:
        return

    f = flows[user_id]

    if data in ("plan:plan_trial", "plan:plan_estandar", "plan:plan_plus", "plan:plan_pro") and f.get("mode") == "newcli_boss" and f.get("step") == "plan_select":
        plan_code = data.split(":")[1]
        f.update({"plan_code": plan_code, "step": "duration_select"})
        with cx() as c:
            cur = c.cursor()
            pr = prices(cur)
        txt, btn = inline_client_terms(pr)
        await ev.edit(txt, buttons=btn)
        logger.info(f"Plan seleccionado por boss {user_id}: {plan_code}")
        return

    if data in ("pay:c:30", "pay:c:90", "pay:c:365") and f.get("mode") == "newcli_boss" and f.get("step") == "duration_select":
        term = data.split(":")[2]
        days = {"30": 30, "90": 90, "365": 365}[term]
        expires = (dt.date.today() + dt.timedelta(days=days)).isoformat()
        with cx() as c:
            cur = c.cursor()
            cur.execute(
                """INSERT INTO clients(slug, owner_id, username, reseller_id, plan, expires, created, workdir, svc_status)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (f["slug"], f["client_id"], None, f["rid"], f["plan_code"], expires, iso_now(), f["workdir"], "stopped")
            )
            c.commit()
        await ev.edit(get_message("MSG_CLIENT_CREATED", slug=f["slug"], rid=f["rid"], plan=f["plan_code"], expires=expires))
        logger.info(f"Cliente creado por boss {user_id}: slug={f['slug']}, plan={f['plan_code']}")
        try:
            await bot.send_message(
                f["client_id"],
                get_message("MSG_WELCOME_CLIENT", username="Cliente", plan=f["plan_code"], expires=expires, slug=f["slug"])
            )
        except Exception:
            logger.warning(f"No se pudo notificar al cliente {f['client_id']}")
        flows.pop(user_id, None)
        return

async def expiry_loop():
    while True:
        try:
            with cx() as c:
                cur = c.cursor()
                cur.execute("SELECT slug, owner_id, expires FROM clients WHERE expires <= ?", ((dt.date.today() + dt.timedelta(days=1)).isoformat(),))
                for row in cur.fetchall():
                    if row["expires"] <= dt.date.today().isoformat():
                        manage_service(row["slug"], "stop")
                        await bot.send_message(row["owner_id"], get_message("MSG_EXPIRED", slug=row["slug"], expires=row["expires"]))
                        logger.info(f"Servicio pausado para {row['slug']} por vencimiento")
            await asyncio.sleep(3600)  # Revisar cada hora
        except Exception as e:
            logger.error(f"Error en expiry_loop: {e}")
            await asyncio.sleep(300)

async def main():
    init_db()
    await bot.start(bot_token=SET.bot_token)
    logger.info("✅ Bot de prueba iniciado correctamente.")
    print("✅ Bot de prueba iniciado correctamente.")
    asyncio.create_task(expiry_loop())
    await bot.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())
