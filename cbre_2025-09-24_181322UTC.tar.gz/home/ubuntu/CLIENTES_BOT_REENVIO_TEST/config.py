# ~/CLIENTES_BOT_REENVIO_TEST/manager/config.py
from pathlib import Path
from dotenv import load_dotenv
import os

load_dotenv(Path.home() / "CLIENTES_BOT_REENVIO_TEST/manager/.env")

class SET:
    data_dir = Path.home() / "CLIENTES_BOT_REENVIO_TEST"
    api_id = int(os.getenv("API_ID", "0"))
    api_hash = os.getenv("API_HASH", "")
    bot_token = os.getenv("MANAGER_BOT_TOKEN", "")
