# ~/CLIENTES_BOT_REENVIO_TEST/manager/models_db.py
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from .config import SET
import datetime as dt
import re

DBPATH = SET.data_dir / "db.sqlite3"

@contextmanager
def cx():
    conn = sqlite3.connect(DBPATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()

def init_db():
    with cx() as c:
        cur = c.cursor()
        cur.executescript("""
            CREATE TABLE IF NOT EXISTS resellers(
                reseller_id INTEGER PRIMARY KEY,
                username TEXT,
                plan TEXT NOT NULL DEFAULT 'basic',
                created TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS clients(
                slug TEXT PRIMARY KEY,
                owner_id INTEGER NOT NULL,
                username TEXT,
                reseller_id INTEGER,
                plan TEXT NOT NULL,
                expires TEXT,
                created TEXT NOT NULL,
                workdir TEXT NOT NULL,
                svc_status TEXT NOT NULL DEFAULT 'stopped'
            );
            CREATE TABLE IF NOT EXISTS payments(
                pay_id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id INTEGER NOT NULL,
                reseller_id INTEGER,
                plan TEXT NOT NULL,
                term INTEGER NOT NULL,
                amount REAL NOT NULL,
                created TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS settings(
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
        """)
        c.commit()

def role_for(user_id: int) -> str:
    with cx() as c:
        cur = c.cursor()
        cur.execute("SELECT value FROM settings WHERE key='owner_id'")
        owner_id = cur.fetchone()
        if owner_id and int(owner_id["value"]) == user_id:
            return "boss"
        cur.execute("SELECT 1 FROM resellers WHERE reseller_id=?", (user_id,))
        if cur.fetchone():
            return "reseller"
        cur.execute("SELECT 1 FROM clients WHERE owner_id=?", (user_id,))
        if cur.fetchone():
            return "client"
        return "guest"

def limits() -> dict:
    return {
        "basic": {"clients": 10, "plans": ["plan_trial", "plan_estandar"]},
        "premium": {"clients": 50, "plans": ["plan_trial", "plan_estandar", "plan_plus", "plan_pro"]}
    }

def prices(cur) -> dict:
    return {
        "plan_trial": {"30": 0.0},
        "plan_estandar": {"30": 10.0, "90": 25.0, "365": 90.0},
        "plan_plus": {"30": 20.0, "90": 50.0, "365": 180.0},
        "plan_pro": {"30": 30.0, "90": 75.0, "365": 270.0}
    }

def prorate(days: int, plan: str, cur) -> float:
    pr = prices(cur)
    return pr[plan].get(str(days), 0.0)

def ensure_client_workdir(slug: str) -> Path:
    wdir = SET.data_dir / "clients" / slug
    wdir.mkdir(parents=True, exist_ok=True)
    return wdir

def slugify(txt: str) -> str:
    t = txt.strip().lstrip("@")
    t = re.sub(r"[^a-zA-Z0-9_]+", "", t)[:32] or "tenant"
    return t

def new_id() -> str:
    return str(dt.datetime.now().timestamp()).replace(".", "")

def iso_now() -> str:
    return dt.datetime.now().isoformat()
