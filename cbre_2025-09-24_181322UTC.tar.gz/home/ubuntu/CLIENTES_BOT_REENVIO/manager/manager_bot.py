SYSTEMCTL="/usr/bin/systemctl"
import os, json, asyncio, shutil, subprocess, datetime as dt, re
from pathlib import Path
from typing import Dict, Any, Optional
import logging
from telethon import TelegramClient, events, Button
from dotenv import load_dotenv

# ======= Configuración de logging =======
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ======= Rutas base =======
ROOT = Path.home() / "CLIENTES_BOT_REENVIO"
MANAGER_DIR = ROOT / "manager"
TEMPL_DIR = ROOT / "TEMPLATES"
STATEF = MANAGER_DIR / "state.json"
CLIENTS_DIR = ROOT / "clients"
CLIENTS_DIR.mkdir(parents=True, exist_ok=True)

# Mapas de planes a carpeta plantilla (agregamos plan trial)
TEMPL = {
    "default": TEMPL_DIR / "default",
    "plan_estandar": TEMPL_DIR / "plan_estandar",
    "plan_plus": TEMPL_DIR / "plan_plus", 
    "plan_pro": TEMPL_DIR / "plan_pro",
    "plan_trial": TEMPL_DIR / "plan_estandar"  # Trial usa template estándar
}

# ======= Config Manager .env =======
load_dotenv(MANAGER_DIR / ".env")
API_ID = int(os.getenv("API_ID", "0"))
API_HASH = os.getenv("API_HASH", "")
BOT_TOKEN = os.getenv("MANAGER_BOT_TOKEN", "")

# ======= State =======
def load_state() -> Dict[str, Any]:
    MANAGER_DIR.mkdir(parents=True, exist_ok=True)
    if not STATEF.exists():
        STATEF.write_text(json.dumps({
            "owner_id": 0, 
            "admins": [], 
            "clients": {},
            "last_expiry_check": None
        }, indent=2))
    return json.loads(STATEF.read_text())

def save_state(S: Dict[str, Any]):
    STATEF.write_text(json.dumps(S, indent=2, ensure_ascii=False))

S = load_state()

# ======= Helpers =======
def is_admin(uid: int) -> bool:
    return uid == S.get("owner_id", 0) or uid in S.get("admins", [])

def run(cmd: str):
    import subprocess
    p = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode != 0:
        raise RuntimeError(f"RC={p.returncode} CMD={cmd}\nSTDOUT:\n{p.stdout}\nSTDERR:\n{p.stderr}")
    return p.stdout
    subprocess.run(cmd, shell=True, check=True)

def slugify_from_user(entity) -> str:
    if getattr(entity, "username", None):
        return re.sub(r"[^a-zA-Z0-9_]+", "", entity.username)[:32] or f"tenant{entity.id}"
    return f"tenant{entity.id}"

def slugify_text(txt: str) -> str:
    t = txt.strip()
    if t.startswith("@"): 
        t = t[1:]
    return re.sub(r"[^a-zA-Z0-9_]+", "", t)[:32] or "tenant"

def fmt_date(d: dt.date) -> str:
    return d.isoformat()

def parse_days(btag: bytes) -> Optional[int]:
    if btag and btag.startswith(b"dur:"):
        val = btag.split(b":", 1)[1]
        if val == b"cancel": 
            return None
        try:
            return int(val.decode())
        except:
            return None
    return None

def kb_clients(prefix: str):
    rows, row = [], []
    for slug in sorted(S["clients"].keys()):
        row.append(Button.inline(f"👤 {slug}", f"{prefix}:{slug}".encode()))
        if len(row) == 2:
            rows.append(row)
            row = []
    if row: 
        rows.append(row)
    rows.append([Button.inline("❌ Cancelar", f"{prefix}:cancel".encode())])
    return rows

def clone_template(plan: str, workdir: Path):
    if plan not in TEMPL:
        raise RuntimeError(f"❌ Plan inválido: {plan}")
    if workdir.exists():
        shutil.rmtree(workdir)
    shutil.copytree(TEMPL[plan], workdir)

def ensure_venv_and_requirements(workdir: Path):
    venv = workdir / "venv"
    if not venv.exists():
        run(f"python3 -m venv '{venv}'")
        run(f"'{venv}/bin/pip' install --upgrade pip")
    req = workdir / "requirements.txt"
    if req.exists():
        run(f"'{venv}/bin/pip' install -r '{req}'")
    else:
        run(f"'{venv}/bin/pip' install telethon==1.36.0 python-dotenv==1.0.1")

def write_env(workdir: Path, *, bot_token: str, owner_id: int, slug: str,
              tz: str = "UTC", qstart: str = "00:30", qend: str = "07:00"):
    # Intenta arrastrar API_ID/API_HASH desde la plantilla si existen .env
    apid, apih = API_ID, API_HASH
    tpl_env = workdir / ".env"
    if tpl_env.exists():
        try:
            from dotenv import dotenv_values
            vals = dotenv_values(tpl_env)
            apid = int(vals.get("API_ID", apid) or apid)
            apih = vals.get("API_HASH", apih) or apih
        except:
            pass

    ENV = f"""API_ID={apid}
API_HASH={apih}
BOT_TOKEN={bot_token}
OWNER_ID={owner_id}
USER_SESSION={slug}_user
BOT_SESSION={slug}panel
STATE_FILE=state{slug}.json
TIMEZONE={tz}
QUIET_START={qstart}
QUIET_END={qend}
"""
    (workdir / ".env").write_text(ENV)

def force_load_dotenv_override(workdir: Path):
    py = workdir / "telethon_userbot_listas_publicaciones.py"
    if not py.exists(): 
        return
    txt = py.read_text()
    if "load_dotenv(" in txt and "override=True" in txt:
        return
    # Inserta carga .env al inicio si no existe
    if "load_dotenv" not in txt:
        txt = (
            "from pathlib import Path as _P\n"
            "from dotenv import load_dotenv\n"
            "load_dotenv(dotenv_path=_P(__file__).with_name('.env'), override=True)\n"
        ) + txt
    else:
        # fuerza override=True si ya invocan load_dotenv
        txt = re.sub(r"load_dotenv\((.*?)\)", r"load_dotenv(\1, override=True)", txt, count=1, flags=re.S)
    py.write_text(txt)

def enable_instance_service(slug: str):
    """🟢 Habilita y arranca el servicio"""
    run("sudo -n /usr/bin/systemctl daemon-reload")
    run(f"sudo -n /usr/bin/systemctl enable --now 'reenvio@{slug}.service'")

def disable_instance_service(slug: str):
    """🔴 Deshabilita y detiene el servicio"""
    run(f"sudo -n /usr/bin/systemctl disable --now 'reenvio@{slug}.service' || true")

def pause_instance_service(slug: str):
    """⏸️ Pausa el servicio (solo lo detiene, mantiene habilitado)"""
    run(f"sudo -n /usr/bin/systemctl stop 'reenvio@{slug}.service' || true")

def resume_instance_service(slug: str):
    """▶️ Resume el servicio pausado"""
    run(f"sudo -n /usr/bin/systemctl start 'reenvio@{slug}.service' || true")

def _svc_status(svc: str) -> str:
    """Obtiene estado del servicio systemd"""
    try:
        out = subprocess.run(
            ["systemctl", "is-active", svc],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, check=False
        ).stdout.strip()
        return "active" if out == "active" else out or "unknown"
    except Exception:
        return "unknown"

def _get_bot_meta(token: str) -> dict:
    """Obtiene info del bot usando Bot API getMe"""
    try:
        import requests
        r = requests.get(f"https://api.telegram.org/bot{token}/getMe", timeout=6)
        j = r.json()
        if j.get("ok"):
            res = j.get("result", {})
            return {"ok": True, "username": res.get("username"), "id": res.get("id")}
        return {"ok": False, "username": None, "id": None}
    except Exception:
        return {"ok": False, "username": None, "id": None}

def _read_env(workdir: Path) -> dict:
    """Lee variables del archivo .env"""
    envp = workdir / ".env"
    out = {}
    if not envp.exists():
        return out
    for line in envp.read_text().splitlines():
        if "=" in line and not line.strip().startswith("#"):
            k, v = line.split("=", 1)
            out[k.strip()] = v.strip()
    return out

def uniq_slug(base: str) -> str:
    """Genera slug único basado en username"""
    base = base.strip().lstrip("@")
    base = re.sub(r"[^a-zA-Z0-9]+", "", base) or "cliente"
    slug = base
    n = 2
    while slug in S.get("clients", {}):
        slug = f"{base}{n}"
        n += 1
    return slug

# ======= Flujos =======
flows: Dict[int, Dict[str, Any]] = {}

# ======= Bot Manager =======
bot = TelegramClient("manager_bot", API_ID, API_HASH)

# ======= Sistema de notificaciones de expiración =======
async def check_expiring_plans():
    """🔔 Revisa planes que vencen mañana y envía notificaciones"""
    try:
        current_state = load_state()
        tomorrow = (dt.date.today() + dt.timedelta(days=1)).isoformat()
        today = dt.date.today().isoformat()
        
        for slug, client_info in current_state.get("clients", {}).items():
            expires_at = client_info.get("expires_at")
            owner_id = client_info.get("owner_id")
            
            if not expires_at or not owner_id:
                continue
                
            # Notifica 1 día antes del vencimiento
            if expires_at == tomorrow:
                await send_expiry_notification(slug, client_info, "warning")
            # Pausa servicio si ya venció
            elif expires_at <= today:
                await handle_expired_service(slug, client_info)
        
        # Actualizar timestamp del último chequeo
        current_state["last_expiry_check"] = dt.datetime.now().isoformat()
        save_state(current_state)
        
    except Exception as e:
        logger.error(f"Error en check_expiring_plans: {e}")

async def send_expiry_notification(slug: str, client_info: dict, notification_type: str):
    """📧 Envía notificación de expiración al cliente"""
    try:
        owner_id = client_info.get("owner_id")
        expires_at = client_info.get("expires_at")
        plan = client_info.get("plan", "plan_estandar")
        workdir = Path(client_info.get("workdir", ""))
        
        # Obtener info del bot si existe
        env = _read_env(workdir)
        token = env.get("BOT_TOKEN", "")
        bot_meta = {"username": None, "id": None}
        
        if token:
            try:
                import requests
                bot_meta = _get_bot_meta(token)
            except:
                pass
        
        # Estado del servicio
        svc = f"reenvio@{slug}.service"
        status = _svc_status(svc)
        status_emoji = "🟢" if status == "active" else "🔴"
        
        if notification_type == "warning":
            message = (
                f"⚠️ **AVISO DE VENCIMIENTO** ⚠️\n\n"
                f"🎫 **Plan:** {plan}\n"
                f"📅 **Vence mañana:** {expires_at}\n"
                f"{status_emoji} **Servicio:** {status}\n"
                f"🤖 **Tu bot:** @{bot_meta.get('username', 'N/A')}\n\n"
                f"📞 **Para renovar tu plan, contacta:**\n"
                f"👨‍💻 @frankosmel\n\n"
                f"ℹ️ Si no renuevas, tu servicio se pausará automáticamente."
            )
            
            keyboard = [
                [Button.url("💬 Contactar @frankosmel", "https://t.me/frankosmel")],
                [Button.inline("📊 Ver estado", f"status:{slug}".encode())]
            ]
        else:  # expired
            message = (
                f"🔴 **SERVICIO PAUSADO** 🔴\n\n"
                f"🎫 **Plan:** {plan}\n"
                f"📅 **Venció:** {expires_at}\n"
                f"⏸️ **Estado:** Servicio pausado\n"
                f"🤖 **Bot afectado:** @{bot_meta.get('username', 'N/A')}\n\n"
                f"📞 **Para reactivar, contacta:**\n"
                f"👨‍💻 @frankosmel"
            )
            
            keyboard = [
                [Button.url("💬 Contactar @frankosmel para renovar", "https://t.me/frankosmel")]
            ]
        
        await bot.send_message(owner_id, message, buttons=keyboard)
        logger.info(f"Notificación de {notification_type} enviada a {owner_id} para {slug}")
        
    except Exception as e:
        logger.error(f"Error enviando notificación a {owner_id}: {e}")

async def handle_expired_service(slug: str, client_info: dict):
    """⏸️ Maneja servicios que ya vencieron"""
    try:
        # Solo pausa si el servicio está activo
        svc = f"reenvio@{slug}.service"
        status = _svc_status(svc)
        
        if status == "active":
            pause_instance_service(slug)
            logger.info(f"Servicio {svc} pausado por expiración")
            
            # Enviar notificación de servicio pausado
            await send_expiry_notification(slug, client_info, "expired")
            
    except Exception as e:
        logger.error(f"Error pausando servicio {slug}: {e}")

# ======= Task de background para chequeo de expiraciones =======
async def expiry_checker_task():
    """🔄 Task en background que revisa expiraciones cada hora"""
    while True:
        try:
            await asyncio.sleep(3600)  # Revisa cada hora
            await check_expiring_plans()
        except Exception as e:
            logger.error(f"Error en expiry_checker_task: {e}")
            await asyncio.sleep(300)  # Espera 5 minutos antes de reintentar

# ======= Comandos comunes =======
@bot.on(events.NewMessage(pattern=r'^/start$'))
async def start_cmd(ev):
    uid = ev.sender_id
    if is_admin(uid):
        await ev.reply(
            "🤖 **Bot Manager** - Panel de Administración\n\n"
            "🛠️ **Comandos de Admin:**\n"
            "• `/set_owner <id>` - Establecer propietario\n"
            "• `/admins` - Listar administradores\n"
            "• `/admin_add <id>` - Agregar admin\n"
            "• `/admin_rm <id>` - Remover admin\n"
            "• `/clients` - Ver todos los clientes\n"
            "• `/client <slug>` - Info detallada de cliente\n"
            "• `/auth` - Autorizar nuevo cliente\n"
            "• `/renew` - Renovar plan de cliente\n"
            "• `/edit_plan` - Cambiar plan de cliente\n"
            "• `/revoke` - Revocar acceso de cliente\n"
            "• `/upgrade <slug>` - Actualizar cliente específico\n"
            "• `/upgrade_all` - Actualizar todos los clientes\n\n"
            "🎯 **Panel listo para gestionar servicios**"
        )
    else:
        # Cliente - verificar autorización
        my = None
        for slug, c in S["clients"].items():
            if c.get("owner_id") == uid:
                my = (slug, c)
                break
        
        if my:
            slug, c = my
            exp = c.get("expires_at", "N/A")
            plan = c.get("plan", "N/A")
            svc = f"reenvio@{slug}.service"
            status = _svc_status(svc)
            status_emoji = "🟢" if status == "active" else "🔴"
            
            await ev.reply(
                f"👋 **Bienvenido de vuelta!**\n\n"
                f"🎫 **Tu Plan:** {plan}\n"
                f"📅 **Vence:** {exp}\n"
                f"{status_emoji} **Estado del servicio:** {status}\n"
                f"🔧 **Identificador:** {slug}\n\n"
                "📋 **Comandos disponibles:**\n"
                "• `/provision` - Crear/reinstalar tu bot\n"
                "• `/status` - Ver estado detallado\n\n"
                "❓ **¿Necesitas ayuda?** Contacta a @frankosmel"
            )
        else:
            await ev.reply(
                "👋 **¡Hola!** Aún no estás autorizado.\n\n"
                "📝 Para obtener acceso al servicio, contacta a un administrador.\n"
                "💬 Puedes escribir a: @frankosmel\n\n"
                "🎁 **¡Pregunta por nuestro plan trial de 7 días!**"
            )

# ======= Admin management =======
@bot.on(events.NewMessage(pattern=r'^/set_owner\s+(\d+)$'))
async def set_owner(ev):
    if S.get("owner_id", 0) not in (0, ev.sender_id): 
        return
    S["owner_id"] = int(ev.pattern_match.group(1))
    save_state(S)
    await ev.reply(f"👑 **Owner establecido:** `{S['owner_id']}`")

@bot.on(events.NewMessage(pattern=r'^/admins$'))
async def admins_list(ev):
    if not is_admin(ev.sender_id): 
        return
    arr = S.get("admins", [])
    owner = S.get("owner_id", 0)
    
    msg = f"👑 **Owner:** `{owner}`\n\n👮 **Administradores:**\n"
    if arr:
        for admin_id in arr:
            msg += f"• `{admin_id}`\n"
    else:
        msg += "_(No hay administradores configurados)_"
    
    await ev.reply(msg)

@bot.on(events.NewMessage(pattern=r'^/admin_add\s+(\d+)$'))
async def admin_add(ev):
    if not is_admin(ev.sender_id): 
        return
    aid = int(ev.pattern_match.group(1))
    A = S.setdefault("admins", [])
    if aid not in A: 
        A.append(aid)
        save_state(S)
        await ev.reply(f"✅ **Admin agregado:** `{aid}`")
    else:
        await ev.reply(f"⚠️ `{aid}` ya es administrador")

@bot.on(events.NewMessage(pattern=r'^/admin_rm\s+(\d+)$'))
async def admin_rm(ev):
    if not is_admin(ev.sender_id): 
        return
    aid = int(ev.pattern_match.group(1))
    S["admins"] = [x for x in S.get("admins", []) if x != aid]
    save_state(S)
    await ev.reply(f"✅ **Admin removido:** `{aid}`")

@bot.on(events.NewMessage(pattern=r'^/clients$'))
async def clients_list(ev):
    if not is_admin(ev.sender_id): 
        return
    clients = S.get("clients", {})
    if not clients:
        return await ev.reply("📭 **No hay clientes registrados**")
    
    lines = ["👥 **Lista de Clientes:**\n"]
    for slug, c in sorted(clients.items()):
        uname = c.get("username") or f"ID:{c.get('owner_id','?')}"
        plan = c.get("plan", "N/A")
        svc = f"reenvio@{slug}.service"
        st = _svc_status(svc)
        status_emoji = "🟢" if st == "active" else "🔴"
        exp = c.get("expires_at", "?")
        
        lines.append(f"{status_emoji} **{slug}** - @{uname} - {plan} - vence {exp}")
    
    await ev.reply("\n".join(lines))

@bot.on(events.NewMessage(pattern=r'^/client\s+(\S+)$'))
async def client_detail(ev):
    if not is_admin(ev.sender_id): 
        return
    slug = ev.pattern_match.group(1).strip()
    c = S.get("clients", {}).get(slug)
    
    if not c:
        return await ev.reply(f"❌ **No existe el cliente** `{slug}`")
    
    workdir = Path(c.get("workdir", ""))
    env = _read_env(workdir)
    token = env.get("BOT_TOKEN", "")
    token_short = token[:12] + "..." if token else "_(no configurado)_"
    svc = f"reenvio@{slug}.service"
    st = _svc_status(svc)
    
    bot_meta = {"ok": False, "username": None, "id": None}
    if token:
        try:
            import requests
            bot_meta = _get_bot_meta(token)
        except:
            pass
    
    status_emoji = "🟢" if st == "active" else "🔴"
    
    lines = [
        f"📋 **Detalles de {slug}**",
        f"",
        f"👤 **Propietario:** `{c.get('owner_id','?')}` (@{c.get('username', 'N/A')})",
        f"🎫 **Plan:** {c.get('plan', 'N/A')}",
        f"📅 **Vence:** {c.get('expires_at', '?')}",
        f"📁 **Directorio:** `{workdir}`",
        f"{status_emoji} **Servicio:** `{svc}` → **{st}**",
        f"🤖 **Bot Token:** `{token_short}`",
        f"🤖 **Bot Username:** @{bot_meta.get('username', 'desconocido')}",
        f"🤖 **Bot ID:** `{bot_meta.get('id', '?')}`",
        f"📅 **Creado:** {c.get('created_at', 'N/A')}"
    ]
    
    await ev.reply("\n".join(lines))

# ======= AUTH (admin, con plan trial) =======
def kb_durations():
    return [
        [Button.inline("🎁 7 días (TRIAL)", b"dur:7")],
        [Button.inline("📅 30 días", b"dur:30"), Button.inline("📅 90 días", b"dur:90")],
        [Button.inline("📅 365 días", b"dur:365")],
        [Button.inline("❌ Cancelar", b"dur:cancel")]
    ]

def kb_plans():
    return [
        [Button.inline("🎁 Trial", b"plan:plan_trial")],
        [Button.inline("📦 Estándar", b"plan:plan_estandar"), Button.inline("⭐ Plus", b"plan:plan_plus")],
        [Button.inline("👑 Pro", b"plan:plan_pro")],
        [Button.inline("❌ Cancelar", b"plan:cancel")]
    ]

@bot.on(events.NewMessage(pattern=r'^/auth$'))
async def auth_start(ev):
    if not is_admin(ev.sender_id):
        return
    flows[ev.sender_id] = {
        "mode": "auth",
        "await": "target",
        "target_id": None,
        "target_username": None
    }
    await ev.reply(
        "👤 **Autorizar nuevo cliente**\n\n"
        "📝 Envíame uno de los siguientes:\n"
        "• El **@username** del cliente\n" 
        "• El **ID numérico** del cliente\n"
        "• **Reenvía un mensaje** del cliente\n\n"
        "⏹️ _Escribe /cancel para cancelar_"
    )

@bot.on(events.NewMessage)
async def auth_capture_user(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode") != "auth" or f.get("await") != "target":
        return
    if not is_admin(ev.sender_id):
        return

    raw = (ev.raw_text or "").strip()

    # Ignorar comandos
    if raw.startswith("/"):
        if raw == "/cancel":
            flows.pop(ev.sender_id, None)
            await ev.reply("❌ **Autorización cancelada**")
        return

    uid = None
    uname = None

    # 1) Si es reenvío, tomamos el user_id del reenviado
    try:
        fwd = getattr(ev.message, "fwd_from", None)
        if fwd and getattr(getattr(fwd, "from_id", None), "user_id", None):
            uid = int(fwd.from_id.user_id)
    except Exception:
        pass

    # 2) Si no, intentamos resolver @usuario o ID
    if uid is None:
        try:
            if raw.isdigit():
                uid = int(raw)
            else:
                ent = await ev.client.get_entity(raw)
                uid = int(getattr(ent, "id", 0))
                uname = getattr(ent, "username", None)
        except Exception:
            await ev.reply(
                "❌ **No pude resolver el usuario**\n\n"
                "✅ **Formatos válidos:**\n"
                "• `@username`\n"
                "• `123456789` (ID numérico)\n"
                "• Mensaje reenviado del usuario"
            )
            return

    f["target_id"] = uid
    f["target_username"] = uname
    f["await"] = "plan"

    await ev.reply(
        f"✅ **Cliente identificado**\n"
        f"👤 ID: `{uid}`\n"
        f"📝 Username: @{uname or 'N/A'}\n\n"
        f"🎯 **Selecciona el plan:**",
        buttons=kb_plans()
    )

@bot.on(events.CallbackQuery)
async def auth_pick_plan(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode") != "auth" or f.get("await") != "plan":
        return
    if not is_admin(ev.sender_id):
        return

    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("plan:"):
        return

    plan = data.split(":", 1)[1]
    if plan == "cancel":
        flows.pop(ev.sender_id, None)
        try: 
            await ev.edit("❌ **Autorización cancelada**")
        except: 
            pass
        return

    f["plan"] = plan
    f["await"] = "days"

    # Para plan trial, fijar automáticamente 7 días
    if plan == "plan_trial":
        await auth_finalize(ev, f, 7)
        return

    try:
        await ev.edit(
            f"📦 **Plan seleccionado:** {plan}\n\n"
            f"⏰ **Selecciona la duración:**",
            buttons=kb_durations()
        )
    except:
        await ev.respond(
            f"📦 **Plan seleccionado:** {plan}\n\n"
            f"⏰ **Selecciona la duración:**",
            buttons=kb_durations()
        )

@bot.on(events.CallbackQuery)
async def auth_pick_days(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode") != "auth" or f.get("await") != "days":
        return
    if not is_admin(ev.sender_id):
        return

    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("dur:"):
        return

    val = data.split(":", 1)[1]
    if val == "cancel":
        flows.pop(ev.sender_id, None)
        try: 
            await ev.edit("❌ **Autorización cancelada**")
        except: 
            pass
        return

    try:
        days = int(val)
    except Exception:
        await ev.answer("⚠️ Duración inválida", alert=True)
        return

    await auth_finalize(ev, f, days)

async def auth_finalize(ev, f, days):
    """Finaliza el proceso de autorización"""
    tgt_id = f.get("target_id")
    tgt_un = f.get("target_username")
    plan = f.get("plan", "plan_estandar")
    
    slug = uniq_slug(tgt_un or str(tgt_id))
    exp_date = (dt.date.today() + dt.timedelta(days=days)).isoformat()

    # Registrar cliente
    S.setdefault("clients", {})[slug] = {
        "owner_id": tgt_id,
        "username": tgt_un,
        "plan": plan,
        "expires_at": exp_date,
        "workdir": str(CLIENTS_DIR / slug),
        "created_at": dt.datetime.now().isoformat(timespec="seconds")
    }
    save_state(S)
    flows.pop(ev.sender_id, None)

    # Mensajes específicos según el plan
    plan_emoji = {
        "plan_trial": "🎁",
        "plan_estandar": "📦", 
        "plan_plus": "⭐",
        "plan_pro": "👑"
    }.get(plan, "📦")
    
    # Aviso al admin
    try:
        await ev.edit(
            f"✅ **Cliente autorizado exitosamente**\n\n"
            f"{plan_emoji} **Plan:** {plan}\n"
            f"👤 **Cliente:** `{slug}` (ID: `{tgt_id}`)\n"
            f"📅 **Válido hasta:** {exp_date}\n"
            f"📁 **Directorio:** `{CLIENTS_DIR / slug}`\n\n"
            f"🔔 **El cliente ha sido notificado automáticamente**"
        )
    except:
        await ev.respond(
            f"✅ **Cliente autorizado exitosamente**\n\n"
            f"{plan_emoji} **Plan:** {plan}\n"
            f"👤 **Cliente:** `{slug}` (ID: `{tgt_id}`)\n"
            f"📅 **Válido hasta:** {exp_date}\n"
            f"📁 **Directorio:** `{CLIENTS_DIR / slug}`\n\n"
            f"🔔 **El cliente ha sido notificado automáticamente**"
        )

    # Notificar al cliente
    try:
        if plan == "plan_trial":
            welcome_msg = (
                f"🎁 **¡Bienvenido a tu TRIAL de 7 días!**\n\n"
                f"✅ Tu acceso ha sido activado\n"
                f"📅 **Válido hasta:** {exp_date}\n"
                f"🔧 **Tu identificador:** `{slug}`\n\n"
                f"🚀 **Para empezar:**\n"
                f"1️⃣ Usa el comando `/provision` aquí conmigo\n"
                f"2️⃣ Sigue las instrucciones paso a paso\n\n"
                f"❓ **¿Necesitas ayuda?** Contacta a @frankosmel\n"
                f"💬 **¿Te gustó el trial?** ¡Pregunta por nuestros planes!"
            )
        else:
            welcome_msg = (
                f"🎉 **¡Bienvenido al servicio!**\n\n"
                f"{plan_emoji} **Tu plan:** {plan}\n"
                f"📅 **Válido hasta:** {exp_date}\n"
                f"🔧 **Tu identificador:** `{slug}`\n\n"
                f"🚀 **Para empezar:**\n"
                f"1️⃣ Usa el comando `/provision` aquí conmigo\n"
                f"2️⃣ Sigue las instrucciones para configurar tu bot\n\n"
                f"❓ **Soporte:** @frankosmel"
            )
        
        await bot.send_message(tgt_id, welcome_msg)
    except Exception:
        await ev.respond("ℹ️ No pude notificar al cliente (no ha iniciado chat con el bot)")

# ======= Renovación de clientes =======
@bot.on(events.NewMessage(pattern=r'^/renew$'))
async def renew_start(ev):
    if not is_admin(ev.sender_id):
        return
    if not S.get("clients"):
        return await ev.reply("📭 **No hay clientes para renovar**")
    
    flows[ev.sender_id] = {"mode": "renew", "await": "client"}
    await ev.reply(
        "🔄 **Renovar cliente**\n\n"
        "👤 **Selecciona el cliente a renovar:**",
        buttons=kb_clients("renew")
    )

@bot.on(events.CallbackQuery)
async def renew_pick_client(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode") != "renew" or f.get("await") != "client":
        return
    if not is_admin(ev.sender_id):
        return

    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("renew:"):
        return

    slug = data.split(":", 1)[1]
    if slug == "cancel":
        flows.pop(ev.sender_id, None)
        try: 
            await ev.edit("❌ **Renovación cancelada**")
        except: 
            pass
        return

    if slug not in S.get("clients", {}):
        await ev.answer("❌ Cliente no encontrado", alert=True)
        return

    f["slug"] = slug
    f["await"] = "days"

    client = S["clients"][slug]
    try:
        await ev.edit(
            f"🔄 **Renovando:** `{slug}`\n"
            f"📅 **Vence actualmente:** {client.get('expires_at', 'N/A')}\n\n"
            f"⏰ **Selecciona nueva duración:**",
            buttons=kb_durations()
        )
    except:
        await ev.respond(
            f"🔄 **Renovando:** `{slug}`\n"
            f"📅 **Vence actualmente:** {client.get('expires_at', 'N/A')}\n\n"
            f"⏰ **Selecciona nueva duración:**",
            buttons=kb_durations()
        )

@bot.on(events.CallbackQuery) 
async def renew_pick_days(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode") != "renew" or f.get("await") != "days":
        return
    if not is_admin(ev.sender_id):
        return

    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("dur:"):
        return

    val = data.split(":", 1)[1]
    if val == "cancel":
        flows.pop(ev.sender_id, None)
        try: 
            await ev.edit("❌ **Renovación cancelada**")
        except: 
            pass
        return

    try:
        days = int(val)
    except Exception:
        await ev.answer("⚠️ Duración inválida", alert=True)
        return

    slug = f["slug"]
    new_exp = (dt.date.today() + dt.timedelta(days=days)).isoformat()
    
    # Actualizar fecha de vencimiento
    S["clients"][slug]["expires_at"] = new_exp
    save_state(S)
    flows.pop(ev.sender_id, None)
    
    # Reactivar servicio si estaba pausado
    try:
        resume_instance_service(slug)
    except:
        pass

    try:
        await ev.edit(
            f"✅ **Cliente renovado exitosamente**\n\n"
            f"👤 **Cliente:** `{slug}`\n"
            f"📅 **Nueva fecha de vencimiento:** {new_exp}\n"
            f"🔄 **Duración agregada:** {days} días\n\n"
            f"▶️ **Servicio reactivado automáticamente**"
        )
    except:
        await ev.respond(
            f"✅ **Cliente renovado exitosamente**\n\n"
            f"👤 **Cliente:** `{slug}`\n"
            f"📅 **Nueva fecha de vencimiento:** {new_exp}\n"
            f"🔄 **Duración agregada:** {days} días\n\n"
            f"▶️ **Servicio reactivado automáticamente**"
        )

    # Notificar al cliente
    try:
        client = S["clients"][slug]
        await bot.send_message(
            client["owner_id"],
            f"🎉 **¡Tu plan ha sido renovado!**\n\n"
            f"📅 **Válido hasta:** {new_exp}\n"
            f"▶️ **Tu servicio ya está activo nuevamente**\n"
            f"🙏 **¡Gracias por confiar en nosotros!**"
        )
    except:
        pass

# ======= Cambio de plan =======
@bot.on(events.NewMessage(pattern=r'^/edit_plan$'))
async def edit_plan_start(ev):
    if not is_admin(ev.sender_id):
        return
    if not S.get("clients"):
        return await ev.reply("📭 **No hay clientes**")
    
    flows[ev.sender_id] = {"mode": "edit_plan", "await": "client"}
    await ev.reply(
        "📝 **Cambiar plan de cliente**\n\n"
        "👤 **Selecciona el cliente:**",
        buttons=kb_clients("edit_plan")
    )

@bot.on(events.CallbackQuery)
async def edit_plan_pick_client(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode") != "edit_plan" or f.get("await") != "client":
        return
    if not is_admin(ev.sender_id):
        return

    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("edit_plan:"):
        return

    slug = data.split(":", 1)[1]
    if slug == "cancel":
        flows.pop(ev.sender_id, None)
        try: 
            await ev.edit("❌ **Operación cancelada**")
        except: 
            pass
        return

    if slug not in S.get("clients", {}):
        await ev.answer("❌ Cliente no encontrado", alert=True)
        return

    f["slug"] = slug
    f["await"] = "plan"

    client = S["clients"][slug]
    current_plan = client.get("plan", "N/A")
    
    try:
        await ev.edit(
            f"📝 **Cambiar plan:** `{slug}`\n"
            f"📦 **Plan actual:** {current_plan}\n\n"
            f"🎯 **Selecciona nuevo plan:**",
            buttons=kb_plans()
        )
    except:
        await ev.respond(
            f"📝 **Cambiar plan:** `{slug}`\n"
            f"📦 **Plan actual:** {current_plan}\n\n"
            f"🎯 **Selecciona nuevo plan:**",
            buttons=kb_plans()
        )

@bot.on(events.CallbackQuery)
async def edit_plan_pick_plan(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode") != "edit_plan" or f.get("await") != "plan":
        return
    if not is_admin(ev.sender_id):
        return

    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("plan:"):
        return

    plan = data.split(":", 1)[1]
    if plan == "cancel":
        flows.pop(ev.sender_id, None)
        try: 
            await ev.edit("❌ **Operación cancelada**")
        except: 
            pass
        return

    slug = f["slug"]
    old_plan = S["clients"][slug].get("plan", "N/A")
    
    # Actualizar plan
    S["clients"][slug]["plan"] = plan
    save_state(S)
    flows.pop(ev.sender_id, None)

    plan_emoji = {
        "plan_trial": "🎁",
        "plan_estandar": "📦", 
        "plan_plus": "⭐",
        "plan_pro": "👑"
    }.get(plan, "📦")

    try:
        await ev.edit(
            f"✅ **Plan actualizado exitosamente**\n\n"
            f"👤 **Cliente:** `{slug}`\n"
            f"📦 **Plan anterior:** {old_plan}\n"
            f"{plan_emoji} **Nuevo plan:** {plan}\n\n"
            f"ℹ️ **Nota:** El cliente deberá usar `/provision` para actualizar su instancia"
        )
    except:
        await ev.respond(
            f"✅ **Plan actualizado exitosamente**\n\n"
            f"👤 **Cliente:** `{slug}`\n"
            f"📦 **Plan anterior:** {old_plan}\n"
            f"{plan_emoji} **Nuevo plan:** {plan}\n\n"
            f"ℹ️ **Nota:** El cliente deberá usar `/provision` para actualizar su instancia"
        )

    # Notificar al cliente
    try:
        client = S["clients"][slug]
        await bot.send_message(
            client["owner_id"],
            f"🔄 **Tu plan ha sido actualizado**\n\n"
            f"{plan_emoji} **Nuevo plan:** {plan}\n"
            f"🚀 **Para aplicar cambios:** usa `/provision` para reinstalar tu bot\n\n"
            f"❓ **¿Dudas?** Contacta a @frankosmel"
        )
    except:
        pass

# ======= Revocación de clientes =======
@bot.on(events.NewMessage(pattern=r'^/revoke$'))
async def revoke_start(ev):
    if not is_admin(ev.sender_id):
        return
    if not S.get("clients"):
        return await ev.reply("📭 **No hay clientes**")
    
    flows[ev.sender_id] = {"mode": "revoke", "await": "client"}
    await ev.reply(
        "🚫 **Revocar acceso de cliente**\n\n"
        "⚠️ **ADVERTENCIA:** Esto eliminará permanentemente el cliente y detendrá su servicio.\n\n"
        "👤 **Selecciona el cliente:**",
        buttons=kb_clients("revoke")
    )

@bot.on(events.CallbackQuery)
async def revoke_pick_client(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode") != "revoke" or f.get("await") != "client":
        return
    if not is_admin(ev.sender_id):
        return

    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("revoke:"):
        return

    slug = data.split(":", 1)[1]
    if slug == "cancel":
        flows.pop(ev.sender_id, None)
        try: 
            await ev.edit("❌ **Revocación cancelada**")
        except: 
            pass
        return

    if slug not in S.get("clients", {}):
        await ev.answer("❌ Cliente no encontrado", alert=True)
        return

    # Deshabilitar servicio
    try:
        disable_instance_service(slug)
    except Exception as e:
        logger.error(f"Error deshabilitando servicio para {slug}: {e}")

    # Remover del estado
    client_info = S["clients"].pop(slug)
    save_state(S)
    flows.pop(ev.sender_id, None)

    try:
        await ev.edit(
            f"✅ **Cliente revocado exitosamente**\n\n"
            f"👤 **Cliente eliminado:** `{slug}`\n"
            f"🔴 **Servicio detenido:** `reenvio@{slug}.service`\n"
            f"📁 **Directorio preservado:** `{client_info.get('workdir', 'N/A')}`\n\n"
            f"ℹ️ **El directorio del cliente se mantiene intacto**"
        )
    except:
        await ev.respond(
            f"✅ **Cliente revocado exitosamente**\n\n"
            f"👤 **Cliente eliminado:** `{slug}`\n"
            f"🔴 **Servicio detenido:** `reenvio@{slug}.service`\n"
            f"📁 **Directorio preservado:** `{client_info.get('workdir', 'N/A')}`\n\n"
            f"ℹ️ **El directorio del cliente se mantiene intacto**"
        )

    # Notificar al cliente
    try:
        await bot.send_message(
            client_info["owner_id"],
            f"🚫 **Tu acceso ha sido revocado**\n\n"
            f"🔴 **Servicio detenido**\n"
            f"📞 **Para más información contacta:** @frankosmel"
        )
    except:
        pass

# ======= Cliente: provisión =======
@bot.on(events.NewMessage(pattern=r'^/provision$'))
async def provision_start(ev):
    cid = ev.sender_id
    # Buscar cliente autorizado
    my = None
    for slug, c in S["clients"].items():
        if c.get("owner_id") == cid:
            my = (slug, c)
            break
    
    if not my:
        return await ev.reply(
            "⛔ **No estás autorizado**\n\n"
            "📞 Para obtener acceso contacta a: @frankosmel\n"
            "🎁 ¡Pregunta por nuestro trial de 7 días!"
        )

    slug, c = my
    plan = c.get("plan", "plan_estandar")
    
    # Verificar si el plan está vencido
    expires_at = c.get("expires_at")
    if expires_at and expires_at <= dt.date.today().isoformat():
        return await ev.reply(
            f"⏰ **Tu plan ha vencido**\n\n"
            f"📅 **Venció:** {expires_at}\n"
            f"📞 **Para renovar contacta:** @frankosmel\n\n"
            f"🔄 Una vez renovado, podrás usar este comando nuevamente."
        )
    
    flows[cid] = {
        "mode": "provision", 
        "slug": slug, 
        "plan": plan, 
        "await": "token"
    }
    
    plan_emoji = {
        "plan_trial": "🎁",
        "plan_estandar": "📦", 
        "plan_plus": "⭐",
        "plan_pro": "👑"
    }.get(plan, "📦")
    
    await ev.reply(
        f"🚀 **Configurando tu bot**\n\n"
        f"{plan_emoji} **Plan:** {plan}\n"
        f"🔧 **Identificador:** `{slug}`\n"
        f"📅 **Válido hasta:** {c.get('expires_at', 'N/A')}\n\n"
        f"🤖 **Paso 1/2:** Pega tu **BOT_TOKEN**\n"
        f"_(Obtén tu token desde @BotFather)_\n\n"
        f"📋 **Formato esperado:** `123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11`"
    )
    raise events.StopPropagation  # ← añadido para evitar doble manejo del mismo update

@bot.on(events.NewMessage(pattern=r'^/status$'))
async def status_cmd(ev):
    cid = ev.sender_id
    # Buscar cliente
    my = None
    for slug, c in S["clients"].items():
        if c.get("owner_id") == cid:
            my = (slug, c)
            break
    
    if not my:
        return await ev.reply("⛔ **No estás autorizado**")
    
    slug, c = my
    plan = c.get("plan", "N/A")
    expires_at = c.get("expires_at", "N/A")
    workdir = Path(c.get("workdir", ""))
    
    # Estado del servicio
    svc = f"reenvio@{slug}.service"
    status = _svc_status(svc)
    status_emoji = "🟢" if status == "active" else "🔴"
    
    # Info del bot si existe
    env = _read_env(workdir)
    token = env.get("BOT_TOKEN", "")
    bot_meta = {"username": None, "id": None}
    
    if token:
        try:
            import requests
            bot_meta = _get_bot_meta(token)
        except:
            pass
    
    # Verificar si está vencido
    is_expired = expires_at <= dt.date.today().isoformat() if expires_at != "N/A" else False
    
    plan_emoji = {
        "plan_trial": "🎁",
        "plan_estandar": "📦", 
        "plan_plus": "⭐",
        "plan_pro": "👑"
    }.get(plan, "📦")
    
    lines = [
        f"📊 **Estado de tu servicio**",
        f"",
        f"{plan_emoji} **Plan:** {plan}",
        f"🔧 **Identificador:** `{slug}`",
        f"📅 **Vence:** {expires_at}" + (" ⚠️ **VENCIDO**" if is_expired else ""),
        f"{status_emoji} **Servicio:** {status}",
        f"🤖 **Bot:** @{bot_meta.get('username', 'No configurado')}",
        f"📁 **Directorio:** `{workdir}`"
    ]
    
    if is_expired:
        lines.append("")
        lines.append("📞 **Para renovar contacta:** @frankosmel")
    
    keyboard = []
    if not is_expired and status != "active":
        keyboard.append([Button.inline("🔄 Reiniciar servicio", f"restart:{slug}".encode())])
    
    keyboard.append([Button.url("💬 Contactar soporte", "https://t.me/frankosmel")])
    
    await ev.reply("\n".join(lines), buttons=keyboard if keyboard else None)

# ======= Callback para reiniciar servicio desde /status =======
@bot.on(events.CallbackQuery)
async def handle_restart_service(ev):
    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("restart:"):
        return
    
    slug = data.split(":", 1)[1]
    
    # Verificar que el usuario sea dueño del servicio
    cid = ev.sender_id
    client = S.get("clients", {}).get(slug)
    if not client or client.get("owner_id") != cid:
        await ev.answer("❌ No tienes permisos", alert=True)
        return
    
    try:
        resume_instance_service(slug)
        await ev.answer("✅ Servicio reiniciado", alert=True)
        
        # Actualizar mensaje
        status = _svc_status(f"reenvio@{slug}.service") 
        status_emoji = "🟢" if status == "active" else "🔴"
        
        try:
            await ev.edit(f"🔄 **Servicio reiniciado**\n{status_emoji} **Estado:** {status}")
        except:
            pass
            
    except Exception as e:
        await ev.answer(f"❌ Error: {str(e)[:50]}", alert=True)

@bot.on(events.NewMessage)
async def provision_flow(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode") != "provision": 
        return
    if f.get("await") != "token": 
        return

    # Ignorar comandos para no evaluar /provision como token
    raw = (ev.raw_text or "").strip()
    if raw.startswith('/'):
        return

    token = raw
    if not token or ":" not in token:
        return await ev.reply(
            "❌ **BOT_TOKEN inválido**\n\n"
            "✅ **Formato correcto:**\n"
            "`123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11`\n\n"
            "📱 **¿Cómo obtenerlo?**\n"
            "1️⃣ Habla con @BotFather\n"
            "2️⃣ Usa `/newbot` o `/mybots`\n"
            "3️⃣ Copia el token completo aquí"
        )
    
    # Datos del flujo
    slug = f["slug"]
    plan = f["plan"]
    workdir = Path(S["clients"][slug]["workdir"])
    owner_id = ev.sender_id
    
    try:
        await ev.reply("⏳ **Paso 1/4:** Clonando plantilla...")
        clone_template(plan, workdir)
        
        await ev.reply("⏳ **Paso 2/4:** Configurando variables...")
        write_env(workdir, bot_token=token, owner_id=owner_id, slug=slug, tz="UTC")
        force_load_dotenv_override(workdir)
        
        await ev.reply("⏳ **Paso 3/4:** Instalando dependencias...")
        ensure_venv_and_requirements(workdir)
        
        await ev.reply("⏳ **Paso 4/4:** Activando servicio...")
        enable_instance_service(slug)
        
        flows.pop(ev.sender_id, None)
        
        # Verificar que el bot token es válido
        bot_meta = _get_bot_meta(token)
        bot_info = f"@{bot_meta.get('username', 'Error verificando')}" if bot_meta.get("ok") else "⚠️ Token inválido o bot inaccesible"
        
        await ev.reply(
            f"✅ **¡Instancia creada exitosamente!**\n\n"
            f"🤖 **Tu bot:** {bot_info}\n"
            f"📁 **Directorio:** `{workdir}`\n"
            f"🛎️ **Servicio:** `reenvio@{slug}.service`\n"
            f"🟢 **Estado:** Activo\n\n"
            f"📋 **Comandos útiles:**\n"
            f"• `/status` - Ver estado detallado\n"
            f"• `/provision` - Reinstalar si necesario\n\n"
            f"❓ **¿Necesitas ayuda?** Contacta a @frankosmel"
        )
        
    except subprocess.CalledProcessError as e:
        flows.pop(ev.sender_id, None)
        await ev.reply(
            f"❌ **Error en la instalación**\n\n"
            f"🔧 **Comando que falló:** `{e.cmd}`\n"
            f"📞 **Contacta al soporte:** @frankosmel\n"
            f"📝 **Código de error:** `{e.returncode}`"
        )
    except Exception as e:
        flows.pop(ev.sender_id, None)
        await ev.reply(
            f"❌ **Error inesperado**\n\n"
            f"📝 **Detalles:** `{str(e)[:100]}`\n"
            f"📞 **Contacta al soporte:** @frankosmel"
        )

# ======= Sistema de actualización de plantillas =======
def _upgrade_client(slug: str) -> str:
    """Actualiza un cliente específico desde la plantilla"""
    current_state = load_state()
    if slug not in current_state.get("clients", {}):
        return f"❌ Cliente `{slug}` no existe"
    
    info = current_state["clients"][slug]
    wdir = Path(info["workdir"])
    plan = info.get("plan", "plan_estandar")
    svc = f"reenvio@{slug}.service"
    
    if not wdir.exists():
        return f"❌ Directorio no existe: `{wdir}`"
    
    template_dir = TEMPL.get(plan)
    if not template_dir or not template_dir.exists():
        return f"❌ Plantilla no encontrada para plan: `{plan}`"
    
    try:
        # Detener servicio
        try: 
            run(f"sudo -n /usr/bin/systemctl stop {svc}")
        except: 
            pass
        
        # Sincronizar archivos (preservando .env, sessions, venv, state)
        rsync = shutil.which("rsync")
        if rsync:
            run(
                f'rsync -a --delete '
                f'--exclude ".env" --exclude "state*.json" --exclude "*session*" --exclude "venv" '
                f'{template_dir}/ {wdir}/'
            )
        else:
            # Fallback manual
            for src in template_dir.rglob("*"):
                rel = src.relative_to(template_dir)
                dst = wdir / rel
                
                # Preservar archivos importantes
                if any(str(rel).startswith(x) for x in ("venv", ".env")) or \
                   dst.name.endswith(".session") or dst.name.startswith("state"):
                    continue
                
                if src.is_dir():
                    dst.mkdir(parents=True, exist_ok=True)
                else:
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, dst)
        
        # Reinstalar requirements si existen
        req = wdir / "requirements.txt"
        vpy = wdir / "venv/bin/pip"
        if req.exists() and vpy.exists():
            try:
                run(f"{vpy} install --upgrade -r {req}")
            except:
                pass
        
        # Reiniciar servicio
        try: 
            run("sudo -n /usr/bin/systemctl daemon-reload")
        except: 
            pass
        run(f"sudo -n /usr/bin/systemctl start {svc}")
        
        return f"✅ `{slug}` actualizado y reiniciado"
        
    except Exception as e:
        return f"❌ Error actualizando `{slug}`: {str(e)[:100]}"

@bot.on(events.NewMessage(pattern=r'^/upgrade\s+(\S+)$'))
async def cmd_upgrade_one(ev):
    if not is_admin(ev.sender_id):
        return
    slug = ev.pattern_match.group(1).strip()
    
    msg_loading = await ev.reply(f"⏳ **Actualizando** `{slug}`...")
    
    result = _upgrade_client(slug)
    
    try:
        await msg_loading.edit(result)
    except:
        await ev.reply(result)

@bot.on(events.NewMessage(pattern=r'^/upgrade_all$'))
async def cmd_upgrade_all(ev):
    if not is_admin(ev.sender_id):
        return
    
    current_state = load_state()
    clients = sorted(current_state.get("clients", {}).keys())
    
    if not clients:
        return await ev.reply("📭 **No hay clientes para actualizar**")
    
    msg_loading = await ev.reply(f"⏳ **Actualizando {len(clients)} clientes...**")
    
    results = []
    for i, slug in enumerate(clients, 1):
        try:
            result = _upgrade_client(slug)
            results.append(f"{i}. {result}")
            
            # Actualizar progreso cada 3 clientes
            if i % 3 == 0 or i == len(clients):
                try:
                    await msg_loading.edit(
                        f"⏳ **Progreso: {i}/{len(clients)}**\n\n" + 
                        "\n".join(results[-5:])  # Mostrar últimos 5
                    )
                except:
                    pass
                    
        except Exception as e:
            results.append(f"{i}. ❌ {slug}: {str(e)[:50]}")
    
    # Resultado final
    final_msg = f"🔄 **Actualización completada**\n\n" + "\n".join(results[:20])
    if len(results) > 20:
        final_msg += f"\n\n_(+{len(results)-20} clientes más)_"
    
    try:
        await msg_loading.edit(final_msg)
    except:
        await ev.reply(final_msg)

# ======= Comandos de cancelación =======
@bot.on(events.NewMessage(pattern=r'^/cancel$'))
async def cancel_flow(ev):
    if ev.sender_id in flows:
        flows.pop(ev.sender_id, None)
        await ev.reply("❌ **Operación cancelada**")
    else:
        await ev.reply("ℹ️ **No hay operaciones activas para cancelar**")

# ======= Comando de ayuda =======
@bot.on(events.NewMessage(pattern=r'^/help$'))
async def help_cmd(ev):
    uid = ev.sender_id
    if is_admin(uid):
        await ev.reply(
            "📖 **Ayuda - Administrador**\n\n"
            "👑 **Gestión de administradores:**\n"
            "• `/set_owner <id>` - Establecer propietario\n"
            "• `/admins` - Listar administradores\n"
            "• `/admin_add <id>` - Agregar admin\n"
            "• `/admin_rm <id>` - Remover admin\n\n"
            "👥 **Gestión de clientes:**\n"
            "• `/clients` - Listar todos los clientes\n"
            "• `/client <slug>` - Ver detalles de cliente\n"
            "• `/auth` - Autorizar nuevo cliente\n"
            "• `/renew` - Renovar plan de cliente\n"
            "• `/edit_plan` - Cambiar plan de cliente\n"
            "• `/revoke` - Revocar acceso de cliente\n\n"
            "🔧 **Mantenimiento:**\n"
            "• `/upgrade <slug>` - Actualizar cliente\n"
            "• `/upgrade_all` - Actualizar todos\n\n"
            "🎁 **Planes disponibles:**\n"
            "• `plan_trial` - 7 días de prueba\n"
            "• `plan_estandar` - Plan básico\n"
            "• `plan_plus` - Plan intermedio\n"
            "• `plan_pro` - Plan premium\n\n"
            "❌ **Otros:** `/cancel` - Cancelar operación"
        )
    else:
        await ev.reply(
            "📖 **Ayuda - Cliente**\n\n"
            "🚀 **Comandos principales:**\n"
            "• `/start` - Ver tu estado actual\n"
            "• `/provision` - Configurar/reinstalar tu bot\n"
            "• `/status` - Ver estado detallado de tu servicio\n"
            "• `/help` - Mostrar esta ayuda\n\n"
            "🎁 **¿Nuevo aquí?**\n"
            "Contacta a @frankosmel para obtener acceso\n"
            "¡Pregunta por nuestro trial gratuito de 7 días!\n\n"
            "❓ **Soporte:** @frankosmel"
        )

# ======= Función principal =======
async def main():
    await bot.start(bot_token=BOT_TOKEN)
    print("🤖 Bot Manager iniciado correctamente")
    print(f"📊 Clientes registrados: {len(S.get('clients', {}))}")
    print(f"👮 Administradores: {len(S.get('admins', []))} + 1 owner")
    
    # Ejecutar chequeo inicial de expiraciones
    await check_expiring_plans()
    
    # Iniciar task de background para chequeos periódicos
    asyncio.create_task(expiry_checker_task())
    
    print("🔔 Sistema de notificaciones de expiración activo")
    await bot.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())
N