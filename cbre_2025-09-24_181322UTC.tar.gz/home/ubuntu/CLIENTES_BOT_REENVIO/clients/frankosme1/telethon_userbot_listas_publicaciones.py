# bot.py
# ==============================================================================
#  Bot de Reenvío de Publicaciones v3 - Un solo archivo
# ==============================================================================
#
#  Instrucciones de arranque:
#  1. Asegúrate de tener Python 3.10 o superior.
#
#  2. Crea un entorno virtual (recomendado):
#     python -m venv venv
#     source venv/bin/activate  # En Windows: venv\Scripts\activate
#
#  3. Instala las dependencias:
#     pip install telethon apscheduler "apscheduler[sqlalchemy]" aiolimiter ujson python-dotenv "pytz"
#
#  4. Crea un archivo .env en el mismo directorio con el siguiente contenido:
#     API_ID=1234567
#     API_HASH=tu_api_hash
#     BOT_TOKEN=token_de_tu_bot
#     OWNER_ID=tu_id_de_usuario_de_telegram
#
#  5. (Opcional) Personaliza otras variables de entorno:
#     SESSION_NAME=reenvio
#     TIMEZONE=America/Havana
#     QUIET_START=00:00
#     QUIET_END=07:00
#
#  6. Ejecuta el bot:
#     python bot.py
#
#  7. La primera vez, el bot te pedirá iniciar sesión con tu cuenta de usuario
#     en la consola para crear el archivo de sesión (.session).
#
# ==============================================================================

import os
import json
import asyncio
import logging
import random
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple, Union
import copy
from contextlib import suppress

# --- Dependencias ---
try:
    import ujson
    json_lib = ujson
except ImportError:
    json_lib = json

from telethon import TelegramClient, events, Button
from telethon.errors import (FloodWaitError, ChatWriteForbiddenError,
                             UserIsBlockedError, PeerIdInvalidError, RPCError)
from telethon.tl.types import Message

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from apscheduler.triggers.date import DateTrigger

from aiolimiter import AsyncLimiter
from dotenv import load_dotenv

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)

# --- Carga de Configuración y Variables de Entorno ---
load_dotenv(, override=True)

API_ID = int(os.getenv("API_ID", 0))
API_HASH = os.getenv("API_HASH", "")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
OWNER_ID = int(os.getenv("OWNER_ID", 0))
SESSION_NAME = os.getenv("SESSION_NAME", "reenvio")

if not all([API_ID, API_HASH, BOT_TOKEN, OWNER_ID]):
    log.critical("FATAL: API_ID, API_HASH, BOT_TOKEN, y OWNER_ID deben estar definidos en las variables de entorno.")
    exit(1)

# --- Estado y Constantes ---
STATE_FILE = Path("state.json")
SCHEMA_VERSION = "3.1"
DEFAULT_STATE = {
    "schema_version": SCHEMA_VERSION,
    "quiet_hours": {
        "start": os.getenv("QUIET_START", "00:00"),
        "end": os.getenv("QUIET_END", "07:00"),
        "tz": os.getenv("TIMEZONE", "America/Havana")
    },
    "dedup_ttl_hours": 24,
    "dry_run": False,
    "lists": {"TODOS": []}, # 'TODOS' es una lista especial, no editable directamente
    "pubs": {},
}
# Diccionario para contextos de entrada de texto
user_context: Dict[int, Dict[str, Any]] = {}
# Caché de deduplicación en memoria: (source_chat_id, source_msg_id) -> timestamp
dedup_cache: Dict[Tuple[int, int], float] = {}

# --- Inicialización de Clientes y Scheduler ---
client = TelegramClient(SESSION_NAME, API_ID, API_HASH)
bot = TelegramClient(None, API_ID, API_HASH) # Bot se conecta con token
scheduler = AsyncIOScheduler()

# ==============================================================================
# 1. GESTIÓN DE ESTADO (state.json)
# ==============================================================================

def save_state(state_data: Dict[str, Any]):
    """Guarda el estado de forma atómica en state.json."""
    temp_file = STATE_FILE.with_suffix(".tmp")
    try:
        temp_file.write_text(json_lib.dumps(state_data, indent=2, ensure_ascii=False), encoding='utf-8')
        temp_file.replace(STATE_FILE)
    except Exception as e:
        log.error(f"Error al guardar el estado: {e}")

def _migrate_and_fill_defaults(loaded_state: Dict[str, Any]) -> Tuple[Dict[str, Any], bool]:
    """
    Compara el estado cargado con el default, añade claves faltantes y marca si hubo cambios.
    Aplica una migración básica si es necesario.
    """
    is_dirty = False
    original_state = copy.deepcopy(loaded_state)

    if loaded_state.get("schema_version") != SCHEMA_VERSION:
        log.warning(f"Versión de esquema obsoleta. Migrando de '{loaded_state.get('schema_version')}' a '{SCHEMA_VERSION}'")
        is_dirty = True
    
    # Recursivamente añade claves faltantes
    def fill_recursively(current_level, default_level):
        nonlocal is_dirty
        for key, default_value in default_level.items():
            if key not in current_level:
                current_level[key] = default_value
                is_dirty = True
            elif isinstance(default_value, dict) and isinstance(current_level[key], dict):
                fill_recursively(current_level[key], default_value)

    fill_recursively(loaded_state, DEFAULT_STATE)
    loaded_state["schema_version"] = SCHEMA_VERSION # Forzar versión actual

    return loaded_state, is_dirty

def load_state() -> Dict[str, Any]:
    """Carga state.json, realiza migraciones y backups si es necesario."""
    if not STATE_FILE.exists():
        log.info(f"No se encontró '{STATE_FILE}', creando uno nuevo con valores por defecto.")
        save_state(DEFAULT_STATE)
        return copy.deepcopy(DEFAULT_STATE)
    
    try:
        loaded_data = json_lib.loads(STATE_FILE.read_text(encoding='utf-8'))
        
        migrated_state, was_migrated = _migrate_and_fill_defaults(loaded_data)
        
        if was_migrated:
            backup_filename = f"state.bak.{datetime.now().strftime('%Y%m%d%H%M%S')}"
            log.warning(f"El estado fue actualizado. Creando backup en '{backup_filename}'")
            Path(backup_filename).write_text(json_lib.dumps(loaded_data, indent=2, ensure_ascii=False))
            save_state(migrated_state)
        
        return migrated_state

    except (json_lib.JSONDecodeError, TypeError) as e:
        log.error(f"Error al decodificar '{STATE_FILE}': {e}. Se usará el estado por defecto.")
        return copy.deepcopy(DEFAULT_STATE)
    except Exception as e:
        log.error(f"Error inesperado al cargar el estado: {e}. Se usará el estado por defecto.")
        return copy.deepcopy(DEFAULT_STATE)

state = load_state()


# ==============================================================================
# 2. FUNCIONES AUXILIARES (Tiempo, UI, Parsers)
# ==============================================================================

def get_tz_info():
    """Obtiene el objeto de zona horaria o UTC como fallback."""
    try:
        from pytz import timezone as pytz_timezone, UnknownTimeZoneError
        return pytz_timezone(state['quiet_hours']['tz'])
    except (ImportError, UnknownTimeZoneError):
        return timezone.utc

def now_in_tz() -> datetime:
    """Devuelve la hora actual en la zona horaria configurada."""
    return datetime.now(get_tz_info())

def in_quiet_hours() -> bool:
    """Verifica si la hora actual está dentro del período de silencio."""
    q_cfg = state['quiet_hours']
    if q_cfg['start'].lower() == 'off' or q_cfg['end'].lower() == 'off':
        return False
        
    now = now_in_tz()
    
    try:
        start_time = datetime.strptime(q_cfg['start'], '%H:%M').time()
        end_time = datetime.strptime(q_cfg['end'], '%H:%M').time()
    except ValueError:
        log.error(f"Formato de quiet hours inválido: start={q_cfg['start']}, end={q_cfg['end']}")
        return False

    now_time = now.time()
    if start_time < end_time:
        return start_time <= now_time < end_time
    else: # Horario nocturno que cruza la medianoche (e.g., 23:00 - 07:00)
        return now_time >= start_time or now_time < end_time

def p_data(payload: Dict) -> str:
    """Codifica un diccionario en una cadena JSON compacta para callback_data."""
    # Versión 'c' (corta) de las claves para ahorrar espacio
    short_map = {
        "view": "v", "page": "p", "name": "n", "action": "a", 
        "sub": "s", "key": "k", "val": "vl"
    }
    short_payload = {short_map.get(k, k): v for k, v in payload.items()}
    return json_lib.dumps(short_payload)

def unp_data(query_data: bytes) -> Dict:
    """Decodifica el JSON de callback_data a un diccionario."""
    long_map = {
        "v": "view", "p": "page", "n": "name", "a": "action", 
        "s": "sub", "k": "key", "vl": "val"
    }
    try:
        data = json_lib.loads(query_data.decode('utf-8'))
        return {long_map.get(k, k): v for k, v in data.items()}
    except (json_lib.JSONDecodeError, UnicodeDecodeError):
        return {}
        
async def get_entity_name(entity_id: int) -> str:
    """Obtiene el nombre de una entidad (canal/grupo) de forma segura."""
    try:
        entity = await client.get_entity(entity_id)
        return getattr(entity, 'title', getattr(entity, 'username', f"ID {entity_id}"))
    except Exception:
        return f"ID Desconocido {entity_id}"

# ==============================================================================
# 3. LÓGICA DE EJECUCIÓN DE PUBLICACIONES
# ==============================================================================
async def resolve_targets(pub_cfg: Dict[str, Any]) -> List[int]:
    """Resuelve los IDs de destino finales para una publicación."""
    list_name = pub_cfg['target_list']
    source_id = pub_cfg['source_chat_id']
    policy = pub_cfg.get('send_policy', {})
    
    # 1. Obtener la lista base
    if list_name == "TODOS":
        base_ids = [dialog.id for dialog in await client.get_dialogs() if dialog.is_group or dialog.is_channel]
    else:
        base_ids = state['lists'].get(list_name, [])

    # 2. Excluir el origen
    final_ids = [gid for gid in base_ids if gid != source_id]
    
    # 3. Aplicar Whitelist (si no está vacía, es la única fuente)
    whitelist = policy.get('whitelist_chat_ids', [])
    if whitelist:
        final_ids = [gid for gid in final_ids if gid in whitelist]
    
    # 4. Aplicar Blacklist
    blacklist = policy.get('blacklist_chat_ids', [])
    if blacklist:
        final_ids = [gid for gid in final_ids if gid not in blacklist]
        
    return list(set(final_ids))

def check_dedup(source_chat_id: int, source_msg_id: int) -> bool:
    """Verifica si un mensaje ya ha sido enviado recientemente."""
    key = (source_chat_id, source_msg_id)
    ttl_seconds = state.get('dedup_ttl_hours', 24) * 3600
    
    if key in dedup_cache:
        last_sent_time = dedup_cache[key]
        if time.time() - last_sent_time < ttl_seconds:
            return True # Dedup: encontrado y reciente
    return False # No es duplicado

def update_dedup(source_chat_id: int, source_msg_id: int):
    """Actualiza la caché de deduplicación para un mensaje."""
    key = (source_chat_id, source_msg_id)
    dedup_cache[key] = time.time()

async def send_with_retries(target_id: int, source_msg: Message) -> str:
    """Envía un mensaje con reintentos, backoff exponencial y manejo de errores."""
    policy = state['pubs'][source_msg._pub_name].get('send_policy', {}) # Inyectado en `run_publication`
    max_retries = policy.get('max_retries', 3)
    backoff_base = policy.get('retry_backoff_base_s', 2.0)
    flood_pad = policy.get('floodwait_pad_s', 1)

    for attempt in range(max_retries):
        try:
            # Reenvía como copia para anonimizar el origen
            await client.send_message(target_id, file=source_msg.media, message=source_msg.text, link_preview=False)
            return "ok"
        except FloodWaitError as e:
            wait_time = e.seconds + flood_pad
            log.warning(f"[RETRY] FloodWaitError para {target_id}. Esperando {wait_time:.2f}s (intento {attempt + 1}/{max_retries})")
            await asyncio.sleep(wait_time)
        except ChatWriteForbiddenError:
            log.error(f"[FAIL] ChatWriteForbiddenError para {target_id}. No se puede escribir. No se reintentará.")
            return "forbidden"
        except (PeerIdInvalidError, ValueError):
            log.error(f"[FAIL] PeerIdInvalidError para {target_id}. El chat no existe o es inválido. No se reintentará.")
            return "invalid_peer"
        except Exception as e:
            wait_time = backoff_base * (2 ** attempt)
            log.error(f"[RETRY] Error enviando a {target_id}: {type(e).__name__}. Reintentando en {wait_time:.2f}s (intento {attempt + 1}/{max_retries})")
            await asyncio.sleep(wait_time)
            
    return "failed_retries"
    
async def run_publication(pub_name: str):
    """Función principal que orquesta el envío de una publicación, llamada por el scheduler."""
    start_time = time.monotonic()
    log.info(f"▶️ Iniciando trabajo para la publicación: '{pub_name}'")
    
    metrics = {"ok": 0, "fail": 0, "skipped": 0, "total": 0, "reason": "N/A"}

    if not pub_name in state['pubs']:
        log.error(f"Publicación '{pub_name}' no encontrada en el estado. Eliminando job.")
        scheduler.remove_job(pub_name)
        return

    pub_cfg = state['pubs'][pub_name]
    if not pub_cfg.get('enabled', False):
        log.info(f"⏯️ Publicación '{pub_name}' está desactivada. Saltando.")
        metrics['reason'] = "desactivada"
        await notify_owner(pub_name, start_time, metrics)
        return

    if in_quiet_hours():
        log.info(f"🌙 Saltando publicación '{pub_name}' por Quiet Hours.")
        metrics['reason'] = "quiet_hours"
        await notify_owner(pub_name, start_time, metrics)
        return

    is_dry_run = state.get('dry_run', False)
    if is_dry_run:
        log.info(f"🧪 DRY-RUN activado para '{pub_name}'. Se simularán los envíos.")

    try:
        source_msg = await client.get_messages(pub_cfg['source_chat_id'], ids=pub_cfg['source_msg_id'])
        if not source_msg:
            raise ValueError("Mensaje fuente no encontrado.")
    except Exception as e:
        log.error(f"❌ No se pudo obtener el mensaje fuente para '{pub_name}': {e}")
        metrics['reason'] = f"error_fuente: {e}"
        await notify_owner(pub_name, start_time, metrics)
        return

    policy = pub_cfg.get('send_policy', {})
    
    # Filtrar por tipo
    msg_type = "unknown"
    if source_msg.text: msg_type = "text"
    if source_msg.photo: msg_type = "photo"
    if source_msg.video: msg_type = "video"
    if source_msg.document: msg_type = "document"

    if msg_type not in policy.get('allow_types', ["text","photo","video","document"]):
        log.info(f"🧾 Saltando '{pub_name}' por tipo de mensaje no permitido ('{msg_type}').")
        metrics['reason'] = f"tipo_no_permitido ({msg_type})"
        await notify_owner(pub_name, start_time, metrics)
        return
        
    source_msg._pub_name = pub_name # Inyectar para que send_with_retries pueda acceder a la política
    
    targets = await resolve_targets(pub_cfg)
    random.shuffle(targets)
    metrics['total'] = len(targets)

    if not targets:
        log.warning(f"🎯 No se encontraron destinos para '{pub_name}'.")
        metrics['reason'] = "sin_destinos"
        await notify_owner(pub_name, start_time, metrics)
        return

    semaphore = asyncio.Semaphore(policy.get('max_concurrency', 3))
    limiter = AsyncLimiter(policy.get('rate_limit_per_min', 18), 60)
    delay_range = policy.get('per_target_delay_ms', [800, 3200])
    jitter_pct = policy.get('jitter_pct', 20)

    async def send_to_target(target_id: int):
        if check_dedup(pub_cfg['source_chat_id'], pub_cfg['source_msg_id']):
            log.info(f"[SKIP-DEDUP] {pub_name} -> {target_id}")
            metrics['skipped'] += 1
            return
            
        async with semaphore:
            async with limiter:
                delay_sec = random.uniform(delay_range[0] / 1000, delay_range[1] / 1000)
                jitter_amt = delay_sec * (jitter_pct / 100) * random.uniform(-1, 1)
                await asyncio.sleep(delay_sec + jitter_amt)
                
                log.info(f"✉️ {'[DRY-RUN] ' if is_dry_run else ''}Enviando '{pub_name}' a {target_id}...")
                
                if not is_dry_run:
                    status = await send_with_retries(target_id, source_msg)
                    if status == "ok":
                        metrics['ok'] += 1
                    else:
                        metrics['fail'] += 1
                else: # En Dry-Run simulamos un éxito
                    metrics['ok'] += 1

    await asyncio.gather(*(send_to_target(tid) for tid in targets))

    # Actualizar dedup solo después de que toda la ejecución termine
    update_dedup(pub_cfg['source_chat_id'], pub_cfg['source_msg_id'])
    
    # Deshabilitar si es un job de tipo 'date'
    if pub_cfg.get('schedule', {}).get('type') == 'date':
        log.info(f"🗓️ Deshabilitando publicación de única vez '{pub_name}'.")
        state['pubs'][pub_name]['enabled'] = False
        save_state(state)
        # El job se eliminará automáticamente al no ser reprogramado
        with suppress(Exception):
             scheduler.remove_job(pub_name)

    await notify_owner(pub_name, start_time, metrics)

async def notify_owner(pub_name, start_time, metrics):
    """Envía un resumen de la ejecución al propietario del bot."""
    duration = time.monotonic() - start_time
    is_dry_run = state.get('dry_run', False)

    msg = (
        f"📊 **Resumen de {'DRY-RUN ' if is_dry_run else ''}Publicación**\n\n"
        f"▪️ **Nombre:** `{pub_name}`\n"
        f"✔️ **Éxitos:** `{metrics['ok']}`\n"
        f"❌ **Fallos:** `{metrics['fail']}`\n"
        f"⏭️ **Saltados (dedup):** `{metrics['skipped']}`\n"
        f"🎯 **Total Destinos:** `{metrics['total']}`\n"
        f"⏱️ **Duración:** `{duration:.2f} segundos`\n"
        f"📝 **Motivo finalización:** `{metrics.get('reason', 'completado')}`"
    )
    
    try:
        await bot.send_message(OWNER_ID, msg)
    except Exception as e:
        log.error(f"No se pudo notificar al owner: {e}")


# ==============================================================================
# 4. GESTIÓN DEL SCHEDULER (APScheduler)
# ==============================================================================

def refresh_job(pub_name: str):
    """Añade o actualiza un job en el scheduler según la configuración del estado."""
    global state
    pub_cfg = state['pubs'].get(pub_name)
    if not pub_cfg or not pub_cfg.get('enabled', False):
        with suppress(Exception):
            scheduler.remove_job(pub_name)
        log.info(f"Job para '{pub_name}' eliminado o no programado (deshabilitado).")
        return

    schedule = pub_cfg.get('schedule')
    if not schedule or 'type' not in schedule:
        log.warning(f"No se puede programar '{pub_name}': configuración 'schedule' inválida.")
        return

    job_id = pub_name
    trigger = None
    
    if schedule['type'] == 'interval':
        minutes = schedule.get('minutes')
        if not isinstance(minutes, int) or minutes < 1:
            log.error(f"Intervalo inválido para '{pub_name}'. Debe ser un número entero >= 1.")
            return
        trigger = IntervalTrigger(minutes=minutes)

    elif schedule['type'] == 'date':
        date_str = schedule.get('date')
        try:
            run_date = datetime.fromisoformat(date_str).astimezone(get_tz_info())
            if run_date <= now_in_tz():
                log.warning(f"La fecha para '{pub_name}' ya ha pasado. No se programará.")
                state['pubs'][pub_name]['enabled'] = False # Deshabilitarla
                save_state(state)
                with suppress(Exception):
                    scheduler.remove_job(job_id)
                return
            trigger = DateTrigger(run_date=run_date)
        except (ValueError, TypeError) as e:
            log.error(f"Formato de fecha inválido para '{pub_name}': {date_str} - Error: {e}")
            return
            
    if trigger:
        scheduler.add_job(run_publication, trigger, args=[pub_name], id=job_id, replace_existing=True, misfire_grace_time=60*5)
        log.info(f"✅ Job '{pub_name}' programado/actualizado.")
    else:
        log.warning(f"No se creó un trigger para '{pub_name}'.")

def schedule_all_jobs():
    """Limpia y reprograma todos los jobs basándose en el estado actual."""
    log.info("🗓️ (Re)programando todos los trabajos desde state.json...")
    scheduler.remove_all_jobs()
    for pub_name in state['pubs']:
        refresh_job(pub_name)

# ==============================================================================
# 5. GENERADORES DE INTERFAZ (BOTONES)
# ==============================================================================
def build_main_menu_buttons():
    dry_run_status = "ON 🟢" if state.get('dry_run', False) else "OFF 🔴"
    return [
        [Button.inline("📢 Publicaciones", p_data({"view": "pubs"}))],
        [Button.inline("📋 Listas de Destinos", p_data({"view": "lists"}))],
        [Button.inline("⚙️ Ajustes Generales", p_data({"view": "settings"}))],
        [Button.inline(f"🧪 Dry-Run: {dry_run_status}", p_data({"action": "toggle_dry_run"}))],
        [Button.inline("📊 Estado del Sistema", p_data({"view": "status"}))],
    ]
    
def build_pagination_buttons(view: str, current_page: int, total_pages: int, name: Optional[str] = None):
    buttons = []
    base_data = {"view": view}
    if name:
        base_data["name"] = name

    if current_page > 0:
        buttons.append(Button.inline("◀️", p_data({**base_data, "page": current_page - 1})))
    
    buttons.append(Button.inline(f"Pág {current_page + 1}/{total_pages}", p_data({"action": "noop"})))

    if current_page < total_pages - 1:
        buttons.append(Button.inline("▶️", p_data({**base_data, "page": current_page + 1})))

    return buttons

def build_back_button(view: str, page: int = 0, name: Optional[str] = None):
    data = {"view": view, "page": page}
    if name: data["name"] = name
    return Button.inline("🔙 Atrás", p_data(data))

def build_home_button():
    return Button.inline("🏠 Inicio", p_data({"view": "main"}))

# ==============================================================================
# 6. MANEJADORES DE CALLBACKS Y COMANDOS
# ==============================================================================

@bot.on(events.NewMessage(pattern='/start', from_users=OWNER_ID))
async def start_handler(event):
    await event.respond(
        "**🤖 Bienvenido al Panel de Control de Reenvíos v3**\n\n"
        "Usa los botones de abajo para gestionar tus publicaciones, listas y configuraciones.",
        buttons=build_main_menu_buttons()
    )

@bot.on(events.NewMessage(from_users=OWNER_ID))
async def text_input_handler(event):
    """Manejador para entradas de texto en modo 'wizard'."""
    if event.message.text.lower() == "/cancelar":
        if user_context.pop(OWNER_ID, None):
            await event.respond("Operación cancelada.", buttons=build_main_menu_buttons())
        return

    ctx = user_context.get(OWNER_ID)
    if not ctx: return

    # --- Lógica de contexto aquí ---
    action = ctx.get("action")
    # Lógica de creación de publicación...
    if action == "new_pub_source":
        try:
            parts = event.text.split()
            chat_id = int(parts[0])
            msg_id = int(parts[1])
            await client.get_messages(chat_id, ids=msg_id) # Validar que existe
            user_context[OWNER_ID]['source_chat_id'] = chat_id
            user_context[OWNER_ID]['source_msg_id'] = msg_id
            user_context[OWNER_ID]['action'] = 'new_pub_list_selection'

            text = "✅ Mensaje fuente validado.\n\n**Paso 3/3: Selecciona la lista de destinos**"
            
            list_names = list(state['lists'].keys())
            buttons = [Button.inline(name, p_data({"action":"pub_create_set_list", "name": name})) for name in list_names]
            # Botón especial TODOS
            buttons.insert(0, Button.inline("TODOS (Todos los grupos)", p_data({"action":"pub_create_set_list", "name":"TODOS"})))

            await event.respond(text, buttons=[buttons[i:i+2] for i in range(0, len(buttons), 2)])

        except (ValueError, IndexError):
            await event.respond("❌ Formato incorrecto. Envía `ID_del_chat ID_del_mensaje`.")
        except Exception as e:
            await event.respond(f"❌ No se pudo acceder al mensaje. ¿Estás en el chat? Error: {e}")
            
    # Lógica de gestión de listas
    elif action in ("add_list_ids", "remove_list_ids"):
        list_name = ctx['name']
        try:
            ids_to_process = {int(x) for x in event.text.split()}
            
            if action == "add_list_ids":
                current_ids = set(state['lists'].get(list_name, []))
                new_ids = list(current_ids.union(ids_to_process))
                state['lists'][list_name] = new_ids
                save_state(state)
                await event.respond(f"✅ {len(ids_to_process)} IDs añadidos a la lista '{list_name}'. Total ahora: {len(new_ids)}.")
            else: # remove
                current_ids = set(state['lists'].get(list_name, []))
                kept_ids = list(current_ids.difference(ids_to_process))
                state['lists'][list_name] = kept_ids
                save_state(state)
                await event.respond(f"✅ IDs eliminados de la lista '{list_name}'. Total ahora: {len(kept_ids)}.")
            
            user_context.pop(OWNER_ID, None)
            
            # Volver a la vista de la lista
            data = {"view": "list_view", "name": list_name, "page": 0}
            await callback_handler(await event.respond("...", buttons=Button.clear()), data)


        except ValueError:
            await event.respond("❌ Formato incorrecto. Envía una lista de IDs numéricos separados por espacios.")
    
    # Resto de los contextos (nombre de lista/pub, edición manual, etc.)
    elif action == "new_list_name":
        list_name = event.text.strip()
        if not list_name or list_name in state['lists'] or list_name == "TODOS":
            await event.respond(f"❌ Nombre de lista inválido o ya existe. Intenta de nuevo.")
            return
        state['lists'][list_name] = []
        save_state(state)
        user_context.pop(OWNER_ID, None)
        await event.respond(f"✅ Lista '{list_name}' creada. Ahora puedes añadirle destinos.", buttons=[[
            Button.inline("➕ Agregar IDs", p_data({"view":"list_view", "name":list_name, "action":"add"})),
            build_back_button("lists")
        ]])
    
    elif action == "new_pub_name":
        pub_name = event.text.strip()
        if not pub_name or not pub_name.isalnum() or pub_name in state['pubs']:
            await event.respond(f"❌ Nombre de publicación inválido (solo alfanumérico) o ya existe. Intenta de nuevo.")
            return
            
        user_context[OWNER_ID] = {
            "action": "new_pub_source",
            "pub_name": pub_name
        }
        await event.respond(f"✅ Nombre establecido a '{pub_name}'.\n\n"
                            "**Paso 2/3: Envía la ID del chat y del mensaje a reenviar.**\n"
                            "Formato: `-100123456789 123`")

@bot.on(events.CallbackQuery(from_users=OWNER_ID))
async def main_callback_handler(event):
    """Manejador central para todas las interacciones de botones."""
    data = unp_data(event.data)
    
    # Acciones que no requieren un redibujado de la vista principal
    action = data.get("action")
    if action == "noop":
        await event.answer()
        return
        
    if action == "toggle_dry_run":
        state['dry_run'] = not state.get('dry_run', False)
        save_state(state)
        await event.answer(f"Dry-Run ahora está {'ACTIVADO' if state['dry_run'] else 'DESACTIVADO'}")
        # Redibujar menú principal
        data = {"view": "main"}
    elif action == "reprogram":
        schedule_all_jobs()
        await event.answer("✅ Todos los trabajos han sido reprogramados.", alert=True)
        return
    elif action == 'pub_create_set_list':
        ctx = user_context.get(OWNER_ID)
        if ctx and ctx.get('action') == 'new_pub_list_selection':
            pub_name = ctx['pub_name']
            
            # Crear la publicación con valores por defecto
            new_pub = copy.deepcopy(DEFAULT_STATE['pubs'].get('demo', {})) # Copiar plantilla si existe
            new_pub.update({
                "enabled": True,
                "source_chat_id": ctx['source_chat_id'],
                "source_msg_id": ctx['source_msg_id'],
                "target_list": data['name'],
                "schedule": {"type": "interval", "minutes": 30},
            })
            if 'send_policy' not in new_pub: # Asegurar que exista la policy
                new_pub['send_policy'] = {
                    "per_target_delay_ms": [800, 3200], "jitter_pct": 20, "max_concurrency": 3,
                    "rate_limit_per_min": 18, "max_retries": 3, "retry_backoff_base_s": 2.0,
                    "floodwait_pad_s": 1, "allow_types": ["text","photo","video","document"],
                    "blacklist_chat_ids": [], "whitelist_chat_ids": []
                }
            
            state['pubs'][pub_name] = new_pub
            save_state(state)
            refresh_job(pub_name)
            user_context.pop(OWNER_ID, None)

            await event.edit(f"✅ ¡Publicación '{pub_name}' creada y activada!\n"
                                f"Está programada para ejecutarse cada {new_pub['schedule']['minutes']} minutos en la lista '{data['name']}'.\n\n"
                                "Puedes editar sus detalles desde el menú de publicaciones.",
                                buttons=[[build_home_button(), Button.inline("Ver Pubs", p_data({"view":"pubs"}))]])
            return

    await callback_handler(event, data)

async def callback_handler(event: Union[events.CallbackQuery.Event, Message], data: Dict):
    """Lógica de renderizado de vistas basada en datos decodificados."""
    view = data.get("view")
    page = data.get("page", 0)
    name = data.get("name") # ID/nombre del item
    action = data.get("action")

    text, buttons = "Error: Vista no encontrada", [[build_home_button()]]

    # --- NAVEGACIÓN PRINCIPAL ---
    if view == "main":
        text = "**🤖 Panel de Control de Reenvíos v3**\n\n" \
               "Usa los botones para gestionar el bot."
        buttons = build_main_menu_buttons()

    elif view == "status":
        active_jobs = scheduler.get_jobs()
        next_runs = sorted([job.next_run_time for job in active_jobs if job.next_run_time])
        next_run_str = next_runs[0].strftime('%Y-%m-%d %H:%M:%S %Z') if next_runs else "Ninguno"
        
        text = (f"📊 **Estado del Sistema**\n\n"
                f"▶️ **Publicaciones activas:** `{len([p for p in state['pubs'].values() if p.get('enabled')])}` / `{len(state['pubs'])}`\n"
                f"📋 **Listas de destinos:** `{len(state['lists'])}`\n"
                f"👥 **Grupos totales en listas:** `{sum(len(l) for l in state['lists'].values())}`\n"
                f"⏰ **Próximo disparo programado:** `{next_run_str}`\n"
                f"🧪 **Modo Dry-Run:** `{'ON' if state.get('dry_run') else 'OFF'}`")
        buttons = [[build_back_button("main")]]
    
    # --- PUBLICACIONES ---
    elif view == "pubs":
        if action == "new":
            user_context[OWNER_ID] = {"action": "new_pub_name"}
            await event.edit("📝 **Paso 1/3: Elige un nombre para tu nueva publicación.**\n\n"
                             "Debe ser una sola palabra alfanumérica (ej: `promo_lunes`). "
                             "Puedes escribir `/cancelar` para abortar.",
                             buttons=[[build_back_button("pubs")]])
            return

        pub_names = sorted(list(state['pubs'].keys()))
        if not pub_names:
            text = "📢 No hay publicaciones creadas."
            buttons = [[Button.inline("➕ Crear Primera Publicación", p_data({"view":"pubs", "action":"new"}))],[build_back_button("main")]]
        else:
            items_per_page = 5
            total_pages = (len(pub_names) + items_per_page - 1) // items_per_page
            page = max(0, min(page, total_pages - 1))
            start, end = page * items_per_page, (page + 1) * items_per_page
            
            text = "📢 **Publicaciones (pág. {}/{})**".format(page + 1, total_pages)
            buttons = []
            for pub_name in pub_names[start:end]:
                p_cfg = state['pubs'][pub_name]
                status_icon = "✅" if p_cfg.get('enabled') else "⏸️"
                buttons.append([Button.inline(f"{status_icon} {pub_name}", p_data({"view": "pub_view", "name": pub_name}))])
            
            if total_pages > 1: buttons.append(build_pagination_buttons("pubs", page, total_pages))
            buttons.append([
                Button.inline("➕ Nueva Pub", p_data({"view":"pubs", "action":"new"})),
                build_home_button(),
            ])
            buttons.insert(len(buttons)-1, [build_back_button("main")])


    # --- VISTA DE UNA PUBLICACIÓN ---
    elif view == "pub_view":
        p_cfg = state['pubs'].get(name)
        if not p_cfg:
            text, buttons = "Error: Publicación no encontrada.", [[build_back_button("pubs")]]
        else:
            if action == "toggle":
                p_cfg['enabled'] = not p_cfg.get('enabled', False)
                save_state(state)
                refresh_job(name)
                await event.answer(f"Publicación ahora {'Activada' if p_cfg['enabled'] else 'Pausada'}")
            
            if action == "delete":
                state['pubs'].pop(name, None)
                save_state(state)
                with suppress(Exception): scheduler.remove_job(name)
                await event.answer(f"Publicación '{name}' eliminada.")
                await callback_handler(event, {"view": "pubs", "page": 0})
                return

            status = "✅ Activada" if p_cfg.get('enabled') else "⏸️ Pausada"
            sched = p_cfg.get('schedule', {})
            sched_str = f"{sched.get('type', 'N/A')}: {sched.get('minutes')}m" if sched.get('type') == 'interval' else f"{sched.get('type', 'N/A')}: {sched.get('date', 'N/A')}"
            
            text = (f"👁 **Viendo Publicación: `{name}`**\n\n"
                    f"**Estado:** {status}\n"
                    f"**Fuente:** `{p_cfg['source_chat_id']}` msg `{p_cfg['source_msg_id']}`\n"
                    f"**Destino:** Lista `{p_cfg['target_list']}`\n"
                    f"**Programación:** `{sched_str}`")

            buttons = [
                [
                    Button.inline("✏️ Editar", p_data({"view":"pub_edit", "name":name})),
                    Button.inline("⏯️ Activar/Pausar", p_data({"view":"pub_view", "name":name, "action":"toggle"})),
                ],
                [Button.inline("🗑 Eliminar", p_data({"view":"pub_view", "name":name, "action":"delete"}))],
                [build_back_button("pubs", page=data.get('page', 0))]
            ]

    # ... [Resto de las vistas: pub_edit, lists, list_view, settings]
    elif view == 'lists':
        # (similar a 'pubs', lista paginada de `state['lists']`)
        if action == "new":
            user_context[OWNER_ID] = {"action": "new_list_name"}
            await event.edit("📝 **Elige un nombre para tu nueva lista.**\n\n"
                             "Debe ser una sola palabra. `/cancelar` para abortar.",
                             buttons=[[build_back_button("lists")]])
            return

        list_names = sorted([k for k in state['lists'].keys() if k != "TODOS"])
        if not list_names:
            text = "📋 No hay listas creadas."
            buttons = [[Button.inline("➕ Crear Primera Lista", p_data({"view":"lists", "action":"new"}))],[build_back_button("main")]]
        else:
            text = "📋 **Listas de Destinos**"
            buttons = []
            for list_name in list_names:
                 buttons.append([Button.inline(f"{list_name} ({len(state['lists'][list_name])} IDs)", p_data({"view":"list_view", "name":list_name}))])
            buttons.append([
                Button.inline("➕ Nueva Lista", p_data({"view":"lists", "action":"new"})),
                build_home_button(),
            ])
            buttons.insert(len(buttons)-1, [build_back_button("main")])
    
    elif view == 'list_view':
        # (similar a pub_view, pero para listas. Botones para agregar/quitar/vaciar/eliminar)
        list_name = data['name']
        if list_name not in state['lists'] or list_name == "TODOS":
            text, buttons = "Error: Lista no encontrada o protegida.", [[build_back_button("lists")]]
        else:
            if action == 'delete':
                # No eliminar si alguna pub la usa
                is_used = any(p['target_list'] == list_name for p in state['pubs'].values())
                if is_used:
                    await event.answer("❌ No se puede borrar. La lista está en uso por una publicación.", alert=True)
                else:
                    state['lists'].pop(list_name)
                    save_state(state)
                    await event.answer(f"✅ Lista '{list_name}' eliminada.")
                    await callback_handler(event, {"view":"lists"})
                return

            if action in ('add', 'remove'):
                action_text = "añadir a" if action == 'add' else "quitar de"
                user_context[OWNER_ID] = {"action": f"{action}_list_ids", "name": list_name}
                await event.edit(f"📝 **Envía los IDs que quieres {action_text} la lista `{list_name}`.**\n\n"
                                 "Sepáralos por espacios. Escribe `/cancelar` para volver.", 
                                 buttons=[[build_back_button("list_view", name=list_name)]])
                return

            if action == 'clear':
                state['lists'][list_name] = []
                save_state(state)
                await event.answer("✅ Lista vaciada.")

            ids = state['lists'][list_name]
            # Mostrar preview paginado de IDs
            text = f"👁 **Viendo Lista: `{list_name}`** (`{len(ids)}` IDs)\n\n"
            text += "`" + " ".join(map(str, ids[:20])) + ("...`" if len(ids) > 20 else "`")

            buttons = [
                [
                    Button.inline("➕ Agregar IDs", p_data({"view":"list_view", "name":list_name, "action":"add"})),
                    Button.inline("🗑 Quitar IDs", p_data({"view":"list_view", "name":list_name, "action":"remove"}))
                ],
                [
                    Button.inline("🧹 Vaciar Lista", p_data({"view":"list_view", "name":list_name, "action":"clear"})),
                    Button.inline("❌ Eliminar Lista", p_data({"view":"list_view", "name":list_name, "action":"delete"}))
                ],
                [build_back_button("lists")]
            ]

    elif view == "settings":
        q_h = state['quiet_hours']
        d_ttl = state['dedup_ttl_hours']
        
        text = (f"⚙️ **Ajustes Generales**\n\n"
                f"**🌙 Quiet Hours:** `{q_h['start']} - {q_h['end']} (TZ: {q_h['tz']})`\n"
                f"**♻️ Dedup TTL:** `{d_ttl} horas` (evita reenviar lo mismo)")

        buttons = [
            [Button.inline(f"🌙 Cambiar Quiet Hours (Próximamente)", p_data({"action":"noop"}))],
            [Button.inline(f"♻️ Cambiar Dedup TTL (Próximamente)", p_data({"action":"noop"}))],
            [Button.inline(f"🔁 Forzar Reprogramación de Jobs", p_data({"action":"reprogram"}))],
            [build_back_button("main")]
        ]

    try:
        if isinstance(event, events.CallbackQuery.Event):
            await event.edit(text, buttons=buttons)
        elif isinstance(event, Message):
            # Usado cuando una entrada de texto lleva a una nueva vista
            await event.client.delete_messages(event.chat_id, [event.id, event.reply_to_msg_id])
            await event.client.send_message(event.chat_id, text, buttons=buttons)
    except RPCError as e:
        log.warning(f"Error al editar mensaje (puede ser normal si no hay cambios): {e}")


# ==============================================================================
# 7. FUNCIÓN PRINCIPAL
# ==============================================================================

async def main():
    """Función de arranque principal."""
    try:
        # Conectar el bot primero
        await bot.start(bot_token=BOT_TOKEN)
        log.info("Bot de panel conectado.")

        # Conectar el cliente de usuario
        if not await client.is_user_authorized():
            log.warning("Cliente de usuario no autorizado. Sigue las instrucciones en la consola.")
            await client.send_code_request(os.getenv("PHONE_NUMBER", ""))
            try:
                await client.sign_in(os.getenv("PHONE_NUMBER", ""), input("Introduce el código de Telegram: "))
            except Exception as e:
                 await client.sign_in(password=input("Introduce tu contraseña 2FA: "))

        me = await client.get_me()
        log.info(f"Cliente de usuario conectado como: {me.first_name} (@{me.username})")

        # Iniciar scheduler y programar jobs
        scheduler.start()
        schedule_all_jobs()
        log.info(f"Scheduler iniciado con {len(scheduler.get_jobs())} trabajos.")

        log.info("🚀 Bot listo y escuchando.")
        
    except Exception as e:
        log.critical(f"Error fatal durante el inicio: {e}")
        return

    await bot.run_until_disconnected()


if __name__ == "__main__":
    with client, bot:
        client.loop.run_until_complete(main())