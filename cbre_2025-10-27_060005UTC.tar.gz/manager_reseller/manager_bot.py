# manager_bot.py  — versión integrada con Reseller, límites, visibilidad y facturación
SYSTEMCTL="/usr/bin/systemctl"
import os, json, asyncio, shutil, subprocess, datetime as dt, re, csv
from pathlib import Path
from typing import Dict, Any, Optional
import logging
from telethon import TelegramClient, events, Button
from dotenv import load_dotenv

# ===== Logging =====
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ===== Rutas base parametrizables =====
ROOT = Path.home() / "CLIENTES_BOT_REENVIO"
MANAGER_DIR = Path(os.getenv("MANAGER_DIR", ROOT / "manager"))
TEMPL_DIR = ROOT / "TEMPLATES"
STATEF = Path(os.getenv("STATE_FILE", MANAGER_DIR / "state.json"))
CLIENTS_DIR = ROOT / "clients"
CLIENTS_DIR.mkdir(parents=True, exist_ok=True)

# Plantillas (incluye trial)
TEMPL = {
    "default": TEMPL_DIR / "default",
    "plan_estandar": TEMPL_DIR / "plan_estandar",
    "plan_plus": TEMPL_DIR / "plan_plus",
    "plan_pro": TEMPL_DIR / "plan_pro",
    "plan_trial": TEMPL_DIR / "plan_estandar"
}

# ===== .env =====
load_dotenv(MANAGER_DIR / ".env")
API_ID = int(os.getenv("API_ID", "0"))
API_HASH = os.getenv("API_HASH", "")
BOT_TOKEN = os.getenv("MANAGER_BOT_TOKEN", "")

# ===== State =====
DEFAULT_STATE = {
    "owner_id": 0,
    # nuevo esquema admins como dict; admitir compat con lista
    "admins": {},              # { "123": {slug, role, plan, max_subbots, base_usd, subbot_usd, expires_at} }
    "clients": {},             # { slug: {owner_id, username, plan, parent_admin, expires_at, workdir, created_at} }
    "plans_catalog": {
        "personal":    {"max_subbots":0,  "base_usd":5.0,  "subbot_usd":0.0},
        "reseller_b":  {"max_subbots":3,  "base_usd":10.0, "subbot_usd":3.0},
        "reseller_p":  {"max_subbots":10, "base_usd":20.0, "subbot_usd":2.5},
        "enterprise":  {"max_subbots":-1, "base_usd":30.0, "subbot_usd":2.0}
    },
    "last_expiry_check": None
}

def load_state() -> Dict[str, Any]:
    MANAGER_DIR.mkdir(parents=True, exist_ok=True)
    if not STATEF.exists():
        STATEF.write_text(json.dumps(DEFAULT_STATE, indent=2))
        return json.loads(STATEF.read_text())
    S = json.loads(STATEF.read_text())
    # compat: si admins es lista -> migrar a dict
    if isinstance(S.get("admins", {}), list):
        mig = {}
        for aid in S["admins"]:
            mig[str(aid)] = {
                "slug": f"adm{aid}",
                "role": "reseller",
                "plan": "personal",
                "max_subbots": 0,
                "base_usd": 5.0,
                "subbot_usd": 0.0,
                "expires_at": (dt.date.today()+dt.timedelta(days=30)).isoformat()
            }
        S["admins"] = mig
    # asegurar catálogo
    if "plans_catalog" not in S:
        S["plans_catalog"] = DEFAULT_STATE["plans_catalog"]
    return S

def save_state(S: Dict[str, Any]):
    STATEF.write_text(json.dumps(S, indent=2, ensure_ascii=False))

S = load_state()

# ===== Helpers permisos/planes =====
def is_owner(uid: int) -> bool:
    return uid == S.get("owner_id", 0)

def is_any_admin(uid: int) -> bool:
    return is_owner(uid) or str(uid) in S.get("admins", {})

def ensure_admin_stub(uid: int):
    if is_owner(uid): return
    A = S["admins"].get(str(uid))
    if not A:
        S["admins"][str(uid)] = {
            "slug": f"adm{uid}",
            "role": "reseller",
            "plan": "personal",
            "max_subbots": 0,
            "base_usd": 5.0,
            "subbot_usd": 0.0,
            "expires_at": (dt.date.today()+dt.timedelta(days=30)).isoformat()
        }
        save_state(S)

def plan_caps(plan_key: str):
    P = S["plans_catalog"][plan_key]
    return P["max_subbots"], P["base_usd"], P["subbot_usd"]

def apply_plan_to_admin(admin_id: int, plan_key: str, extend_days: Optional[int]=None):
    mx, baseu, subu = plan_caps(plan_key)
    A = S["admins"].setdefault(str(admin_id), {
        "slug": f"adm{admin_id}",
        "role": "reseller",
        "plan": plan_key,
        "max_subbots": 0, "base_usd": 0.0, "subbot_usd": 0.0,
        "expires_at": dt.date.today().isoformat()
    })
    A.update({"plan": plan_key, "max_subbots": mx, "base_usd": baseu, "subbot_usd": subu})
    if extend_days:
        try:
            cur = dt.date.fromisoformat(A.get("expires_at", dt.date.today().isoformat()))
        except:
            cur = dt.date.today()
        A["expires_at"] = (max(cur, dt.date.today()) + dt.timedelta(days=extend_days)).isoformat()
    save_state(S)

def visible_clients_for(uid: int):
    if is_owner(uid): 
        return list(S["clients"].keys())
    return [slug for slug, c in S["clients"].items() if c.get("parent_admin")==uid]

def count_subbots(uid: int): 
    return len(visible_clients_for(uid))

# ===== Utilidades previas (sin cambios funcionales) =====
def run(cmd: str):
    p = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode != 0:
        raise RuntimeError(f"RC={p.returncode} CMD={cmd}\nSTDOUT:\n{p.stdout}\nSTDERR:\n{p.stderr}")
    return p.stdout

def slugify_from_user(entity) -> str:
    if getattr(entity, "username", None):
        return re.sub(r"[^a-zA-Z0-9_]+", "", entity.username)[:32] or f"tenant{entity.id}"
    return f"tenant{entity.id}"

def slugify_text(txt: str) -> str:
    t = txt.strip()
    if t.startswith("@"):
        t = t[1:]
    return re.sub(r"[^a-zA-Z0-9_]+", "", t)[:32] or "tenant"

def fmt_date(d: dt.date) -> str:
    return d.isoformat()

def parse_days(btag: bytes) -> Optional[int]:
    if btag and btag.startswith(b"dur:"):
        val = btag.split(b":", 1)[1]
        if val == b"cancel":
            return None
        try:
            return int(val.decode())
        except:
            return None
    return None

def kb_clients(prefix: str, uid: Optional[int]=None):
    # si uid dado, filtrar visibilidad
    clist = visible_clients_for(uid) if uid else sorted(S["clients"].keys())
    rows, row = [], []
    for slug in sorted(clist):
        row.append(Button.inline(f"👤 {slug}", f"{prefix}:{slug}".encode()))
        if len(row) == 2:
            rows.append(row); row = []
    if row: rows.append(row)
    rows.append([Button.inline("❌ Cancelar", f"{prefix}:cancel".encode())])
    return rows

def clone_template(plan: str, workdir: Path):
    if plan not in TEMPL:
        raise RuntimeError(f"❌ Plan inválido: {plan}")
    if workdir.exists():
        shutil.rmtree(workdir)
    shutil.copytree(TEMPL[plan], workdir)

def ensure_venv_and_requirements(workdir: Path):
    venv = workdir / "venv"
    if not venv.exists():
        run(f"python3 -m venv '{venv}'")
        run(f"'{venv}/bin/pip' install --upgrade pip")
    req = workdir / "requirements.txt"
    if req.exists():
        run(f"'{venv}/bin/pip' install -r '{req}'")
    else:
        run(f"'{venv}/bin/pip' install telethon==1.36.0 python-dotenv==1.0.1 requests==2.32.3")

def write_env(workdir: Path, *, bot_token: str, owner_id: int, slug: str,
              tz: str = "UTC", qstart: str = "00:30", qend: str = "07:00"):
    apid, apih = API_ID, API_HASH
    tpl_env = workdir / ".env"
    if tpl_env.exists():
        try:
            from dotenv import dotenv_values
            vals = dotenv_values(tpl_env)
            apid = int(vals.get("API_ID", apid) or apid)
            apih = vals.get("API_HASH", apih) or apih
        except:
            pass
    ENV = f"""API_ID={apid}
API_HASH={apih}
BOT_TOKEN={bot_token}
OWNER_ID={owner_id}
USER_SESSION={slug}_user
BOT_SESSION={slug}panel
STATE_FILE=state{slug}.json
TIMEZONE={tz}
QUIET_START={qstart}
QUIET_END={qend}
"""
    (workdir / ".env").write_text(ENV)

def force_load_dotenv_override(workdir: Path):
    py = workdir / "telethon_userbot_listas_publicaciones.py"
    if not py.exists(): return
    txt = py.read_text()
    if "load_dotenv(" in txt and "override=True" in txt: return
    if "load_dotenv" not in txt:
        txt = ("from pathlib import Path as _P\nfrom dotenv import load_dotenv\n"
               "load_dotenv(dotenv_path=_P(__file__).with_name('.env'), override=True)\n") + txt
    else:
        txt = re.sub(r"load_dotenv\((.*?)\)", r"load_dotenv(\1, override=True)", txt, count=1, flags=re.S)
    py.write_text(txt)

def enable_instance_service(slug: str):
    run("sudo -n /usr/bin/systemctl daemon-reload")
    run(f"sudo -n /usr/bin/systemctl enable --now 'reenvio@{slug}.service'")

def disable_instance_service(slug: str):
    run(f"sudo -n /usr/bin/systemctl disable --now 'reenvio@{slug}.service' || true")

def pause_instance_service(slug: str):
    run(f"sudo -n /usr/bin/systemctl stop 'reenvio@{slug}.service' || true")

def resume_instance_service(slug: str):
    run(f"sudo -n /usr/bin/systemctl start 'reenvio@{slug}.service' || true")

def _svc_status(svc: str) -> str:
    try:
        out = subprocess.run(["systemctl", "is-active", svc],
                             stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, check=False).stdout.strip()
        return "active" if out == "active" else out or "unknown"
    except Exception:
        return "unknown"

def _get_bot_meta(token: str) -> dict:
    try:
        import requests
        r = requests.get(f"https://api.telegram.org/bot{token}/getMe", timeout=6)
        j = r.json()
        if j.get("ok"):
            res = j.get("result", {})
            return {"ok": True, "username": res.get("username"), "id": res.get("id")}
        return {"ok": False, "username": None, "id": None}
    except Exception:
        return {"ok": False, "username": None, "id": None}

def _read_env(workdir: Path) -> dict:
    envp = workdir / ".env"
    out = {}
    if not envp.exists(): return out
    for line in envp.read_text().splitlines():
        if "=" in line and not line.strip().startswith("#"):
            k, v = line.split("=", 1)
            out[k.strip()] = v.strip()
    return out

def uniq_slug(base: str) -> str:
    base = base.strip().lstrip("@")
    base = re.sub(r"[^a-zA-Z0-9]+", "", base) or "cliente"
    slug = base; n = 2
    while slug in S.get("clients", {}):
        slug = f"{base}{n}"; n += 1
    return slug

# ===== Bot Manager =====
bot = TelegramClient("manager_bot", API_ID, API_HASH)

# ===== Notificaciones de expiración =====
async def check_expiring_plans():
    try:
        current_state = load_state()
        tomorrow = (dt.date.today() + dt.timedelta(days=1)).isoformat()
        today = dt.date.today().isoformat()

        for slug, client_info in current_state.get("clients", {}).items():
            expires_at = client_info.get("expires_at")
            owner_id = client_info.get("owner_id")
            if not expires_at or not owner_id: continue
            if expires_at == tomorrow:
                await send_expiry_notification(slug, client_info, "warning")
            elif expires_at <= today:
                await handle_expired_service(slug, client_info)

        current_state["last_expiry_check"] = dt.datetime.now().isoformat()
        save_state(current_state)
    except Exception as e:
        logger.error(f"check_expiring_plans: {e}")

async def send_expiry_notification(slug: str, client_info: dict, notification_type: str):
    try:
        owner_id = client_info.get("owner_id")
        expires_at = client_info.get("expires_at")
        plan = client_info.get("plan", "plan_estandar")
        workdir = Path(client_info.get("workdir", ""))
        env = _read_env(workdir)
        token = env.get("BOT_TOKEN", "")
        bot_meta = _get_bot_meta(token) if token else {"username": None, "id": None}
        svc = f"reenvio@{slug}.service"
        status = _svc_status(svc); status_emoji = "🟢" if status == "active" else "🔴"

        if notification_type == "warning":
            message = (f"⚠️ **AVISO DE VENCIMIENTO**\n\n"
                       f"🎫 Plan: {plan}\n📅 Vence mañana: {expires_at}\n{status_emoji} Servicio: {status}\n"
                       f"🤖 Bot: @{bot_meta.get('username','N/A')}\n\n"
                       f"📞 Renueva con: @frankosmel")
            keyboard = [[Button.url("💬 Contactar @frankosmel", "https://t.me/frankosmel")],
                        [Button.inline("📊 Ver estado", f"status:{slug}".encode())]]
        else:
            message = (f"🔴 **SERVICIO PAUSADO**\n\n🎫 Plan: {plan}\n📅 Venció: {expires_at}\n"
                       f"⏸️ Estado: pausado\n🤖 Bot: @{bot_meta.get('username','N/A')}\n\n📞 @frankosmel")
            keyboard = [[Button.url("💬 Renovar con @frankosmel", "https://t.me/frankosmel")]]

        await bot.send_message(owner_id, message, buttons=keyboard)
        logger.info(f"Notificado {notification_type} → {owner_id} ({slug})")
    except Exception as e:
        logger.error(f"send_expiry_notification: {e}")

async def handle_expired_service(slug: str, client_info: dict):
    try:
        svc = f"reenvio@{slug}.service"
        status = _svc_status(svc)
        if status == "active":
            pause_instance_service(slug)
            logger.info(f"{svc} pausado por expiración")
            await send_expiry_notification(slug, client_info, "expired")
    except Exception as e:
        logger.error(f"handle_expired_service {slug}: {e}")

async def expiry_checker_task():
    while True:
        try:
            await asyncio.sleep(3600)
            await check_expiring_plans()
        except Exception as e:
            logger.error(f"expiry_checker_task: {e}")
            await asyncio.sleep(300)

# ===== Comandos existentes: /start =====
@bot.on(events.NewMessage(pattern=r'^/start$'))
async def start_cmd(ev):
    uid = ev.sender_id
    if is_any_admin(uid):
        await ev.reply(
            "🤖 **Bot Manager**\n\n"
            "🛠️ **Comandos de Admin:**\n"
            "• `/set_owner <id>`\n"
            "• `/admins`\n"
            "• `/admin_add <id>`\n"
            "• `/admin_rm <id>`\n"
            "• `/clients`\n"
            "• `/client <slug>`\n"
            "• `/auth`\n"
            "• `/renew`\n"
            "• `/edit_plan`\n"
            "• `/revoke`\n"
            "• `/upgrade <slug>`\n"
            "• `/upgrade_all`\n"
            "• `/reseller`  ← menú nuevo\n"
            "• `/invoice <admin_id>` ← facturación\n"
        )
    else:
        my = None
        for slug, c in S["clients"].items():
            if c.get("owner_id") == uid:
                my = (slug, c); break
        if my:
            slug, c = my
            exp = c.get("expires_at", "N/A")
            plan = c.get("plan", "N/A")
            svc = f"reenvio@{slug}.service"
            status = _svc_status(svc)
            status_emoji = "🟢" if status == "active" else "🔴"
            await ev.reply(
                f"👋 **Bienvenido**\n\n🎫 Plan: {plan}\n📅 Vence: {exp}\n{status_emoji} Servicio: {status}\n🔧 ID: {slug}\n\n"
                "• `/provision`\n• `/status`"
            )
        else:
            await ev.reply("No autorizado. Contacta @frankosmel. Trial 7 días disponible.")

# ===== Admin management original con compat =====
@bot.on(events.NewMessage(pattern=r'^/set_owner\s+(\d+)$'))
async def set_owner(ev):
    if S.get("owner_id", 0) not in (0, ev.sender_id): return
    S["owner_id"] = int(ev.pattern_match.group(1)); save_state(S)
    await ev.reply(f"Owner: `{S['owner_id']}`")

@bot.on(events.NewMessage(pattern=r'^/admins$'))
async def admins_list(ev):
    if not is_any_admin(ev.sender_id): return
    owner = S.get("owner_id", 0)
    lines = [f"👑 Owner: `{owner}`", "", "👮 Admins:"]
    if S["admins"]:
        for aid, a in S["admins"].items():
            lines.append(f"• {a['slug']} ({aid}) · plan={a['plan']} · exp={a['expires_at']}")
    else:
        lines.append("—")
    await ev.reply("\n".join(lines))

@bot.on(events.NewMessage(pattern=r'^/admin_add\s+(\d+)$'))
async def admin_add(ev):
    if not is_any_admin(ev.sender_id): return
    aid = int(ev.pattern_match.group(1))
    ensure_admin_stub(aid); save_state(S)
    await ev.reply(f"Admin agregado: `{aid}`")

@bot.on(events.NewMessage(pattern=r'^/admin_rm\s+(\d+)$'))
async def admin_rm(ev):
    if not is_any_admin(ev.sender_id): return
    aid = int(ev.pattern_match.group(1))
    # bloquear si tiene clientes
    has_clients = any(c.get("parent_admin")==aid for c in S["clients"].values())
    if has_clients: 
        await ev.reply("Primero reasigna o elimina sus clientes.")
        return
    S["admins"].pop(str(aid), None); save_state(S)
    await ev.reply(f"Admin removido: `{aid}`")

# ===== Listado de clientes con visibilidad =====
@bot.on(events.NewMessage(pattern=r'^/clients$'))
async def clients_list(ev):
    if not is_any_admin(ev.sender_id): return
    cl = visible_clients_for(ev.sender_id)
    if not cl:
        await ev.reply("📭 No hay clientes visibles")
        return
    lines = ["👥 **Clientes:**\n"]
    for slug in sorted(cl):
        c = S["clients"][slug]
        uname = c.get("username") or f"ID:{c.get('owner_id','?')}"
        plan = c.get("plan", "N/A")
        svc = f"reenvio@{slug}.service"
        st = _svc_status(svc); status_emoji = "🟢" if st == "active" else "🔴"
        exp = c.get("expires_at", "?")
        lines.append(f"{status_emoji} **{slug}** - @{uname} - {plan} - vence {exp}")
    await ev.reply("\n".join(lines))

@bot.on(events.NewMessage(pattern=r'^/client\s+(\S+)$'))
async def client_detail(ev):
    if not is_any_admin(ev.sender_id): return
    slug = ev.pattern_match.group(1).strip()
    c = S.get("clients", {}).get(slug)
    if not c: return await ev.reply(f"No existe `{slug}`")
    # permiso: reseller solo sus clientes
    if not is_owner(ev.sender_id) and c.get("parent_admin")!=ev.sender_id:
        await ev.reply("Sin permiso sobre este cliente.")
        return
    workdir = Path(c.get("workdir","")); env = _read_env(workdir)
    token = env.get("BOT_TOKEN",""); token_short = token[:12]+"..." if token else "_(no configurado)_"
    svc = f"reenvio@{slug}.service"; st = _svc_status(svc); status_emoji = "🟢" if st=="active" else "🔴"
    bot_meta = _get_bot_meta(token) if token else {"ok":False,"username":None,"id":None}
    lines = [
        f"📋 {slug}",
        f"Propietario: `{c.get('owner_id','?')}` (@{c.get('username','N/A')})",
        f"Plan: {c.get('plan','N/A')}",
        f"Parent admin: {c.get('parent_admin','—')}",
        f"Vence: {c.get('expires_at','?')}",
        f"Dir: `{workdir}`",
        f"{status_emoji} Servicio: `{svc}` → {st}",
        f"Bot Token: `{token_short}`",
        f"Bot Username: @{bot_meta.get('username','desconocido')}",
        f"Bot ID: `{bot_meta.get('id','?')}`",
        f"Creado: {c.get('created_at','N/A')}"
    ]
    await ev.reply("\n".join(lines))

# ===== Teclados comunes =====
def kb_durations():
    return [
        [Button.inline("🎁 7 días (TRIAL)", b"dur:7")],
        [Button.inline("📅 30 días", b"dur:30"), Button.inline("📅 90 días", b"dur:90")],
        [Button.inline("📅 365 días", b"dur:365")],
        [Button.inline("❌ Cancelar", b"dur:cancel")]
    ]

def kb_plans_clients():
    return [
        [Button.inline("🎁 Trial", b"plan:plan_trial")],
        [Button.inline("📦 Estándar", b"plan:plan_estandar"), Button.inline("⭐ Plus", b"plan:plan_plus")],
        [Button.inline("👑 Pro", b"plan:plan_pro")],
        [Button.inline("❌ Cancelar", b"plan:cancel")]
    ]

def kb_reseller_plans():
    k = []
    for key in ["personal","reseller_b","reseller_p","enterprise"]:
        p = S["plans_catalog"][key]
        label = f"{key} · base ${p['base_usd']} + sub ${p['subbot_usd']} · max {('∞' if p['max_subbots']<0 else p['max_subbots'])}"
        k.append([Button.inline(label, f"rplan:{key}".encode())])
    k.append([Button.inline("❌ Cancelar", b"rplan:cancel")])
    return k

# ===== AUTH (autorizar cliente) con límites por reseller =====
flows: Dict[int, Dict[str, Any]] = {}

@bot.on(events.NewMessage(pattern=r'^/auth$'))
async def auth_start(ev):
    if not is_any_admin(ev.sender_id): return
    flows[ev.sender_id] = {"mode":"auth","await":"target","target_id":None,"target_username":None}
    await ev.reply("Autorizar cliente\nEnvíe @usuario, ID o reenvíe un mensaje.\n/cancel para salir.")

@bot.on(events.NewMessage)
async def auth_capture_user(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode")!="auth" or f.get("await")!="target": return
    if not is_any_admin(ev.sender_id): return
    raw = (ev.raw_text or "").strip()
    if raw.startswith("/"):
        if raw == "/cancel":
            flows.pop(ev.sender_id, None); await ev.reply("Cancelado")
        return
    uid, uname = None, None
    try:
        fwd = getattr(ev.message, "fwd_from", None)
        if fwd and getattr(getattr(fwd, "from_id", None), "user_id", None):
            uid = int(fwd.from_id.user_id)
    except: pass
    if uid is None:
        try:
            if raw.isdigit():
                uid = int(raw)
            else:
                ent = await ev.client.get_entity(raw)
                uid = int(getattr(ent, "id", 0)); uname = getattr(ent, "username", None)
        except:
            await ev.reply("No pude resolver. Formatos: @user, 123, o reenvío.")
            return
    f["target_id"] = uid; f["target_username"] = uname; f["await"] = "plan"
    await ev.reply(f"Cliente OK\nID: `{uid}`\n@{uname or 'N/A'}\nElige plan:", buttons=kb_plans_clients())

@bot.on(events.CallbackQuery)
async def auth_pick_plan(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode")!="auth" or f.get("await")!="plan": return
    if not is_any_admin(ev.sender_id): return
    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("plan:"): return
    plan = data.split(":",1)[1]
    if plan == "cancel":
        flows.pop(ev.sender_id, None)
        try: await ev.edit("Cancelado")
        except: pass
        return
    # límite de sub-bots si es reseller
    if not is_owner(ev.sender_id):
        A = S["admins"].get(str(ev.sender_id))
        if not A: 
            await ev.answer("No eres admin.", alert=True); return
        mx = A["max_subbots"]
        if mx >= 0 and count_subbots(ev.sender_id) >= mx:
            await ev.answer(f"Límite alcanzado ({mx}). Mejora tu plan.", alert=True)
            return
    f["plan"] = plan
    # trial → 7 días directos
    if plan == "plan_trial":
        await auth_finalize(ev, f, 7); return
    f["await"] = "days"
    try:
        await ev.edit(f"Plan: {plan}\nElige duración:", buttons=kb_durations())
    except:
        await ev.respond(f"Plan: {plan}\nElige duración:", buttons=kb_durations())

@bot.on(events.CallbackQuery)
async def auth_pick_days(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode")!="auth" or f.get("await")!="days": return
    if not is_any_admin(ev.sender_id): return
    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("dur:"): return
    val = data.split(":",1)[1]
    if val == "cancel":
        flows.pop(ev.sender_id, None)
        try: await ev.edit("Cancelado")
        except: pass
        return
    try: days = int(val)
    except: await ev.answer("Duración inválida", alert=True); return
    await auth_finalize(ev, f, days)

async def auth_finalize(ev, f, days):
    tgt_id = f.get("target_id"); tgt_un = f.get("target_username")
    plan = f.get("plan","plan_estandar")
    slug = uniq_slug(tgt_un or str(tgt_id))
    exp_date = (dt.date.today() + dt.timedelta(days=days)).isoformat()
    parent_admin = ev.sender_id if not is_owner(ev.sender_id) else None
    S.setdefault("clients", {})[slug] = {
        "owner_id": tgt_id, "username": tgt_un, "plan": plan,
        "parent_admin": parent_admin,
        "expires_at": exp_date, "workdir": str(CLIENTS_DIR / slug),
        "created_at": dt.datetime.now().isoformat(timespec="seconds")
    }
    save_state(S); flows.pop(ev.sender_id, None)
    try:
        await ev.edit(f"Cliente creado\nPlan: {plan}\nSlug: `{slug}`\nVálido hasta: {exp_date}\nDir: `{CLIENTS_DIR / slug}`")
    except:
        await ev.respond(f"Cliente creado\nPlan: {plan}\nSlug: `{slug}`\nVálido hasta: {exp_date}\nDir: `{CLIENTS_DIR / slug}`")
    # notificar cliente
    try:
        if plan == "plan_trial":
            welcome = (f"Trial 7 días activo\nVence: {exp_date}\nID: `{slug}`\nUsa /provision para iniciar.")
        else:
            welcome = (f"Acceso activo\nPlan: {plan}\nVence: {exp_date}\nID: `{slug}`\nUsa /provision para iniciar.")
        await bot.send_message(tgt_id, welcome)
    except: pass

# ===== Renovación (filtrada por visibilidad) =====
@bot.on(events.NewMessage(pattern=r'^/renew$'))
async def renew_start(ev):
    if not is_any_admin(ev.sender_id): return
    if not visible_clients_for(ev.sender_id): 
        return await ev.reply("No hay clientes para renovar")
    flows[ev.sender_id] = {"mode":"renew","await":"client"}
    await ev.reply("Renovar cliente:\nElige:", buttons=kb_clients("renew", uid=ev.sender_id))

@bot.on(events.CallbackQuery)
async def renew_pick_client(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode")!="renew" or f.get("await")!="client": return
    if not is_any_admin(ev.sender_id): return
    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("renew:"): return
    slug = data.split(":",1)[1]
    if slug == "cancel":
        flows.pop(ev.sender_id, None)
        try: await ev.edit("Cancelado")
        except: pass
        return
    c = S["clients"].get(slug)
    if not c: return await ev.answer("No encontrado", alert=True)
    if not is_owner(ev.sender_id) and c.get("parent_admin")!=ev.sender_id:
        await ev.answer("Sin permiso", alert=True); return
    f["slug"] = slug; f["await"]="days"
    try:
        await ev.edit(f"Renovar `{slug}`\nVence: {c.get('expires_at','N/A')}\nDuración:", buttons=kb_durations())
    except:
        await ev.respond(f"Renovar `{slug}`\nVence: {c.get('expires_at','N/A')}\nDuración:", buttons=kb_durations())

@bot.on(events.CallbackQuery)
async def renew_pick_days(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode")!="renew" or f.get("await")!="days": return
    if not is_any_admin(ev.sender_id): return
    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("dur:"): return
    val = data.split(":",1)[1]
    if val == "cancel":
        flows.pop(ev.sender_id, None)
        try: await ev.edit("Cancelado")
        except: pass
        return
    try: days = int(val)
    except: await ev.answer("Duración inválida", alert=True); return
    slug = f["slug"]; new_exp = (dt.date.today() + dt.timedelta(days=days)).isoformat()
    S["clients"][slug]["expires_at"] = new_exp; save_state(S); flows.pop(ev.sender_id, None)
    try: resume_instance_service(slug)
    except: pass
    try:
        await ev.edit(f"Renovado\nCliente: `{slug}`\nNueva fecha: {new_exp}\nServicio reactivado.")
    except:
        await ev.respond(f"Renovado\nCliente: `{slug}`\nNueva fecha: {new_exp}\nServicio reactivado.")
    try:
        client = S["clients"][slug]
        await bot.send_message(client["owner_id"], f"Plan renovado.\nVálido hasta: {new_exp}\nServicio activo.")
    except: pass

# ===== Cambio de plan (filtrado) =====
def kb_plans():
    return kb_plans_clients()

@bot.on(events.NewMessage(pattern=r'^/edit_plan$'))
async def edit_plan_start(ev):
    if not is_any_admin(ev.sender_id): return
    if not visible_clients_for(ev.sender_id):
        return await ev.reply("No hay clientes")
    flows[ev.sender_id] = {"mode":"edit_plan","await":"client"}
    await ev.reply("Cambiar plan:\nElige cliente:", buttons=kb_clients("edit_plan", uid=ev.sender_id))

@bot.on(events.CallbackQuery)
async def edit_plan_pick_client(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode")!="edit_plan" or f.get("await")!="client": return
    if not is_any_admin(ev.sender_id): return
    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("edit_plan:"): return
    slug = data.split(":",1)[1]
    if slug == "cancel":
        flows.pop(ev.sender_id, None)
        try: await ev.edit("Cancelado")
        except: pass
        return
    c = S["clients"].get(slug)
    if not c: return await ev.answer("No encontrado", alert=True)
    if not is_owner(ev.sender_id) and c.get("parent_admin")!=ev.sender_id:
        await ev.answer("Sin permiso", alert=True); return
    f["slug"]=slug; f["await"]="plan"
    try:
        await ev.edit(f"Cambiar plan `{slug}`\nActual: {c.get('plan','N/A')}\nNuevo:", buttons=kb_plans())
    except:
        await ev.respond(f"Cambiar plan `{slug}`\nActual: {c.get('plan','N/A')}\nNuevo:", buttons=kb_plans())

@bot.on(events.CallbackQuery)
async def edit_plan_pick_plan(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode")!="edit_plan" or f.get("await")!="plan": return
    if not is_any_admin(ev.sender_id): return
    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("plan:"): return
    plan = data.split(":",1)[1]
    if plan == "cancel":
        flows.pop(ev.sender_id, None)
        try: await ev.edit("Cancelado")
        except: pass
        return
    slug = f["slug"]; old = S["clients"][slug].get("plan","N/A")
    S["clients"][slug]["plan"] = plan; save_state(S); flows.pop(ev.sender_id, None)
    try:
        await ev.edit(f"Plan actualizado\nCliente: `{slug}`\nDe: {old} → {plan}\nUsar `/provision` para aplicar plantilla.")
    except:
        await ev.respond(f"Plan actualizado\nCliente: `{slug}`\nDe: {old} → {plan}\nUsar `/provision` para aplicar plantilla.")
    try:
        client = S["clients"][slug]
        await bot.send_message(client["owner_id"], f"Tu plan cambió a {plan}. Ejecuta /provision para aplicar.")
    except: pass

# ===== Revocar (filtrado) =====
@bot.on(events.NewMessage(pattern=r'^/revoke$'))
async def revoke_start(ev):
    if not is_any_admin(ev.sender_id): return
    if not visible_clients_for(ev.sender_id): 
        return await ev.reply("No hay clientes")
    flows[ev.sender_id] = {"mode":"revoke","await":"client"}
    await ev.reply("Revocar acceso:\nElige cliente:", buttons=kb_clients("revoke", uid=ev.sender_id))

@bot.on(events.CallbackQuery)
async def revoke_pick_client(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode")!="revoke" or f.get("await")!="client": return
    if not is_any_admin(ev.sender_id): return
    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("revoke:"): return
    slug = data.split(":",1)[1]
    if slug == "cancel":
        flows.pop(ev.sender_id, None)
        try: await ev.edit("Cancelado")
        except: pass
        return
    c = S["clients"].get(slug)
    if not c: return await ev.answer("No encontrado", alert=True)
    if not is_owner(ev.sender_id) and c.get("parent_admin")!=ev.sender_id:
        await ev.answer("Sin permiso", alert=True); return
    try: disable_instance_service(slug)
    except Exception as e: logger.error(f"disable {slug}: {e}")
    info = S["clients"].pop(slug); save_state(S); flows.pop(ev.sender_id, None)
    try:
        await ev.edit(f"Cliente eliminado `{slug}`\nServicio detenido `reenvio@{slug}.service`\nDir preservado: `{info.get('workdir','N/A')}`")
    except:
        await ev.respond(f"Cliente eliminado `{slug}`\nServicio detenido `reenvio@{slug}.service`\nDir preservado: `{info.get('workdir','N/A')}`")
    try:
        await bot.send_message(info["owner_id"], "Tu acceso ha sido revocado. Contacta @frankosmel.")
    except: pass

# ===== Cliente: provisión y status (inalterado salvo mínimos) =====
@bot.on(events.NewMessage(pattern=r'^/provision$'))
async def provision_start(ev):
    cid = ev.sender_id
    my = None
    for slug, c in S["clients"].items():
        if c.get("owner_id") == cid:
            my = (slug, c); break
    if not my:
        return await ev.reply("No autorizado. Contacta @frankosmel.")
    slug, c = my; plan = c.get("plan","plan_estandar")
    expires_at = c.get("expires_at")
    if expires_at and expires_at <= dt.date.today().isoformat():
        return await ev.reply(f"Tu plan venció ({expires_at}). Contacta @frankosmel.")
    flows[cid] = {"mode":"provision","slug":slug,"plan":plan,"await":"token"}
    plan_emoji = {"plan_trial":"🎁","plan_estandar":"📦","plan_plus":"⭐","plan_pro":"👑"}.get(plan,"📦")
    await ev.reply(f"Configurar bot\n{plan_emoji} Plan: {plan}\nID: `{slug}`\nVence: {c.get('expires_at','N/A')}\n\nPaso 1/2: envía BOT_TOKEN")
    raise events.StopPropagation

@bot.on(events.NewMessage(pattern=r'^/status$'))
async def status_cmd(ev):
    cid = ev.sender_id
    my = None
    for slug, c in S["clients"].items():
        if c.get("owner_id") == cid:
            my = (slug, c); break
    if not my: return await ev.reply("No autorizado.")
    slug, c = my
    plan = c.get("plan","N/A"); expires_at = c.get("expires_at","N/A"); workdir = Path(c.get("workdir",""))
    svc = f"reenvio@{slug}.service"; status = _svc_status(svc); status_emoji = "🟢" if status=="active" else "🔴"
    env = _read_env(workdir); token = env.get("BOT_TOKEN","")
    bot_meta = _get_bot_meta(token) if token else {"username": None, "id": None}
    is_expired = expires_at <= dt.date.today().isoformat() if expires_at!="N/A" else False
    plan_emoji = {"plan_trial":"🎁","plan_estandar":"📦","plan_plus":"⭐","plan_pro":"👑"}.get(plan,"📦")
    lines = [f"📊 Estado", f"{plan_emoji} Plan: {plan}", f"ID: `{slug}`", f"Vence: {expires_at}" + (" ⚠️ VENCIDO" if is_expired else ""),
             f"{status_emoji} Servicio: {status}", f"Bot: @{bot_meta.get('username','No configurado')}", f"Dir: `{workdir}`"]
    keyboard=[]
    if not is_expired and status!="active":
        keyboard.append([Button.inline("🔄 Reiniciar servicio", f"restart:{slug}".encode())])
    keyboard.append([Button.url("💬 Soporte", "https://t.me/frankosmel")])
    await ev.reply("\n".join(lines), buttons=keyboard if keyboard else None)

@bot.on(events.CallbackQuery)
async def handle_restart_service(ev):
    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("restart:"): return
    slug = data.split(":",1)[1]
    cid = ev.sender_id
    client = S.get("clients", {}).get(slug)
    if not client or client.get("owner_id") != cid:
        await ev.answer("No tienes permisos", alert=True); return
    try:
        resume_instance_service(slug); await ev.answer("Servicio reiniciado", alert=True)
        status = _svc_status(f"reenvio@{slug}.service"); status_emoji = "🟢" if status=="active" else "🔴"
        try: await ev.edit(f"Reiniciado\n{status_emoji} Estado: {status}")
        except: pass
    except Exception as e:
        await ev.answer(f"Error: {str(e)[:60]}", alert=True)

@bot.on(events.NewMessage)
async def provision_flow(ev):
    f = flows.get(ev.sender_id)
    if not f or f.get("mode")!="provision" or f.get("await")!="token": return
    raw = (ev.raw_text or "").strip()
    if raw.startswith('/'): return
    token = raw
    if not token or ":" not in token:
        return await ev.reply("BOT_TOKEN inválido. Formato: `123456:ABC-...`")
    slug = f["slug"]; plan = f["plan"]; workdir = Path(S["clients"][slug]["workdir"]); owner_id = ev.sender_id
    try:
        await ev.reply("Paso 1/4: clonando plantilla..."); clone_template(plan, workdir)
        await ev.reply("Paso 2/4: configurando .env..."); write_env(workdir, bot_token=token, owner_id=owner_id, slug=slug, tz="UTC"); force_load_dotenv_override(workdir)
        await ev.reply("Paso 3/4: instalando deps..."); ensure_venv_and_requirements(workdir)
        await ev.reply("Paso 4/4: activando servicio..."); enable_instance_service(slug)
        flows.pop(ev.sender_id, None)
        bot_meta = _get_bot_meta(token); bot_info = f"@{bot_meta.get('username','Error')}" if bot_meta.get("ok") else "⚠️ Token inválido o inaccesible"
        await ev.reply(f"Instancia creada\nBot: {bot_info}\nDir: `{workdir}`\nServicio: `reenvio@{slug}.service` (activo)\n/status para ver estado.")
    except subprocess.CalledProcessError as e:
        flows.pop(ev.sender_id, None)
        await ev.reply(f"Error instalación\nCMD: `{e.cmd}`\nRC: `{e.returncode}`\nContacta @frankosmel")
    except Exception as e:
        flows.pop(ev.sender_id, None)
        await ev.reply(f"Error inesperado: `{str(e)[:100]}`")

# ===== Upgrade (igual con funciones existentes) =====
def _upgrade_client(slug: str) -> str:
    current_state = load_state()
    if slug not in current_state.get("clients", {}): return f"❌ Cliente `{slug}` no existe"
    info = current_state["clients"][slug]; wdir = Path(info["workdir"]); plan = info.get("plan","plan_estandar"); svc = f"reenvio@{slug}.service"
    if not wdir.exists(): return f"❌ Dir no existe: `{wdir}`"
    template_dir = TEMPL.get(plan)
    if not template_dir or not template_dir.exists(): return f"❌ Plantilla no encontrada: `{plan}`"
    try:
        try: run(f"sudo -n /usr/bin/systemctl stop {svc}")
        except: pass
        rsync = shutil.which("rsync")
        if rsync:
            run(f'rsync -a --delete --exclude ".env" --exclude "state*.json" --exclude "*session*" --exclude "venv" {template_dir}/ {wdir}/')
        else:
            for src in template_dir.rglob("*"):
                rel = src.relative_to(template_dir); dst = wdir / rel
                if any(str(rel).startswith(x) for x in ("venv",".env")) or dst.name.endswith(".session") or dst.name.startswith("state"): continue
                if src.is_dir(): dst.mkdir(parents=True, exist_ok=True)
                else: dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(src, dst)
        req = wdir / "requirements.txt"; vpy = wdir / "venv/bin/pip"
        if req.exists() and vpy.exists():
            try: run(f"{vpy} install --upgrade -r {req}")
            except: pass
        try: run("sudo -n /usr/bin/systemctl daemon-reload")
        except: pass
        run(f"sudo -n /usr/bin/systemctl start {svc}")
        return f"✅ `{slug}` actualizado y reiniciado"
    except Exception as e:
        return f"❌ Error `{slug}`: {str(e)[:100]}"

@bot.on(events.NewMessage(pattern=r'^/upgrade\s+(\S+)$'))
async def cmd_upgrade_one(ev):
    if not is_any_admin(ev.sender_id): return
    slug = ev.pattern_match.group(1).strip()
    msg = await ev.reply(f"Actualizando `{slug}`...")
    result = _upgrade_client(slug)
    try: await msg.edit(result)
    except: await ev.reply(result)

@bot.on(events.NewMessage(pattern=r'^/upgrade_all$'))
async def cmd_upgrade_all(ev):
    if not is_any_admin(ev.sender_id): return
    clients = sorted(visible_clients_for(ev.sender_id)) if not is_owner(ev.sender_id) else sorted(S.get("clients", {}).keys())
    if not clients: return await ev.reply("No hay clientes")
    msg_loading = await ev.reply(f"Actualizando {len(clients)} clientes...")
    results=[]
    for i, slug in enumerate(clients, 1):
        try:
            r = _upgrade_client(slug); results.append(f"{i}. {r}")
            if i%3==0 or i==len(clients):
                try: await msg_loading.edit(f"Progreso: {i}/{len(clients)}\n\n" + "\n".join(results[-5:]))
                except: pass
        except Exception as e:
            results.append(f"{i}. ❌ {slug}: {str(e)[:50]}")
    final = "Completado\n\n" + "\n".join(results[:20])
    if len(results)>20: final += f"\n\n(+{len(results)-20} más)"
    try: await msg_loading.edit(final)
    except: await ev.reply(final)

# ===== Cancel y Help (igual) =====
@bot.on(events.NewMessage(pattern=r'^/cancel$'))
async def cancel_flow(ev):
    if ev.sender_id in flows:
        flows.pop(ev.sender_id, None); await ev.reply("Cancelado")
    else:
        await ev.reply("Sin operaciones activas")

@bot.on(events.NewMessage(pattern=r'^/help$'))
async def help_cmd(ev):
    uid = ev.sender_id
    if is_any_admin(uid):
        await ev.reply(
            "Ayuda Admin\n"
            "/set_owner <id>\n/admins\n/admin_add <id>\n/admin_rm <id>\n"
            "/clients\n/client <slug>\n/auth\n/renew\n/edit_plan\n/revoke\n"
            "/upgrade <slug>\n/upgrade_all\n/reseller\n/invoice <admin_id>\n"
        )
    else:
        await ev.reply("Ayuda Cliente\n/start\n/provision\n/status\n/help")

# ===== NUEVO: Menú /reseller (owner) =====
def kb_reseller_menu():
    return [
        [Button.inline("➕ Crear/editar reseller", b"r:manage")],
        [Button.inline("🏷 Cambiar plan", b"r:chgplan"), Button.inline("⏳ Renovar", b"r:renew")],
        [Button.inline("🗑 Eliminar reseller", b"r:del")],
        [Button.inline("👁 Ver clientes por reseller", b"r:list")]
    ]

@bot.on(events.NewMessage(pattern=r'^/reseller$'))
async def reseller_menu(ev):
    if not is_owner(ev.sender_id): return
    await ev.reply("Reseller Manager", buttons=kb_reseller_menu())

RESW: Dict[int, Dict[str, Any]] = {}

@bot.on(events.CallbackQuery)
async def reseller_actions(ev):
    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("r:"): return
    if not is_owner(ev.sender_id): return
    op = data.split(":",1)[1]
    if op=="manage":
        RESW[ev.sender_id] = {"stage":"await_admin_id"}
        try: await ev.edit("Envíe ID numérico del reseller o elija plan tras enviarlo.\n/cancel")
        except: await ev.respond("Envíe ID numérico del reseller.\n/cancel")
    elif op=="chgplan":
        RESW[ev.sender_id] = {"stage":"chgplan_id"}
        await ev.respond("ID de reseller a cambiar plan:")
    elif op=="renew":
        RESW[ev.sender_id] = {"stage":"renew_id"}
        await ev.respond("ID de reseller a renovar:")
    elif op=="del":
        RESW[ev.sender_id] = {"stage":"del_id"}
        await ev.respond("ID de reseller a eliminar:")
    elif op=="list":
        lines = []
        for aid,a in S["admins"].items():
            aid_i = int(aid)
            lines.append(f"- {a['slug']}({aid}) · {len([1 for v in S['clients'].values() if v.get('parent_admin')==aid_i])} clientes · plan {a['plan']}")
        await ev.respond("Resellers:\n" + ("\n".join(lines) if lines else "—"))

@bot.on(events.NewMessage)
async def reseller_wizard(ev):
    st = RESW.get(ev.sender_id)
    if not st: return
    if not is_owner(ev.sender_id): return
    raw = (ev.raw_text or "").strip()
    if raw.startswith("/cancel"):
        RESW.pop(ev.sender_id, None); await ev.reply("Cancelado"); return
    # crear/editar
    if st["stage"]=="await_admin_id":
        if not raw.isdigit():
            await ev.reply("ID inválido"); return
        aid = int(raw); RESW[ev.sender_id]={"stage":"pick_plan","aid":aid}
        await ev.reply(f"ID {aid}. Elige plan:", buttons=kb_reseller_plans()); return
    # cambiar plan
    if st["stage"]=="chgplan_id":
        if not raw.isdigit():
            await ev.reply("ID inválido"); return
        aid = int(raw); RESW[ev.sender_id]={"stage":"chg_plan_pick","aid":aid}
        await ev.reply(f"ID {aid}. Nuevo plan:", buttons=kb_reseller_plans()); return
    # renovar
    if st["stage"]=="renew_id":
        if not raw.isdigit():
            await ev.reply("ID inválido"); return
        aid = int(raw); RESW[ev.sender_id]={"stage":"renew_days","aid":aid}
        await ev.reply("Días a agregar (7,30,90,365):"); return
    if st["stage"]=="renew_days":
        try:
            days = int(raw)
        except:
            await ev.reply("Días inválidos"); return
        aid = st["aid"]; A = S["admins"].get(str(aid))
        if not A: ensure_admin_stub(aid)
        # extender expiración sin cambiar plan
        apply_plan_to_admin(aid, S["admins"][str(aid)]["plan"], extend_days=days)
        ex = S["admins"][str(aid)]["expires_at"]
        RESW.pop(ev.sender_id, None)
        await ev.reply(f"Renovado reseller {aid} +{days} días. Expira: {ex}")
        return
    # eliminar
    if st["stage"]=="del_id":
        if not raw.isdigit():
            await ev.reply("ID inválido"); return
        aid = int(raw)
        has_clients = any(c.get("parent_admin")==aid for c in S["clients"].values())
        if has_clients:
            await ev.reply("No se puede eliminar. Tiene clientes.");
            return
        S["admins"].pop(str(aid), None); save_state(S)
        RESW.pop(ev.sender_id, None)
        await ev.reply(f"Eliminado reseller {aid}")

@bot.on(events.CallbackQuery)
async def reseller_plan_pick(ev):
    data = (ev.data or b"").decode(errors="ignore")
    if not data.startswith("rplan:"): return
    if not is_owner(ev.sender_id): return
    key = data.split(":",1)[1]
    st = RESW.get(ev.sender_id)
    if not st: return
    if key=="cancel":
        RESW.pop(ev.sender_id, None)
        try: await ev.edit("Cancelado")
        except: pass
        return
    aid = st["aid"]
    ensure_admin_stub(aid)
    apply_plan_to_admin(aid, key)
    ex = S["admins"][str(aid)]["expires_at"]
    try: await ev.edit(f"Reseller {aid} plan={key} aplicado. Expira: {ex}")
    except: await ev.respond(f"Reseller {aid} plan={key} aplicado. Expira: {ex}")
    RESW.pop(ev.sender_id, None)

# ===== Facturación básica =====
def calc_invoice(admin_id: int):
    A = S["admins"].get(str(admin_id))
    if not A: return None
    base = A["base_usd"]; sub = A["subbot_usd"]
    active = len([1 for c in S["clients"].values() if c.get("parent_admin")==admin_id])
    total = base + active * sub
    return {"admin_id": admin_id, "slug": A["slug"], "plan": A["plan"], "active_subbots": active, "base_usd": base, "subbot_usd": sub, "total_usd": total}

@bot.on(events.NewMessage(pattern=r'^/invoice\s+(\d+)$'))
async def invoice_cmd(ev):
    if not is_owner(ev.sender_id): return
    aid = int(ev.pattern_match.group(1))
    inv = calc_invoice(aid)
    if not inv: return await ev.reply("Admin no existe")
    # CSV en carpeta manager
    csvp = MANAGER_DIR / f"invoice_{aid}.csv"
    with open(csvp, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["admin_id","slug","plan","active_subbots","base_usd","subbot_usd","total_usd"])
        w.writerow([inv["admin_id"], inv["slug"], inv["plan"], inv["active_subbots"], inv["base_usd"], inv["subbot_usd"], inv["total_usd"]])
    await ev.reply(f"Factura\nAdmin: {aid}\nPlan: {inv['plan']}\nSub-bots: {inv['active_subbots']}\nBase: ${inv['base_usd']}\nSub: ${inv['subbot_usd']}\nTotal: ${inv['total_usd']}\nCSV: `{csvp}`")

# ===== Main =====
async def main():
    await bot.start(bot_token=BOT_TOKEN)
    print("Manager iniciado")
    print(f"Clientes: {len(S.get('clients', {}))}")
    print(f"Admins: {len(S.get('admins', {}))} + owner")
    await check_expiring_plans()
    asyncio.create_task(expiry_checker_task())
    print("Expiraciones activo")
    await bot.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())
