# send_notice.py
import os, asyncio
from pathlib import Path
from dotenv import load_dotenv
from telethon import TelegramClient, Button

# Carga variables del .env del bot del cliente
ENV = Path(__file__).with_name(".env")
load_dotenv(ENV)

API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
BOT_TOKEN = os.getenv("BOT_TOKEN")
TARGET_ID = int(os.getenv("OWNER_ID"))  # dueño del bot (tu cliente)

MSG = (
    "⚠️ *Aviso importante de suscripción*\n\n"
    "Tu servicio en **Reenvío Plus Bot** ha sido *pausado* por falta de pago.\n\n"
    "Para reactivarlo y continuar utilizando el sistema, contacta al administrador 👇"
)

BUTTONS = [[Button.url("💳 Pagar / Contactar", "https://t.me/frankosme1")]]

async def main():
    client = TelegramClient("send_notice_session", API_ID, API_HASH)
    await client.start(bot_token=BOT_TOKEN)
    await client.send_message(TARGET_ID, MSG, buttons=BUTTONS, parse_mode="md")
    await client.disconnect()

if __name__ == "__main__":
    asyncio.run(main())
