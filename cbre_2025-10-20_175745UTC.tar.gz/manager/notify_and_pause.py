#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os, json, datetime as dt, subprocess, sys, re
from pathlib import Path

ROOT = Path.home() / "CLIENTES_BOT_REENVIO"
MGR  = ROOT / "manager"
STATEF = MGR / "state.json"
ENVF = MGR / ".env"
SYSTEMCTL = "/usr/bin/systemctl"

def load_env(path: Path) -> dict:
    env = {}
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k,v = line.split("=",1); env[k.strip()] = v.strip()
    return env

def load_state() -> dict:
    if not STATEF.exists():
        print(f"[err] state.json no existe: {STATEF}", file=sys.stderr)
        sys.exit(1)
    return json.loads(STATEF.read_text(encoding="utf-8"))

def save_state(S: dict):
    STATEF.write_text(json.dumps(S, indent=2, ensure_ascii=False), encoding="utf-8")

def svc_status(slug: str) -> str:
    try:
        out = subprocess.run([SYSTEMCTL,"is-active",f"reenvio@{slug}.service"],
                             stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                             text=True, check=False).stdout.strip()
        return "active" if out=="active" else (out or "unknown")
    except Exception:
        return "unknown"

def svc_stop(slug: str):
    subprocess.run([SYSTEMCTL,"stop",f"reenvio@{slug}.service"], check=False)

def md_escape(t: str) -> str:
    if t is None: return ""
    # Telegram MarkdownV1 escape
    return re.sub(r'([_*\[\]()~`>#+\-=|{}.!])', r'\\\1', str(t))

def send_msg(bot_token: str, chat_id: int, text: str, inline_btns=None):
    import urllib.parse, urllib.request, json as _json
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    data = {
        "chat_id": chat_id,
        "parse_mode": "Markdown",
        "text": text
    }
    if inline_btns:
        data["reply_markup"] = {"inline_keyboard": inline_btns}
    req = urllib.request.Request(url, data=urllib.parse.urlencode({
        k: _json.dumps(v) if k=="reply_markup" else v
        for k,v in data.items()
    }).encode("utf-8"))
    with urllib.request.urlopen(req, timeout=15) as r:
        r.read()

def main():
    env = load_env(ENVF)
    BOT_TOKEN = env.get("MANAGER_BOT_TOKEN") or env.get("BOT_TOKEN") or ""
    if not BOT_TOKEN:
        print("[err] Falta MANAGER_BOT_TOKEN en manager/.env", file=sys.stderr)
        sys.exit(2)

    S = load_state()
    settings = S.get("settings", {})
    grace_days = int(settings.get("grace_days", 0) or 0)
    notify_copy_reseller = bool(settings.get("notify_expiry_reseller", False))
    auto_pause = bool(settings.get("auto_pause_on_expiry", True))
    today = dt.date.today()
    tomorrow = today + dt.timedelta(days=1)

    clients = S.get("clients", {})
    usernames = S.get("usernames", {})
    res_meta = S.get("resellers_meta", {})  # opcional

    for slug, c in clients.items():
        owner_id = c.get("owner_id")
        plan = c.get("plan","plan_estandar")
        exp_s = c.get("expires_at")
        if not owner_id or not exp_s:
            continue

        try:
            exp = dt.date.fromisoformat(exp_s)
        except Exception:
            continue

        # Aviso “vence mañana”
        if exp == tomorrow:
            try:
                # Mensaje a cliente
                msg = (
                    f"⚠️ *Aviso de vencimiento*\n\n"
                    f"🎫 Plan: *{md_escape(plan)}*\n"
                    f"📅 Vence mañana: *{md_escape(exp.isoformat())}*\n"
                    f"Tu servicio se pausará si no renuevas."
                )
                btns = [[{"text":"📞 Contactar @frankosme1","url":"https://t.me/frankosme1"}]]
                send_msg(BOT_TOKEN, owner_id, msg, inline_btns=btns)

                # Copia a reseller (si aplica)
                rid = c.get("reseller_id")
                if notify_copy_reseller and rid:
                    msg_r = (
                        f"🟡 *Cliente por vencer mañana*\n\n"
                        f"👤 Slug: `{md_escape(slug)}`\n"
                        f"🎫 Plan: *{md_escape(plan)}*\n"
                        f"📅 {md_escape(exp.isoformat())}"
                    )
                    send_msg(BOT_TOKEN, rid, msg_r,
                             inline_btns=[[{"text":"👥 Ver cliente","url":"https://t.me/frankosme1"}]])
            except Exception as e:
                print(f"[warn] aviso mañana {slug}: {e}", file=sys.stderr)

        # Vencido (con o sin gracia)
        limit = exp + dt.timedelta(days=grace_days)
        if today > limit:
            # ya pasó vencimiento + gracia
            if auto_pause:
                try:
                    st = svc_status(slug)
                    if st == "active":
                        svc_stop(slug)
                except Exception as e:
                    print(f"[warn] stop {slug}: {e}", file=sys.stderr)

            # Notificar al cliente (solo una vez por día idealmente)
            try:
                msg = (
                    f"🔴 *Servicio pausado por vencimiento*\n\n"
                    f"🎫 Plan: *{md_escape(plan)}*\n"
                    f"📅 Venció: *{md_escape(exp.isoformat())}*\n"
                    f"⏸️ Estado: Pausado\n\n"
                    f"Para reactivar, contáctanos."
                )
                btns = [[{"text":"💬 Contactar @frankosme1","url":"https://t.me/frankosme1"}]]
                send_msg(BOT_TOKEN, owner_id, msg, inline_btns=btns)
            except Exception as e:
                print(f"[warn] aviso pausado {slug}: {e}", file=sys.stderr)

            # Copia a reseller (si aplica)
            try:
                rid = c.get("reseller_id")
                if notify_copy_reseller and rid:
                    send_msg(BOT_TOKEN, rid,
                             f"🔴 *Cliente pausado por vencimiento*: `{md_escape(slug)}`",
                             inline_btns=[[{"text":"👥 Ver cliente","url":"https://t.me/frankosme1"}]])
            except Exception as e:
                print(f"[warn] aviso reseller {slug}: {e}", file=sys.stderr)

    # Marca timestamp de última corrida
    S["last_expiry_check"] = dt.datetime.now().isoformat(timespec="seconds")
    save_state(S)
    print("[ok] notify_and_pause: done")

if __name__ == "__main__":
    main()
