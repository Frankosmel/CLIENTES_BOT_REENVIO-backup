import json, os, asyncio, datetime as dt
from telethon import TelegramClient, Button
from dotenv import load_dotenv
STATE = os.path.expanduser('~/CLIENTES_BOT_REENVIO/manager/state.json')
load_dotenv(os.path.join(os.getcwd(), '.env'), override=True)
API_ID = int(os.getenv("API_ID","0")); API_HASH=os.getenv("API_HASH",""); BOT_TOKEN=os.getenv("MANAGER_BOT_TOKEN","")
SLUG = os.getenv("TARGET_SLUG","frankosme1")  # cambia si quieres

def get_client(slug):
    data = json.loads(open(STATE).read())
    c = data["clients"].get(slug)
    if not c: raise SystemExit(f"Slug '{slug}' no existe")
    return c

async def main():
    c = get_client(SLUG)
    target_id = c["owner_id"]
    expires = c.get("expires_at","")
    msg = (f"⚠️ *Aviso de suscripción*\n\n"
           f"Cliente: `{SLUG}`\n"
           f"Plan: **{c.get('plan','N/A')}**\n"
           f"Vence: **{expires}**\n\n"
           f"Para renovar o pedir ayuda toca el botón 👇")
    buttons = [[Button.url("💳 Renovar / Contactar", "https://t.me/frankosme1")]]
    async with TelegramClient('manager_bot_send_notice', API_ID, API_HASH) as cli:
        await cli.start(bot_token=BOT_TOKEN)
        await cli.send_message(target_id, msg, buttons=buttons, parse_mode='md')
        print("Enviado a", target_id)
asyncio.run(main())
