#!/usr/bin/env python3
# -*- coding: utf-8 -*-

SYSTEMCTL = "/usr/bin/systemctl"

import os, json, asyncio, shutil, subprocess, datetime as dt, re
from pathlib import Path
from typing import Dict, Any
import logging

from telethon import TelegramClient, events, Button
from dotenv import load_dotenv

# ======= Logging =======
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# ======= Rutas base =======
ROOT = Path.home() / "CLIENTES_BOT_REENVIO"
MANAGER_DIR = ROOT / "manager"
TEMPL_DIR = ROOT / "TEMPLATES"
STATEF = MANAGER_DIR / "state.json"
CLIENTS_DIR = ROOT / "clients"
CLIENTS_DIR.mkdir(parents=True, exist_ok=True)
MANAGER_DIR.mkdir(parents=True, exist_ok=True)

# ======= Mapas de planes a carpeta plantilla (incluye trial) =======
TEMPL = {
    "default": TEMPL_DIR / "default",
    "plan_estandar": TEMPL_DIR / "plan_estandar",
    "plan_plus": TEMPL_DIR / "plan_plus",
    "plan_pro": TEMPL_DIR / "plan_pro",
    "plan_trial": TEMPL_DIR / "plan_estandar",  # Trial usa template estándar
}

# ======= Config Manager .env =======
load_dotenv(MANAGER_DIR / ".env")
API_ID = int(os.getenv("API_ID", "0"))
API_HASH = os.getenv("API_HASH", "")
BOT_TOKEN = os.getenv("MANAGER_BOT_TOKEN", "")

# Verificar configuración al importar
if not API_ID or not API_HASH or not BOT_TOKEN:
    print("❌ Error: Faltan credenciales en ~/CLIENTES_BOT_REENVIO/manager/.env")
    print("📝 Crea el archivo con:")
    print("   API_ID=tu_api_id")
    print("   API_HASH=tu_api_hash") 
    print("   MANAGER_BOT_TOKEN=tu_bot_token")
    print("🔗 Obtén las credenciales en: https://my.telegram.org/apps")
    print("🤖 Obtén el bot token de: @BotFather")

# ======= State =======
def load_state() -> Dict[str, Any]:
    if not STATEF.exists():
        STATEF.write_text(
            json.dumps(
                {
                    "owner_id": 0,
                    "admins": [],
                    "resellers": [],
                    "clients": {},
                    "last_expiry_check": None,
                    "notify_expiry": True,
                },
                indent=2,
                ensure_ascii=False,
            )
        )
    return json.loads(STATEF.read_text())

def save_state(S: Dict[str, Any]):
    STATEF.write_text(json.dumps(S, indent=2, ensure_ascii=False))

S = load_state()

# ======= Helpers (roles) - ENHANCED =======
def is_owner(uid: int) -> bool:
    return uid == S.get("owner_id", 0)

def is_admin_normal(uid: int) -> bool:
    """Admin normal: puede gestionar pero no crear clientes"""
    return uid in S.get("admins", [])

def is_admin(uid: int) -> bool:
    """Admin completo: owner o admin normal"""
    return is_owner(uid) or is_admin_normal(uid)

def is_reseller(uid: int) -> bool:
    return uid in S.get("resellers", [])

def can_create_clients(uid: int) -> bool:
    """Solo Owner y Resellers pueden crear clientes"""
    return is_owner(uid) or is_reseller(uid)

def can_manage_client(uid: int, slug: str) -> bool:
    """Permisos para gestionar (renovar, cambiar plan, etc.) un cliente específico"""
    c = S.get("clients", {}).get(slug) or {}
    
    # Owner puede gestionar todos
    if is_owner(uid):
        return True
    
    # Admin normal puede gestionar todos (pero no crear)
    if is_admin_normal(uid):
        return True
    
    # Reseller puede gestionar solo sus clientes
    if is_reseller(uid) and c.get("reseller_id") == uid:
        return True
    
    # Cliente puede gestionar solo el suyo
    return c.get("owner_id") == uid

def can_view_client(uid: int, slug: str) -> bool:
    """Permisos para ver un cliente (más amplio que gestionar)"""
    c = S.get("clients", {}).get(slug) or {}
    
    # Admins ven todos
    if is_admin(uid):
        return True
    
    # Resellers ven todos (pero solo gestionan los suyos)
    if is_reseller(uid):
        return True
    
    # Cliente ve solo el suyo
    return c.get("owner_id") == uid

def get_user_role_name(uid: int) -> str:
    """Obtiene el nombre del rol para mostrar"""
    if is_owner(uid):
        return "👑 Administrador Principal"
    elif is_admin_normal(uid):
        return "🛡️ Admin Normal"
    elif is_reseller(uid):
        return "🤝 Reseller"
    else:
        # Verificar si es cliente
        for slug, c in S.get("clients", {}).items():
            if c.get("owner_id") == uid:
                return "👤 Cliente Final"
        return "❓ Sin Rol"

# ======= PUNTO 5: Helpers de systemd y shell (reales) =======
def run(cmd: str):
    p = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode != 0:
        raise RuntimeError(f"RC={p.returncode}\nCMD={cmd}\nSTDOUT:\n{p.stdout}\nSTDERR:\n{p.stderr}")
    return p.stdout

def _svc_status(svc: str) -> str:
    try:
        out = subprocess.run([SYSTEMCTL, "is-active", svc], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
        return "active" if out.stdout.strip() == "active" else out.stdout.strip() or "unknown"
    except Exception:
        return "unknown"

def resume_instance_service(slug: str):
    run(f"sudo -n {SYSTEMCTL} start reenvio@{slug}.service || true")

def pause_instance_service(slug: str):
    run(f"sudo -n {SYSTEMCTL} stop reenvio@{slug}.service || true")

# ======= PUNTO 8: Funciones de provisionamiento real =======
def clone_template(plan: str, workdir: Path):
    if workdir.exists(): 
        shutil.rmtree(workdir)
    shutil.copytree(TEMPL.get(plan, TEMPL["default"]), workdir)

def ensure_venv_and_requirements(workdir: Path):
    venv = workdir / "venv"
    if not venv.exists():
        run(f"python3 -m venv '{venv}'")
        run(f"'{venv}/bin/pip' install --upgrade pip")
    req = workdir / "requirements.txt"
    if req.exists():
        run(f"'{venv}/bin/pip' install -r '{req}'")
    else:
        run(f"'{venv}/bin/pip' install telethon==1.36.0 python-dotenv==1.0.1 requests==2.31.0")

def write_env(workdir: Path, *, bot_token: str, owner_id: int, slug: str, tz="UTC"):
    (workdir / ".env").write_text(
        f"API_ID={API_ID}\nAPI_HASH={API_HASH}\nBOT_TOKEN={bot_token}\nOWNER_ID={owner_id}\n"
        f"USER_SESSION={slug}_user\nBOT_SESSION={slug}panel\nSTATE_FILE=state{slug}.json\nTIMEZONE={tz}\n"
    )

def force_load_dotenv_override(workdir: Path):
    py = workdir / "telethon_userbot_listas_publicaciones.py"
    if not py.exists(): 
        return
    txt = py.read_text()
    if "override=True" not in txt:
        txt = re.sub(r"load_dotenv\((.*?)\)", r"load_dotenv(\1, override=True)", txt, count=1, flags=re.S)
        if "load_dotenv" not in txt:
            txt = ("from pathlib import Path as _P\nfrom dotenv import load_dotenv\n"
                   "load_dotenv(dotenv_path=_P(__file__).with_name('.env'), override=True)\n") + txt
    py.write_text(txt)

def enable_instance_service(slug: str):
    run(f"sudo -n {SYSTEMCTL} daemon-reload")
    run(f"sudo -n {SYSTEMCTL} enable --now 'reenvio@{slug}.service'")

# ======= Flujos =======
flows: Dict[int, Dict[str, Any]] = {}

# ======= MENÚS MEJORADOS POR ROLE =======
LBL_BACK = "◀️ Volver"

# === OWNER (Administrador Principal) ===
OWNER_MAIN = [
    ["👥 Clientes", "🤝 Resellers"],
    ["➕ Autorizar cliente"],  # Solo Owner puede crear
    ["⚙️ Config", "🛠️ Mantenimiento"],
    ["📊 Reportes", "❓ Ayuda"],
]

# === ADMIN NORMAL ===
ADMIN_MAIN = [
    ["👥 Clientes", "🤝 Resellers"],
    ["⚙️ Config", "🛠️ Mantenimiento"],
    ["📊 Reportes", "❓ Ayuda"],
]

# === RESELLER ===
RESELLER_MAIN = [
    ["👥 Mis clientes", "➕ Autorizar cliente"],
    ["👁️ Ver otros clientes"],
    ["🔁 Renovar", "🗂 Cambiar plan"],
    ["❓ Ayuda"],
]

# === CLIENT ===
CLIENT_MAIN = [
    ["🚀 Provisionar", "📊 Status"],
    ["🔄 Reiniciar servicio", "🧑‍💻 Soporte"],
    ["❓ Ayuda"],
]

def rk(rows):
    return [[Button.text(x) for x in row] for row in rows]

# ======= Funciones de menú =======
async def show_main_menu(ev):
    uid = ev.sender_id
    role_name = get_user_role_name(uid)
    
    if is_owner(uid):
        await ev.respond(f"{role_name} - Panel Principal:", buttons=rk(OWNER_MAIN))
    elif is_admin_normal(uid):
        await ev.respond(f"{role_name} - Panel Principal:", buttons=rk(ADMIN_MAIN))
    elif is_reseller(uid):
        await ev.respond(f"{role_name} - Panel Principal:", buttons=rk(RESELLER_MAIN))
    else:
        # Cliente o sin rol
        for slug, c in S.get("clients", {}).items():
            if c.get("owner_id") == uid:
                await ev.respond(f"{role_name} - Panel Principal:", buttons=rk(CLIENT_MAIN))
                return
        await ev.respond("❌ No tienes acceso autorizado. Contacta @frankosmel")

# ======= Funciones básicas =======
async def help_cmd(ev):
    """Comando de ayuda contextual según el rol"""
    uid = ev.sender_id
    role_name = get_user_role_name(uid)
    
    help_text = f"❓ **Ayuda - {role_name}**\n\n"
    
    if is_owner(uid):
        help_text += (
            "Como **Administrador Principal** tienes acceso completo:\n\n"
            "🔧 **Gestión de Clientes:**\n"
            "• ➕ Autorizar cliente - Crear nuevos accesos\n"
            "• 👥 Clientes - Ver y gestionar todos los clientes\n"
            "• 🔁 Renovar - Extender vencimientos\n"
            "• 🗂 Cambiar plan - Modificar planes de servicio\n\n"
            "👥 **Administración:**\n"
            "• 🤝 Resellers - Gestionar resellers y admins\n"
            "• ⚙️ Config - Configuración del sistema\n"
            "• 🛠️ Mantenimiento - Herramientas de diagnóstico\n"
            "• 📊 Reportes - Estadísticas y estado de servicios\n\n"
            "💡 **Tip:** Usa /menu para acceder rápidamente al panel principal\n\n"
            "📞 Soporte técnico: @frankosmel"
        )
    elif is_admin_normal(uid):
        help_text += (
            "Como **Admin Normal** puedes gestionar clientes existentes:\n\n"
            "🔧 **Tus funciones:**\n"
            "• 👥 Clientes - Ver y gestionar todos los clientes\n"
            "• 🔁 Renovar - Extender vencimientos\n"
            "• 🗂 Cambiar plan - Modificar planes de servicio\n"
            "• ⚙️ Config - Ver configuración del sistema\n"
            "• 🛠️ Mantenimiento - Herramientas de diagnóstico\n"
            "• 📊 Reportes - Estadísticas del sistema\n\n"
            "❌ **Limitaciones:**\n"
            "• NO puedes crear nuevos clientes\n"
            "• NO puedes gestionar resellers\n\n"
            "📞 Soporte: @frankosmel"
        )
    elif is_reseller(uid):
        help_text += (
            "Como **Reseller** puedes gestionar tus clientes:\n\n"
            "🔧 **Tus funciones:**\n"
            "• ➕ Autorizar cliente - Crear tus propios clientes\n"
            "• 👥 Mis clientes - Gestionar solo tus clientes\n"
            "• 👁️ Ver otros clientes - Visualizar otros clientes (solo lectura)\n"
            "• 🔁 Renovar - Extender vencimientos de tus clientes\n"
            "• 🗂 Cambiar plan - Modificar planes de tus clientes\n"
            "• 📊 Reportes - Ver estadísticas\n\n"
            "💡 **Importante:**\n"
            "• Solo puedes gestionar clientes que tú hayas creado\n"
            "• Puedes ver otros clientes pero no modificarlos\n\n"
            "📞 Soporte: @frankosmel"
        )
    else:
        # Cliente final
        my_client = None
        for slug, c in S.get("clients", {}).items():
            if c.get("owner_id") == uid:
                my_client = (slug, c)
                break
        
        if my_client:
            slug, client_info = my_client
            plan = client_info.get("plan", "N/A")
            exp = client_info.get("expires_at", "N/A")
            provisioned = client_info.get("provisioned", False)
            
            help_text += (
                "Como **Cliente Final** puedes gestionar tu servicio:\n\n"
                f"📋 **Tu información:**\n"
                f"• Cliente ID: `{slug}`\n"
                f"• Plan: {plan}\n"
                f"• Vencimiento: {exp}\n"
                f"• Estado: {'✅ Provisionado' if provisioned else '⚠️ Pendiente de provisionar'}\n\n"
                "🔧 **Tus funciones:**\n"
                "• 🚀 Provisionar - Configurar tu bot (solo una vez)\n"
                "• 📊 Status - Ver estado de tu servicio\n"
                "• 🔄 Reiniciar servicio - Solucionar problemas\n"
                "• 🧑‍💻 Soporte - Obtener ayuda técnica\n\n"
                "💡 **Proceso inicial:**\n"
                "1. Usa 🚀 Provisionar para configurar tu bot\n"
                "2. Proporciona el token de tu bot de @BotFather\n"
                "3. Espera a que se complete la configuración\n"
                "4. Tu bot estará listo para usar\n\n"
                "📞 Soporte: @frankosmel"
            )
        else:
            help_text += (
                "❌ **No tienes acceso autorizado**\n\n"
                "Para obtener acceso a nuestros servicios, contacta:\n"
                "📞 @frankosmel\n\n"
                "Te asignaremos un cliente y te explicaremos cómo usar el sistema."
            )
    
    await ev.reply(help_text)

# ======= FUNCIONES COMPLETAS CON INLINE KEYBOARDS =======

async def auth_start(ev):
    """Iniciar proceso de autorización - solo Owner y Resellers pueden crear"""
    uid = ev.sender_id
    
    if not can_create_clients(uid):
        return await ev.reply("❌ No tienes permisos para autorizar clientes.")
    
    flows[uid] = {"action": "auth", "step": "get_user", "role": get_user_role_name(uid)}
    await ev.reply(
        "➕ **Autorizar nuevo cliente**\n\n"
        "Envía el **@username** o **ID numérico** del usuario a autorizar:"
    )

async def renew_start(ev):
    """Iniciar renovación de cliente con inline keyboard"""
    uid = ev.sender_id
    clients = get_visible_clients(uid, action_type="manage")
    
    if not clients:
        return await ev.reply("📭 No tienes clientes que puedas gestionar.")
    
    keyboard = create_client_inline_keyboard("renew", clients)
    await ev.respond("🔁 **Renovar Cliente**\n\nSelecciona el cliente a renovar:", buttons=keyboard)

async def edit_plan_start(ev):
    """Iniciar cambio de plan con inline keyboard"""
    uid = ev.sender_id
    clients = get_visible_clients(uid, action_type="manage")
    
    if not clients:
        return await ev.reply("📭 No tienes clientes que puedas gestionar.")
    
    keyboard = create_client_inline_keyboard("edit_plan", clients)
    await ev.respond("🗂 **Cambiar Plan**\n\nSelecciona el cliente:", buttons=keyboard)

async def revoke_start(ev):
    """Iniciar revocación con confirmación inline"""
    uid = ev.sender_id
    clients = get_visible_clients(uid, action_type="manage")
    
    if not clients:
        return await ev.reply("📭 No tienes clientes que puedas gestionar.")
    
    keyboard = create_client_inline_keyboard("revoke", clients)
    await ev.respond("🚫 **Revocar Acceso**\n\n⚠️ Esta acción es destructiva.\nSelecciona el cliente:", buttons=keyboard)

async def status_cmd(ev):
    """Mostrar estado del cliente o sistema"""
    uid = ev.sender_id
    
    # Si es cliente, mostrar su estado específico
    for slug, c in S.get("clients", {}).items():
        if c.get("owner_id") == uid:
            return await show_client_status(ev, slug)
    
    # Si es admin/reseller, mostrar opciones
    if is_admin(uid) or is_reseller(uid):
        clients = get_visible_clients(uid, action_type="view")
        if clients:
            keyboard = create_client_inline_keyboard("status", clients)
            await ev.respond("📊 **Ver Estado**\n\nSelecciona cliente:", buttons=keyboard)
        else:
            await ev.reply("📭 No tienes clientes visibles.")
    else:
        await ev.reply("❌ No tienes acceso al estado del sistema.")

async def provision_start(ev):
    """Iniciar provisionamiento para cliente"""
    uid = ev.sender_id
    
    # Solo el propio cliente puede provisionar
    my_client = None
    for slug, c in S.get("clients", {}).items():
        if c.get("owner_id") == uid:
            my_client = (slug, c)
            break
    
    if not my_client:
        return await ev.reply("❌ No tienes un cliente asignado para provisionar.")
    
    slug, client_info = my_client
    flows[uid] = {"action": "provision", "step": "get_token", "client_slug": slug}
    
    await ev.reply(
        "🚀 **Provisionar Bot**\n\n"
        f"🔧 Cliente: `{slug}`\n"
        f"📦 Plan: {client_info.get('plan', 'N/A')}\n\n"
        "Envía el **token de tu bot** de Telegram:\n"
        "(Obtenlo de @BotFather)"
    )

# ======= FUNCIONES AUXILIARES =======

def get_visible_clients(uid: int, action_type: str = "view") -> dict:
    """Obtiene clientes visibles según permisos y tipo de acción"""
    visible = {}
    
    for slug, c in S.get("clients", {}).items():
        can_perform = False
        
        if action_type == "manage":
            can_perform = can_manage_client(uid, slug)
        elif action_type == "view":
            can_perform = can_view_client(uid, slug)
        elif action_type == "create" and can_create_clients(uid):
            can_perform = True
        
        if can_perform:
            visible[slug] = c
    
    return visible

def create_client_inline_keyboard(action: str, clients: dict, max_per_row: int = 2) -> list:
    """Crea teclado inline para selección de clientes"""
    rows = []
    row = []
    
    for slug, client_info in sorted(clients.items()):
        # Agregar indicador de propiedad
        plan = client_info.get("plan", "std")[:3]
        expires = client_info.get("expires_at", "N/A")[:5] if client_info.get("expires_at") else "N/A"
        
        button_text = f"📋 {slug} ({plan})"
        row.append(Button.inline(button_text, f"{action}:{slug}".encode()))
        
        if len(row) >= max_per_row:
            rows.append(row)
            row = []
    
    if row:
        rows.append(row)
    
    # Botón cancelar
    rows.append([Button.inline("❌ Cancelar", f"{action}:cancel".encode())])
    return rows

def create_plan_inline_keyboard(action: str, client_slug: str) -> list:
    """Crea teclado inline para selección de planes"""
    plans = {
        "plan_estandar": "📦 Estándar",
        "plan_plus": "⭐ Plus", 
        "plan_pro": "🏆 Pro",
        "plan_trial": "🆓 Trial 7d"
    }
    
    rows = []
    row = []
    
    for plan_key, plan_name in plans.items():
        row.append(Button.inline(plan_name, f"{action}_plan:{client_slug}:{plan_key}".encode()))
        if len(row) >= 2:
            rows.append(row)
            row = []
    
    if row:
        rows.append(row)
    
    rows.append([Button.inline("❌ Cancelar", f"{action}:cancel".encode())])
    return rows

def create_duration_inline_keyboard(action: str, client_slug: str, plan: str = "") -> list:
    """Crea teclado inline para selección de duración"""
    durations = {
        "7": "🆓 7 días (Trial)",
        "30": "📅 30 días (1 mes)",
        "90": "📆 90 días (3 meses)", 
        "180": "🗓️ 180 días (6 meses)",
        "365": "📋 365 días (1 año)"
    }
    
    rows = []
    for days, label in durations.items():
        data_key = f"{action}_duration:{client_slug}:{plan}:{days}" if plan else f"{action}_duration:{client_slug}:{days}"
        rows.append([Button.inline(label, data_key.encode())])
    
    rows.append([Button.inline("❌ Cancelar", f"{action}:cancel".encode())])
    return rows

# ======= PUNTO 6: Status real del servicio =======
async def show_client_status(ev, slug: str):
    """Muestra estado detallado de un cliente específico"""
    client_info = S.get("clients", {}).get(slug)
    if not client_info:
        return await ev.reply(f"❌ Cliente `{slug}` no encontrado.")
    
    exp = client_info.get("expires_at", "N/A")
    plan = client_info.get("plan", "N/A")
    reseller_id = client_info.get("reseller_id", "Owner")
    workdir = client_info.get("workdir", "N/A")
    
    # PUNTO 6: Estado real del servicio
    svc_name = f"reenvio@{slug}.service"
    svc = _svc_status(svc_name)
    svc_status = "🟢 Activo" if svc == "active" else f"🔴 {svc}"
    
    status_text = (
        f"📊 **Estado de Cliente: {slug}**\n\n"
        f"📦 **Plan:** {plan}\n"
        f"📅 **Vence:** {exp}\n"
        f"🤝 **Reseller:** {reseller_id}\n"
        f"⚙️ **Servicio:** {svc_status}\n"
        f"📁 **WorkDir:** `{workdir}`"
    )
    
    # Botones de acción según permisos
    action_buttons = []
    uid = ev.sender_id
    
    if can_manage_client(uid, slug):
        action_buttons.append([Button.inline("🔄 Reiniciar", f"restart_service:{slug}".encode())])
        action_buttons.append([Button.inline("🧹 Limpiar", f"cleanup_confirm:{slug}".encode())])
    
    action_buttons.append([Button.inline("📊 Actualizar", f"status:{slug}".encode())])
    
    await ev.respond(status_text, buttons=action_buttons)

# ======= MANEJADORES DE FLUJOS DE TEXTO =======
async def handle_text_flow(ev, txt: str, uid: int):
    """Maneja flujos de conversación en progreso"""
    if uid not in flows:
        return await ev.reply(f"🔧 **Función:** {txt}\n\nEsta opción estará disponible próximamente.")
    
    flow = flows[uid]
    action = flow.get("action")
    step = flow.get("step")
    
    if action == "auth" and step == "get_user":
        await handle_auth_user_input(ev, txt, uid)
    elif action == "provision" and step == "get_token":
        await handle_provision_token_input(ev, txt, uid)
    else:
        del flows[uid]
        await ev.reply("❌ Flujo no reconocido. Usa /menu para continuar.")

# ======= PUNTO 3: Resolver @username real =======
async def handle_auth_user_input(ev, txt: str, uid: int):
    """Maneja entrada de usuario para autorización"""
    try:
        # PUNTO 3: Resolución real de @username
        if txt.startswith("@"):
            ent = await ev.client.get_entity(txt)
            target_id = int(ent.id)
            flows[uid]["target_username"] = getattr(ent, "username", None)
        else:
            target_id = int(txt.strip())
            flows[uid]["target_username"] = None
            
        flows[uid]["step"] = "get_plan"
        flows[uid]["target_id"] = target_id
        
        # Mostrar planes disponibles
        keyboard = create_plan_inline_keyboard("auth", str(target_id))
        await ev.respond(
            f"📦 **Selecciona Plan**\n\nUsuario: `{target_id}`\nSelecciona el plan a asignar:", 
            buttons=keyboard
        )
            
    except ValueError:
        await ev.reply("❌ Formato inválido. Envía @username o ID numérico.")
    except Exception as e:
        await ev.reply(f"❌ Error buscando usuario: {str(e)}")

async def handle_provision_token_input(ev, txt: str, uid: int):
    """Maneja entrada de token para provisionamiento"""
    bot_token = txt.strip()
    
    # Validar formato básico del token
    if not bot_token or ":" not in bot_token:
        return await ev.reply("❌ Token inválido. Debe tener formato: 123456789:ABC-DEF...")
    
    flow = flows[uid]
    client_slug = flow["client_slug"]
    
    # Simular verificación del token
    await ev.reply(f"🔍 Verificando token...\n\n🤖 Token: `{bot_token[:20]}...`")
    
    # Aquí iría la lógica real de configuración
    flows[uid]["step"] = "confirm_provision"
    flows[uid]["bot_token"] = bot_token
    
    confirm_buttons = [
        [Button.inline("✅ Confirmar Configuración", f"confirm_provision:{client_slug}".encode())],
        [Button.inline("❌ Cancelar", "provision:cancel".encode())]
    ]
    
    await ev.respond(
        f"🚀 **Confirmar Provisionamiento**\n\n"
        f"🔧 Cliente: `{client_slug}`\n"
        f"🤖 Bot: `{bot_token[:20]}...`\n\n"
        "¿Proceder con la configuración?",
        buttons=confirm_buttons
    )

# ======= MENÚS ADICIONALES =======
async def show_clients_menu(ev):
    """Muestra menú de clientes según rol con información detallada"""
    uid = ev.sender_id
    role_name = get_user_role_name(uid)
    clients = get_visible_clients(uid, action_type="view")
    
    if not clients:
        message = (
            f"📭 **No hay clientes disponibles**\n\n"
            f"**Tu rol:** {role_name}\n"
        )
        if can_create_clients(uid):
            message += "\n💡 Puedes crear nuevos clientes usando '➕ Autorizar cliente'"
        else:
            message += "\n💡 Contacta a tu administrador para obtener clientes"
        
        back_button = [[Button.text("◀️ Volver")]]
        return await ev.respond(message, buttons=back_button)
    
    # Categorizar clientes
    active_clients = []
    expired_clients = []
    today = dt.date.today()
    
    for slug, c in sorted(clients.items()):
        plan = c.get("plan", "N/A")
        exp_str = c.get("expires_at", "N/A")
        reseller_id = c.get("reseller_id", "Owner")
        active = c.get("active", True)
        provisioned = c.get("provisioned", False)
        
        # Calcular días restantes
        days_left = "N/A"
        expired = False
        if exp_str != "N/A":
            try:
                exp_date = dt.datetime.fromisoformat(exp_str).date()
                days_diff = (exp_date - today).days
                if days_diff < 0:
                    days_left = f"❌ Vencido hace {abs(days_diff)} días"
                    expired = True
                elif days_diff == 0:
                    days_left = "⚠️ Vence hoy"
                elif days_diff <= 3:
                    days_left = f"⚠️ {days_diff} días"
                else:
                    days_left = f"✅ {days_diff} días"
            except:
                days_left = "❓ Error fecha"
        
        # Indicador de propiedad
        ownership_indicator = ""
        if c.get("owner_id") == uid:
            ownership_indicator = "👤 Tu cliente"
        elif c.get("reseller_id") == uid:
            ownership_indicator = "🤝 Tu cliente (reseller)"
        elif is_admin(uid):
            ownership_indicator = f"🔧 Cliente de {reseller_id}"
        elif is_reseller(uid):
            ownership_indicator = f"👁️ Cliente de {reseller_id}"
        
        # Estado del servicio
        status_icon = "🟢" if provisioned and active else "🔴" if provisioned else "⚪"
        
        client_info = {
            'slug': slug,
            'plan': plan,
            'days_left': days_left,
            'ownership': ownership_indicator,
            'status_icon': status_icon,
            'expired': expired,
            'provisioned': provisioned
        }
        
        if expired or not active:
            expired_clients.append(client_info)
        else:
            active_clients.append(client_info)
    
    # Construir mensaje
    lines = [f"👥 **Lista de Clientes** - {role_name}\n"]
    
    if active_clients:
        lines.append("🟢 **Clientes Activos:**")
        for c in active_clients:
            lines.append(f"{c['status_icon']} **{c['slug']}** ({c['plan']})")
            lines.append(f"  ⏰ {c['days_left']}")
            lines.append(f"  👤 {c['ownership']}")
            if not c['provisioned']:
                lines.append(f"  ⚠️ No provisionado")
            lines.append("")
    
    if expired_clients:
        lines.append("🔴 **Clientes Vencidos/Inactivos:**")
        for c in expired_clients:
            lines.append(f"{c['status_icon']} **{c['slug']}** ({c['plan']})")
            lines.append(f"  ⏰ {c['days_left']}")
            lines.append(f"  👤 {c['ownership']}")
            lines.append("")
    
    # Solo mostrar botones de gestión si tiene permisos para gestionar
    manageable_clients = get_visible_clients(uid, action_type="manage")
    
    if manageable_clients:
        lines.append("🔧 **Selecciona un cliente para gestionar:**")
        keyboard = create_client_inline_keyboard("manage", manageable_clients)
        await ev.respond("\n".join(lines), buttons=keyboard)
    else:
        lines.append("👁️ **Solo tienes permisos de visualización**")
        back_button = [[Button.text("◀️ Volver")]]
        await ev.respond("\n".join(lines), buttons=back_button)

async def show_other_clients(ev):
    """Muestra otros clientes en modo lectura (para resellers)"""
    uid = ev.sender_id
    
    if not is_reseller(uid):
        return await ev.reply("❌ Esta función es solo para resellers.")
    
    other_clients = {}
    for slug, c in S.get("clients", {}).items():
        if c.get("reseller_id") != uid:  # No son suyos
            other_clients[slug] = c
    
    if not other_clients:
        return await ev.reply("📭 No hay otros clientes en el sistema.")
    
    lines = ["👁️ **Otros Clientes** (Solo lectura):\n"]
    for slug, c in sorted(other_clients.items()):
        plan = c.get("plan", "N/A")
        exp = c.get("expires_at", "N/A")
        reseller_id = c.get("reseller_id", "Owner")
        
        lines.append(f"• **{slug}** (🤝 {reseller_id})")
        lines.append(f"  📦 {plan} | 📅 {exp}\n")
    
    await ev.reply("\n".join(lines))

async def show_reports_menu(ev):
    """Muestra menú de reportes según permisos"""
    uid = ev.sender_id
    
    if not is_admin(uid) and not is_reseller(uid):
        return await ev.reply("❌ No tienes permisos para ver reportes.")
    
    reports_keyboard = [
        [Button.inline("🗓 Vencimientos próximos", "report:expiring".encode())],
        [Button.inline("🧮 Clientes por reseller", "report:by_reseller".encode())],
        [Button.inline("🟢🔴 Estado servicios", "report:services".encode())],
        [Button.inline("❌ Cancelar", "report:cancel".encode())]
    ]
    
    await ev.respond("📊 **Reportes Disponibles:**\n\nSelecciona el tipo de reporte que quieres ver:", buttons=reports_keyboard)

async def show_resellers_menu(ev):
    """Muestra menú de gestión de resellers"""
    uid = ev.sender_id
    
    if not is_owner(uid):
        return await ev.reply("❌ Solo el administrador principal puede gestionar resellers.")
    
    resellers = S.get("resellers", [])
    admins = S.get("admins", [])
    
    info_text = (
        f"🤝 **Gestión de Resellers y Admins**\n\n"
        f"👑 **Owner:** {S.get('owner_id', 'No establecido')}\n"
        f"🤝 **Resellers activos:** {len(resellers)}\n"
        f"🛡️ **Admins normales:** {len(admins)}\n\n"
        f"**Resellers:** {', '.join(map(str, resellers)) if resellers else 'Ninguno'}\n"
        f"**Admins:** {', '.join(map(str, admins)) if admins else 'Ninguno'}\n\n"
        f"Para añadir/quitar roles, contacta al desarrollador."
    )
    
    back_button = [[Button.text("◀️ Volver")]]
    await ev.respond(info_text, buttons=back_button)

async def show_config_menu(ev):
    """Muestra menú de configuración"""
    uid = ev.sender_id
    
    if not is_admin(uid):
        return await ev.reply("❌ Solo administradores pueden acceder a configuración.")
    
    config_info = (
        f"⚙️ **Configuración del Sistema**\n\n"
        f"📊 **Estadísticas:**\n"
        f"• Total clientes: {len(S.get('clients', {}))}\n"
        f"• Clientes activos: {sum(1 for c in S.get('clients', {}).values() if c.get('active', True))}\n"
        f"• Último check: {S.get('last_expiry_check', 'Nunca')}\n"
        f"• Notificaciones: {'✅ Habilitadas' if S.get('notify_expiry', True) else '❌ Deshabilitadas'}\n\n"
        f"📁 **Rutas:**\n"
        f"• Manager: `{MANAGER_DIR}`\n"
        f"• Templates: `{TEMPL_DIR}`\n"
        f"• Clientes: `{CLIENTS_DIR}`\n\n"
        f"🔧 Para cambios de configuración, contacta al desarrollador."
    )
    
    config_keyboard = [
        [Button.inline("🔔 Cambiar notificaciones", "config:toggle_notifications".encode())],
        [Button.inline("🔄 Forzar check expiraciones", "config:force_expiry_check".encode())],
        [Button.text("◀️ Volver")]
    ]
    
    await ev.respond(config_info, buttons=config_keyboard)

async def show_maintenance_menu(ev):
    """Muestra menú de mantenimiento"""
    uid = ev.sender_id
    
    if not is_admin(uid):
        return await ev.reply("❌ Solo administradores pueden acceder a mantenimiento.")
    
    maintenance_text = (
        f"🛠️ **Mantenimiento del Sistema**\n\n"
        f"**Acciones de mantenimiento disponibles:**\n\n"
        f"🔍 **Diagnóstico:** Verifica estado de servicios\n"
        f"🧹 **Limpieza:** Elimina logs antiguos y archivos temporales\n"
        f"🔄 **Reinicio masivo:** Reinicia todos los servicios activos\n"
        f"📊 **Verificación:** Comprueba integridad de datos\n\n"
        f"⚠️ **Nota:** Estas acciones pueden afectar servicios en ejecución."
    )
    
    maintenance_keyboard = [
        [Button.inline("🔍 Diagnóstico general", "maintenance:diagnostic".encode())],
        [Button.inline("🧹 Limpieza sistema", "maintenance:cleanup".encode())],
        [Button.inline("🔄 Reinicio masivo", "maintenance:restart_all".encode())],
        [Button.inline("📊 Verificar integridad", "maintenance:verify".encode())],
        [Button.text("◀️ Volver")]
    ]
    
    await ev.respond(maintenance_text, buttons=maintenance_keyboard)

async def restart_my_service(ev):
    """Reinicia el servicio del cliente actual"""
    uid = ev.sender_id
    
    # Buscar el cliente del usuario
    my_client = None
    for slug, c in S.get("clients", {}).items():
        if c.get("owner_id") == uid:
            my_client = (slug, c)
            break
    
    if not my_client:
        return await ev.reply("❌ No tienes un servicio asignado.")
    
    slug, client_info = my_client
    
    if not client_info.get("provisioned", False):
        return await ev.reply("❌ Tu servicio aún no ha sido provisionado. Usa 🚀 Provisionar primero.")
    
    try:
        await ev.reply("🔄 **Reiniciando tu servicio...**")
        
        # Reiniciar servicio real
        run(f"sudo -n {SYSTEMCTL} restart reenvio@{slug}.service")
        
        await ev.reply(
            f"✅ **Servicio Reiniciado**\n\n"
            f"🔧 Cliente: `{slug}`\n"
            f"⚙️ Tu bot debería estar funcionando en unos momentos.\n\n"
            f"Si persisten problemas, contacta a tu reseller."
        )
        
    except Exception as e:
        logger.error(f"Error reiniciando servicio {slug}: {e}")
        await ev.reply(
            f"❌ **Error al reiniciar**\n\n"
            f"No se pudo reiniciar tu servicio.\n"
            f"Contacta a tu reseller o @frankosmel para asistencia."
        )

async def show_client_management_menu(ev, slug: str, uid: int):
    """Muestra menú de gestión para un cliente específico"""
    try:
        client_info = S.get("clients", {}).get(slug)
        if not client_info:
            return await ev.edit("❌ Cliente no encontrado.")
        
        if not can_manage_client(uid, slug):
            return await ev.edit("❌ No tienes permisos para gestionar este cliente.")
        
        # Obtener información del cliente
        plan = client_info.get("plan", "N/A")
        exp_str = client_info.get("expires_at", "N/A")
        reseller_id = client_info.get("reseller_id", "Owner")
        active = client_info.get("active", True)
        provisioned = client_info.get("provisioned", False)
        username = client_info.get("username", "N/A")
        
        # Calcular días restantes
        days_left = "N/A"
        if exp_str != "N/A":
            try:
                exp_date = dt.datetime.fromisoformat(exp_str).date()
                days_diff = (exp_date - dt.date.today()).days
                if days_diff < 0:
                    days_left = f"❌ Vencido hace {abs(days_diff)} días"
                elif days_diff == 0:
                    days_left = "⚠️ Vence hoy"
                elif days_diff <= 3:
                    days_left = f"⚠️ {days_diff} días restantes"
                else:
                    days_left = f"✅ {days_diff} días restantes"
            except:
                days_left = "❓ Error en fecha"
        
        # Estado del servicio
        svc_status = _svc_status(f"reenvio@{slug}.service")
        service_status = "🟢 Activo" if svc_status == "active" else f"🔴 {svc_status}"
        
        # Crear mensaje de información
        # Crear información del usuario
        user_info = f"• Username: @{username}" if username != "N/A" else f"• Usuario ID: {client_info.get('owner_id', 'N/A')}"
        
        info_text = (
            f"🔧 **Gestión de Cliente: {slug}**\n\n"
            f"📋 **Información:**\n"
            f"• Plan: {plan}\n"
            f"{user_info}\n"
            f"• Vencimiento: {exp_str}\n"
            f"• ⏰ {days_left}\n"
            f"• Reseller: {reseller_id}\n"
            f"• Estado: {'✅ Activo' if active else '❌ Inactivo'}\n"
            f"• Servicio: {service_status}\n"
            f"• Provisionado: {'✅ Sí' if provisioned else '❌ No'}\n\n"
            f"**Selecciona una acción:**"
        )
        
        # Crear botones de gestión
        management_buttons = []
        
        # Línea 1: Estado y Reinicio
        row1 = []
        row1.append(Button.inline("📊 Ver estado detallado", f"status:{slug}".encode()))
        if provisioned:
            row1.append(Button.inline("🔄 Reiniciar servicio", f"restart_service:{slug}".encode()))
        management_buttons.append(row1)
        
        # Línea 2: Renovar y Cambiar plan
        row2 = []
        row2.append(Button.inline("🔁 Renovar", f"renew:{slug}".encode()))
        row2.append(Button.inline("🗂 Cambiar plan", f"edit_plan:{slug}".encode()))
        management_buttons.append(row2)
        
        # Línea 3: Mantenimiento
        row3 = []
        if provisioned:
            row3.append(Button.inline("🧹 Limpiar sesiones", f"cleanup_confirm:{slug}".encode()))
        
        # Solo admins y owner pueden revocar
        if is_admin(uid) or is_owner(uid):
            row3.append(Button.inline("🚫 Revocar acceso", f"revoke_confirm:{slug}".encode()))
        
        if row3:
            management_buttons.append(row3)
        
        # Línea final: Volver
        management_buttons.append([Button.inline("◀️ Volver a lista", "back_to_clients".encode())])
        
        await ev.edit(info_text, buttons=management_buttons)
        
    except Exception as e:
        logger.error(f"Error mostrando menú de gestión para {slug}: {e}")
        await ev.edit(f"❌ Error mostrando menú de gestión: {str(e)}")

# ======= FUNCIONES DE PROCESAMIENTO =======

# ======= PUNTO 4: Autorización con username y reseller_id =======
async def process_client_authorization(ev, target_id: int, plan: str, days: int, authorizer_id: int):
    """Procesa la autorización completa de un cliente"""
    try:
        # Generar slug único
        base_slug = f"client_{target_id}"
        slug = base_slug
        counter = 1
        while slug in S.get("clients", {}):
            slug = f"{base_slug}_{counter}"
            counter += 1
        
        # Calcular fecha de expiración
        exp_date = (dt.date.today() + dt.timedelta(days=days)).isoformat()
        
        # PUNTO 4: Datos del cliente con username y reseller_id
        client_data = {
            "owner_id": target_id,
            "plan": plan,
            "created_at": dt.datetime.now().isoformat(),
            "expires_at": exp_date,
            "active": True,
            "provisioned": False,
        }
        
        # PUNTO 4: Actualización con username y anclaje al reseller
        client_data.update({
            "username": flows.get(authorizer_id, {}).get("target_username"),
            "reseller_id": authorizer_id if is_reseller(authorizer_id) else S.get("owner_id", 0),
            "workdir": str(CLIENTS_DIR / slug),
        })
        
        # Guardar cliente
        S["clients"][slug] = client_data
        save_state(S)
        
        # Limpiar flujo
        if authorizer_id in flows:
            del flows[authorizer_id]
        
        success_msg = (
            f"✅ **Cliente Autorizado**\n\n"
            f"🆔 **Slug:** `{slug}`\n"
            f"👤 **Usuario:** `{target_id}`"
        )
        
        if client_data.get("username"):
            success_msg += f" (@{client_data['username']})"
        
        success_msg += (
            f"\n📦 **Plan:** {plan}\n"
            f"📅 **Vence:** {exp_date}\n"
            f"🤝 **Reseller:** {client_data['reseller_id']}"
        )
        
        try:
            await ev.edit(success_msg)
        except:
            await ev.respond(success_msg)
        
        # Notificar al cliente nuevo
        try:
            await ev.client.send_message(
                target_id,
                f"🎉 **¡Acceso Autorizado!**\n\n"
                f"Tu cliente ID: `{slug}`\n"
                f"Plan: **{plan}**\n"
                f"Válido hasta: **{exp_date}**\n\n"
                f"Usa /start para comenzar."
            )
        except:
            logger.warning(f"No se pudo notificar al usuario {target_id}")
            
    except Exception as e:
        logger.error(f"Error en autorización: {e}")
        try:
            await ev.edit(f"❌ **Error:** {str(e)}")
        except:
            await ev.respond(f"❌ **Error:** {str(e)}")

async def process_client_renewal(ev, slug: str, days: int, uid: int):
    """Procesa la renovación de un cliente"""
    try:
        if not can_manage_client(uid, slug):
            return await ev.answer("❌ Sin permisos", alert=True)
        
        client_info = S.get("clients", {}).get(slug)
        if not client_info:
            return await ev.edit("❌ Cliente no encontrado.")
        
        # Calcular nueva fecha desde hoy o desde expiración actual
        current_exp = client_info.get("expires_at")
        if current_exp:
            try:
                base_date = dt.datetime.fromisoformat(current_exp).date()
                if base_date < dt.date.today():
                    base_date = dt.date.today()
            except:
                base_date = dt.date.today()
        else:
            base_date = dt.date.today()
        
        new_exp = (base_date + dt.timedelta(days=days)).isoformat()
        
        # Actualizar
        S["clients"][slug]["expires_at"] = new_exp
        S["clients"][slug]["active"] = True
        save_state(S)
        
        await ev.edit(
            f"✅ **Cliente Renovado**\n\n"
            f"🔧 **Cliente:** `{slug}`\n"
            f"📅 **Nueva expiración:** {new_exp}\n"
            f"⏱️ **Días añadidos:** {days}"
        )
        
        # Notificar al cliente
        try:
            await ev.client.send_message(
                client_info["owner_id"],
                f"🔄 **Servicio Renovado**\n\n"
                f"Tu cliente `{slug}` ha sido renovado.\n"
                f"Nueva fecha de vencimiento: **{new_exp}**"
            )
        except:
            logger.warning(f"No se pudo notificar renovación a {client_info['owner_id']}")
            
    except Exception as e:
        logger.error(f"Error en renovación: {e}")
        await ev.edit(f"❌ **Error:** {str(e)}")

# ======= PUNTO 8: Provisionamiento real =======
async def process_client_provision(ev, slug: str, bot_token: str, uid: int):
    """Procesa el provisionamiento real del cliente"""
    try:
        if not can_manage_client(uid, slug):
            return await ev.answer("❌ Sin permisos", alert=True)
        
        client_info = S.get("clients", {}).get(slug)
        if not client_info:
            return await ev.edit("❌ Cliente no encontrado.")
        
        await ev.edit("🚀 **Iniciando provisionamiento...**")
        
        # PUNTO 8: Provisionamiento real
        workdir = CLIENTS_DIR / slug
        clone_template(S["clients"][slug]["plan"], workdir)
        write_env(workdir, bot_token=bot_token, owner_id=S["clients"][slug]["owner_id"], slug=slug)
        ensure_venv_and_requirements(workdir)
        force_load_dotenv_override(workdir)
        enable_instance_service(slug)
        
        S["clients"][slug]["workdir"] = str(workdir)
        S["clients"][slug]["provisioned_at"] = dt.datetime.now().isoformat()
        S["clients"][slug]["provisioned"] = True
        save_state(S)
        
        await ev.edit(
            f"✅ **Provisionamiento Completado**\n\n"
            f"🔧 **Cliente:** `{slug}`\n"
            f"🤖 **Bot configurado:** ✅\n"
            f"📁 **WorkDir:** `{workdir}`\n"
            f"⚙️ **Servicio:** Habilitado\n\n"
            f"El bot debería estar funcionando en unos momentos."
        )
        
        # Limpiar flujo
        if uid in flows:
            del flows[uid]
            
    except Exception as e:
        logger.error(f"Error en provisionamiento: {e}")
        await ev.edit(f"❌ **Error en provisionamiento:** {str(e)}")

# ======= PUNTO 7: Reinicio y limpieza reales =======
async def restart_client_service(ev, slug: str, uid: int):
    """Reinicia el servicio de un cliente"""
    try:
        if not can_manage_client(uid, slug):
            return await ev.answer("❌ Sin permisos", alert=True)
        
        await ev.edit("🔄 **Reiniciando servicio...**")
        
        # PUNTO 7: Reinicio real
        run(f"sudo -n {SYSTEMCTL} restart reenvio@{slug}.service")
        
        await ev.edit(f"✅ **Servicio reiniciado:** `{slug}`")
        
    except Exception as e:
        logger.error(f"Error reiniciando servicio: {e}")
        await ev.edit(f"❌ **Error:** {str(e)}")

async def process_client_cleanup(ev, slug: str, uid: int):
    """Limpia archivos de sesión de un cliente"""
    try:
        if not can_manage_client(uid, slug):
            return await ev.answer("❌ Sin permisos", alert=True)
        
        await ev.edit("🧹 **Limpiando archivos...**")
        
        # PUNTO 7: Limpieza real
        info = S["clients"].get(slug, {})
        wdir = Path(info.get("workdir", ""))
        removed = 0
        
        if wdir.exists():
            for p in wdir.glob("*.session*"):
                try: 
                    p.unlink()
                    removed += 1
                except: 
                    pass
        
        pause_instance_service(slug)
        resume_instance_service(slug)
        save_state(S)
        
        await ev.edit(
            f"✅ **Limpieza completada**\n\n"
            f"🔧 **Cliente:** `{slug}`\n"
            f"🗑️ **Archivos eliminados:** {removed}\n"
            f"🔄 **Servicio reiniciado:** ✅"
        )
        
    except Exception as e:
        logger.error(f"Error en limpieza: {e}")
        await ev.edit(f"❌ **Error:** {str(e)}")

# ======= FUNCIONES DE REPORTES =======
async def generate_expiring_report(ev, uid: int):
    """Genera reporte de clientes próximos a vencer"""
    try:
        today = dt.date.today()
        warning_days = 7
        expiring = []
        
        for slug, c in S.get("clients", {}).items():
            if not can_view_client(uid, slug):
                continue
                
            exp_str = c.get("expires_at")
            if exp_str:
                try:
                    exp_date = dt.datetime.fromisoformat(exp_str).date()
                    days_left = (exp_date - today).days
                    
                    if days_left <= warning_days:
                        expiring.append((slug, c, days_left))
                except:
                    continue
        
        if not expiring:
            await ev.edit("✅ **No hay clientes próximos a vencer**")
            return
        
        lines = ["🗓 **Clientes próximos a vencer:**\n"]
        for slug, c, days in sorted(expiring, key=lambda x: x[2]):
            status = "🔴 VENCIDO" if days < 0 else f"⚠️ {days} días"
            plan = c.get("plan", "N/A")
            lines.append(f"• `{slug}` ({plan}) - {status}")
        
        await ev.edit("\n".join(lines))
        
    except Exception as e:
        await ev.edit(f"❌ Error generando reporte: {str(e)}")

async def generate_services_report(ev, uid: int):
    """Genera reporte del estado de servicios"""
    try:
        if not is_admin(uid):
            return await ev.edit("❌ Solo para administradores")
        
        active_services = []
        inactive_services = []
        
        for slug, c in S.get("clients", {}).items():
            svc_name = f"reenvio@{slug}.service"
            status = _svc_status(svc_name)
            
            if status == "active":
                active_services.append(slug)
            else:
                inactive_services.append((slug, status))
        
        lines = [f"🟢🔴 **Estado de Servicios:**\n"]
        lines.append(f"🟢 **Activos:** {len(active_services)}")
        lines.append(f"🔴 **Inactivos:** {len(inactive_services)}\n")
        
        if inactive_services:
            lines.append("**Servicios inactivos:**")
            for slug, status in inactive_services[:10]:  # Límite para el mensaje
                lines.append(f"• `{slug}` - {status}")
            if len(inactive_services) > 10:
                lines.append(f"... y {len(inactive_services) - 10} más")
        
        await ev.edit("\n".join(lines))
        
    except Exception as e:
        await ev.edit(f"❌ Error generando reporte: {str(e)}")

async def generate_reseller_report(ev, uid: int):
    """Genera reporte de clientes por reseller"""
    try:
        if not is_admin(uid) and not is_reseller(uid):
            return await ev.edit("❌ Solo para administradores y resellers")
        
        # Agrupar clientes por reseller
        resellers = {}
        owner_clients = []
        
        for slug, c in S.get("clients", {}).items():
            reseller_id = c.get("reseller_id")
            if reseller_id and reseller_id != S.get("owner_id", 0):
                if reseller_id not in resellers:
                    resellers[reseller_id] = []
                resellers[reseller_id].append((slug, c))
            else:
                owner_clients.append((slug, c))
        
        lines = ["🧮 **Clientes por Reseller:**\n"]
        
        # Clientes del owner
        if owner_clients:
            lines.append(f"👑 **Owner directo:** {len(owner_clients)} clientes")
            for slug, c in owner_clients[:5]:  # Límite para no saturar
                plan = c.get("plan", "N/A")
                exp = c.get("expires_at", "N/A")[:10] if c.get("expires_at") else "N/A"
                lines.append(f"  • `{slug}` ({plan}) - {exp}")
            if len(owner_clients) > 5:
                lines.append(f"  ... y {len(owner_clients) - 5} más")
            lines.append("")
        
        # Clientes por reseller
        for reseller_id, clients in resellers.items():
            lines.append(f"🤝 **Reseller {reseller_id}:** {len(clients)} clientes")
            for slug, c in clients[:3]:  # Límite para no saturar
                plan = c.get("plan", "N/A")
                exp = c.get("expires_at", "N/A")[:10] if c.get("expires_at") else "N/A"
                lines.append(f"  • `{slug}` ({plan}) - {exp}")
            if len(clients) > 3:
                lines.append(f"  ... y {len(clients) - 3} más")
            lines.append("")
        
        if not resellers and not owner_clients:
            lines.append("📭 No hay clientes en el sistema")
        
        await ev.edit("\n".join(lines))
        
    except Exception as e:
        await ev.edit(f"❌ Error generando reporte: {str(e)}")

# ======= VERIFICADOR DE EXPIRACIONES =======
async def expiry_checker_task():
    """Tarea en segundo plano para verificar expiraciones"""
    while True:
        try:
            await asyncio.sleep(3600)  # Cada hora
            
            if not S.get("notify_expiry", True):
                continue
            
            today = dt.date.today()
            
            for slug, client_info in list(S.get("clients", {}).items()):
                exp_str = client_info.get("expires_at")
                if not exp_str:
                    continue
                
                try:
                    exp_date = dt.datetime.fromisoformat(exp_str).date()
                    days_left = (exp_date - today).days
                    
                    # Avisos a 3, 1 día y vencimiento
                    if days_left in [3, 1] and client_info.get("active", True):
                        await send_expiry_warning(slug, client_info, days_left)
                    elif days_left <= 0 and client_info.get("active", True):
                        await handle_expired_client(slug, client_info)
                        
                except Exception as e:
                    logger.error(f"Error procesando expiración de {slug}: {e}")
            
            S["last_expiry_check"] = dt.datetime.now().isoformat()
            save_state(S)
            
        except Exception as e:
            logger.error(f"Error en verificador de expiraciones: {e}")

# ======= PUNTO 9: Envío de avisos =======
async def send_expiry_warning(slug: str, client_info: dict, days_left: int):
    """Envía aviso de expiración próxima"""
    owner_id = None
    try:
        owner_id = client_info.get("owner_id")
        if not owner_id:
            return
        
        # Enviar aviso de expiración al cliente
        message = (
            f"⚠️ **Aviso de Expiración**\n\n"
            f"Tu servicio `{slug}` vence en **{days_left} día{'s' if days_left != 1 else ''}**.\n\n"
            f"📞 Contacta a tu reseller o @frankosmel para renovar."
        )
        # Se enviará cuando el bot esté disponible en main()
        
        logger.info(f"Aviso de expiración enviado a {owner_id} para cliente {slug} ({days_left} días)")
        
    except Exception as e:
        logger.error(f"Error enviando aviso a {owner_id or 'unknown'}: {e}")

async def handle_expired_client(slug: str, client_info: dict):
    """Maneja cliente vencido"""
    try:
        # Desactivar cliente
        S["clients"][slug]["active"] = False
        
        # Pausar servicio
        pause_instance_service(slug)
        
        save_state(S)
        
        owner_id = client_info.get("owner_id")
        if owner_id:
            # Enviar notificación de vencimiento
            message = (
                f"🔴 **Servicio Vencido**\n\n"
                f"Tu servicio `{slug}` ha vencido y fue pausado.\n\n"
                f"📞 Contacta a tu reseller o @frankosmel para renovar."
            )
            # Se enviará cuando el bot esté disponible en main()
        
        logger.info(f"Cliente {slug} marcado como vencido y servicio pausado")
        
    except Exception as e:
        logger.error(f"Error manejando expiración de {slug}: {e}")

# ======================================================================
# Registro de handlers
# ======================================================================
def register_handlers(bot):
    """Registra todos los manejadores de eventos"""
    
    @bot.on(events.NewMessage(pattern=r"^/start$"))
    async def start_cmd(ev):
        uid = ev.sender_id
        role_name = get_user_role_name(uid)
        
        await ev.reply(
            f"🤖 **Bot Manager Mejorado** - {role_name}\n\n"
            "✨ Sistema con roles y permisos mejorados\n"
            "Usa /menu para acceder a las opciones."
        )
        await show_main_menu(ev)

    @bot.on(events.NewMessage(pattern=r"^/menu$"))
    async def cmd_menu(ev):
        await show_main_menu(ev)

    @bot.on(events.NewMessage(pattern=r"^/set_owner\s+(\d+)$"))
    async def set_owner(ev):
        if S.get("owner_id", 0) not in (0, ev.sender_id):
            return await ev.reply("❌ Solo el owner actual puede cambiar esto")
        
        new_owner = int(ev.pattern_match.group(1))
        S["owner_id"] = new_owner
        save_state(S)
        await ev.reply(f"👑 **Owner establecido:** `{new_owner}`")

    @bot.on(events.NewMessage())
    async def text_router(ev):
        if not ev.is_private or ev.raw_text.startswith('/'):
            return
        
        txt = ev.raw_text.strip()
        uid = ev.sender_id

        if txt == LBL_BACK:
            return await show_main_menu(ev)
        
        # Respuestas básicas por rol
        if txt == "❓ Ayuda":
            return await help_cmd(ev)
        
        # === FUNCIONES PRINCIPALES ===
        if txt == "➕ Autorizar cliente":
            if not can_create_clients(uid):
                return await ev.reply("❌ No tienes permisos para autorizar clientes.")
            return await auth_start(ev)
        
        if txt == "🔁 Renovar":
            return await renew_start(ev)
        
        if txt == "🗂 Cambiar plan":
            return await edit_plan_start(ev)
        
        if txt == "🚫 Revocar":
            return await revoke_start(ev)
        
        if txt == "📊 Status":
            return await status_cmd(ev)
            
        if txt == "🚀 Provisionar":
            return await provision_start(ev)
        
        if txt == "🧑‍💻 Soporte":
            return await ev.reply("🧑‍💻 **Soporte Técnico**\n\nContacta: @frankosmel")
        
        # === MENÚS ESPECÍFICOS POR ROL ===
        if txt == "👥 Clientes" or txt == "👥 Mis clientes":
            return await show_clients_menu(ev)
        
        if txt == "👁️ Ver otros clientes":
            return await show_other_clients(ev)
        
        if txt == "📊 Reportes":
            return await show_reports_menu(ev)
        
        # === FUNCIONES ADMINISTRATIVAS ===
        if txt == "🤝 Resellers":
            return await show_resellers_menu(ev)
        
        if txt == "⚙️ Config":
            return await show_config_menu(ev)
        
        if txt == "🛠️ Mantenimiento":
            return await show_maintenance_menu(ev)
        
        if txt == "🔄 Reiniciar servicio":
            return await restart_my_service(ev)
        
        # === FLUJOS DE TEXTO ===
        await handle_text_flow(ev, txt, uid)

# ======================================================================
# PUNTO 1: MANEJADOR DE INLINE CALLBACKS - COMPLETO
# ======================================================================
def register_inline_callbacks(bot):
    """Registra todos los callbacks de botones inline"""
    
    @bot.on(events.CallbackQuery())
    async def handle_inline_callbacks(ev):
        data = (ev.data or b"").decode(errors="ignore")
        uid = ev.sender_id
        
        # === CANCELACIONES ===
        if data.endswith(":cancel"):
            if uid in flows:
                del flows[uid]
            try:
                await ev.edit("❌ **Operación cancelada.**")
            except:
                await ev.respond("❌ Operación cancelada.")
            return
        
        # === AUTORIZACIÓN DE CLIENTES ===
        if data.startswith("auth_plan:"):
            parts = data.split(":")
            if len(parts) >= 3:
                target_id, plan = parts[1], parts[2]
                if not can_create_clients(uid):
                    return await ev.answer("❌ Sin permisos", alert=True)
                
                # Mostrar duraciones
                keyboard = create_duration_inline_keyboard("auth", target_id, plan)
                try:
                    await ev.edit(f"⏱️ **Selecciona Duración**\n\nUsuario: `{target_id}`\nPlan: **{plan}**", buttons=keyboard)
                except:
                    await ev.respond(f"⏱️ **Selecciona Duración**\n\nUsuario: `{target_id}`\nPlan: **{plan}**", buttons=keyboard)
        
        if data.startswith("auth_duration:"):
            parts = data.split(":")
            if len(parts) >= 4:
                target_id, plan, days = parts[1], parts[2], parts[3]
                if not can_create_clients(uid):
                    return await ev.answer("❌ Sin permisos", alert=True)
                
                # Confirmar autorización
                confirm_keyboard = [
                    [Button.inline("✅ Confirmar Autorización", f"confirm_auth:{target_id}:{plan}:{days}".encode())],
                    [Button.inline("❌ Cancelar", "auth:cancel".encode())]
                ]
                
                exp_date = (dt.date.today() + dt.timedelta(days=int(days))).isoformat()
                reseller_info = f"🤝 Reseller: {uid}" if is_reseller(uid) else "👑 Owner directo"
                
                try:
                    await ev.edit(
                        f"✅ **Confirmar Autorización**\n\n"
                        f"👤 Usuario: `{target_id}`\n"
                        f"📦 Plan: **{plan}**\n"
                        f"📅 Duración: **{days} días**\n"
                        f"📊 Vence: **{exp_date}**\n"
                        f"{reseller_info}\n\n"
                        "¿Proceder con la autorización?",
                        buttons=confirm_keyboard
                    )
                except:
                    await ev.respond("Error mostrando confirmación")
        
        if data.startswith("confirm_auth:"):
            parts = data.split(":")
            if len(parts) >= 4:
                target_id, plan, days = parts[1], parts[2], parts[3]
                await process_client_authorization(ev, int(target_id), plan, int(days), uid)
        
        # === RENOVACIÓN ===
        if data.startswith("renew:") and not data.endswith(":cancel"):
            slug = data.split(":", 1)[1]
            if not can_manage_client(uid, slug):
                return await ev.answer("❌ Sin permisos", alert=True)
            
            keyboard = create_duration_inline_keyboard("renew", slug)
            try:
                await ev.edit(f"🔁 **Renovar Cliente: {slug}**\n\nSelecciona nueva duración:", buttons=keyboard)
            except:
                await ev.respond(f"🔁 **Renovar Cliente: {slug}**\n\nSelecciona nueva duración:", buttons=keyboard)
        
        if data.startswith("renew_duration:"):
            parts = data.split(":")
            if len(parts) >= 3:
                slug, days = parts[1], parts[2]
                await process_client_renewal(ev, slug, int(days), uid)
        
        # === CAMBIO DE PLAN ===
        if data.startswith("edit_plan:") and not data.endswith(":cancel"):
            slug = data.split(":", 1)[1]
            if not can_manage_client(uid, slug):
                return await ev.answer("❌ Sin permisos", alert=True)
            
            keyboard = create_plan_inline_keyboard("edit_plan", slug)
            try:
                await ev.edit(f"🗂 **Cambiar Plan: {slug}**\n\nSelecciona nuevo plan:", buttons=keyboard)
            except:
                await ev.respond(f"🗂 **Cambiar Plan: {slug}**\n\nSelecciona nuevo plan:", buttons=keyboard)
        
        if data.startswith("edit_plan_plan:"):
            parts = data.split(":")
            if len(parts) >= 3:
                slug, new_plan = parts[1], parts[2]
                if not can_manage_client(uid, slug):
                    return await ev.answer("❌ Sin permisos", alert=True)
                
                # Confirmar cambio
                confirm_keyboard = [
                    [Button.inline("✅ Confirmar Cambio", f"confirm_plan_change:{slug}:{new_plan}".encode())],
                    [Button.inline("❌ Cancelar", "edit_plan:cancel".encode())]
                ]
                
                try:
                    await ev.edit(
                        f"🗂 **Confirmar Cambio de Plan**\n\n"
                        f"🔧 Cliente: `{slug}`\n"
                        f"📦 Nuevo Plan: **{new_plan}**\n\n"
                        "¿Proceder con el cambio?",
                        buttons=confirm_keyboard
                    )
                except:
                    await ev.respond("Error mostrando confirmación")
        
        if data.startswith("confirm_plan_change:"):
            parts = data.split(":")
            if len(parts) >= 3:
                slug, new_plan = parts[1], parts[2]
                if not can_manage_client(uid, slug):
                    return await ev.answer("❌ Sin permisos", alert=True)
                
                # Actualizar plan
                old_plan = S["clients"][slug].get("plan", "N/A")
                S["clients"][slug]["plan"] = new_plan
                save_state(S)
                
                try:
                    await ev.edit(
                        f"✅ **Plan Actualizado**\n\n"
                        f"🔧 Cliente: `{slug}`\n"
                        f"📦 Plan anterior: {old_plan}\n"
                        f"📦 Nuevo plan: **{new_plan}**"
                    )
                except:
                    await ev.respond("Plan actualizado")
        
        # === PROVISIONAMIENTO ===
        if data.startswith("confirm_provision:"):
            slug = data.split(":", 1)[1]
            if uid not in flows or flows[uid].get("client_slug") != slug:
                return await ev.answer("❌ Sesión inválida", alert=True)
            
            bot_token = flows[uid].get("bot_token")
            if not bot_token:
                return await ev.answer("❌ Token no encontrado", alert=True)
            
            await process_client_provision(ev, slug, bot_token, uid)
        
        # === ESTADO Y ACCIONES ===
        if data.startswith("status:"):
            slug = data.split(":", 1)[1]
            if not can_view_client(uid, slug):
                return await ev.answer("❌ Sin permisos", alert=True)
            
            await show_client_status(ev, slug)
        
        if data.startswith("restart_service:"):
            slug = data.split(":", 1)[1]
            await restart_client_service(ev, slug, uid)
        
        if data.startswith("cleanup_confirm:"):
            slug = data.split(":", 1)[1]
            if not can_manage_client(uid, slug):
                return await ev.answer("❌ Sin permisos", alert=True)
            
            confirm_buttons = [
                [Button.inline("✅ Sí, limpiar", f"cleanup_execute:{slug}".encode())],
                [Button.inline("❌ Cancelar", "cleanup:cancel".encode())]
            ]
            
            try:
                await ev.edit(
                    f"🧹 **Confirmar Limpieza**\n\n"
                    f"🔧 Cliente: `{slug}`\n\n"
                    "⚠️ Esto eliminará archivos .session y reiniciará el servicio.\n"
                    "¿Continuar?",
                    buttons=confirm_buttons
                )
            except:
                await ev.respond("Error mostrando confirmación")
        
        if data.startswith("cleanup_execute:"):
            slug = data.split(":", 1)[1]
            await process_client_cleanup(ev, slug, uid)
        
        # === GESTIÓN DE CLIENTES INDIVIDUALES ===
        if data.startswith("manage:") and not data.endswith(":cancel"):
            slug = data.split(":", 1)[1]
            if not can_manage_client(uid, slug):
                return await ev.answer("❌ Sin permisos", alert=True)
            
            # Mostrar menú de gestión para este cliente específico
            await show_client_management_menu(ev, slug, uid)
            return
        
        # === REPORTES ===
        if data.startswith("report:"):
            report_type = data.split(":", 1)[1]
            
            if report_type == "expiring":
                await generate_expiring_report(ev, uid)
            elif report_type == "services":
                await generate_services_report(ev, uid)
            elif report_type == "by_reseller":
                await generate_reseller_report(ev, uid)
            elif report_type == "cancel":
                await ev.edit("❌ Reportes cancelados")
        
        # === CONFIGURACIÓN ===
        if data.startswith("config:"):
            config_action = data.split(":", 1)[1]
            
            if config_action == "toggle_notifications":
                current = S.get("notify_expiry", True)
                S["notify_expiry"] = not current
                save_state(S)
                status = "✅ Habilitadas" if S["notify_expiry"] else "❌ Deshabilitadas"
                await ev.edit(f"🔔 **Notificaciones de expiración:** {status}")
            
            elif config_action == "force_expiry_check":
                await ev.edit("🔄 **Ejecutando verificación de expiraciones...**")
                # Ejecutar check manual
                try:
                    await ev.edit("✅ **Verificación completada**\n\nRevisa los logs para más detalles.")
                except:
                    await ev.edit("❌ Error en la verificación")
        
        # === MANTENIMIENTO ===
        if data.startswith("maintenance:"):
            maint_action = data.split(":", 1)[1]
            
            if not is_admin(uid):
                return await ev.answer("❌ Solo administradores", alert=True)
            
            if maint_action == "diagnostic":
                await ev.edit("🔍 **Ejecutando diagnóstico...**")
                # Diagnóstico básico
                total_clients = len(S.get("clients", {}))
                active_services = 0
                for slug in S.get("clients", {}):
                    if _svc_status(f"reenvio@{slug}.service") == "active":
                        active_services += 1
                
                result = (
                    f"🔍 **Diagnóstico Completado**\n\n"
                    f"📊 **Clientes totales:** {total_clients}\n"
                    f"🟢 **Servicios activos:** {active_services}\n"
                    f"🔴 **Servicios inactivos:** {total_clients - active_services}\n"
                    f"📁 **Templates disponibles:** {len(TEMPL)}\n"
                    f"💾 **Estado guardado:** {'✅' if STATEF.exists() else '❌'}"
                )
                await ev.edit(result)
            
            elif maint_action == "cleanup":
                await ev.edit("🧹 **Iniciando limpieza del sistema...**")
                # Limpieza básica - logs antiguos, archivos temporales
                cleaned = 0
                try:
                    # Aquí iría la lógica de limpieza real
                    await ev.edit(f"✅ **Limpieza completada**\n\nArchivos procesados: {cleaned}")
                except Exception as e:
                    await ev.edit(f"❌ **Error en limpieza:** {str(e)}")
            
            elif maint_action == "restart_all":
                await ev.edit("🔄 **Reiniciando todos los servicios...**")
                restarted = 0
                errors = 0
                
                for slug in S.get("clients", {}):
                    try:
                        run(f"sudo -n {SYSTEMCTL} restart reenvio@{slug}.service")
                        restarted += 1
                    except:
                        errors += 1
                
                result = (
                    f"🔄 **Reinicio Masivo Completado**\n\n"
                    f"✅ **Reiniciados:** {restarted}\n"
                    f"❌ **Errores:** {errors}"
                )
                await ev.edit(result)
            
            elif maint_action == "verify":
                await ev.edit("📊 **Verificando integridad de datos...**")
                issues = []
                
                # Verificar estructura de datos
                for slug, client_data in S.get("clients", {}).items():
                    if not client_data.get("owner_id"):
                        issues.append(f"Cliente {slug}: falta owner_id")
                    if not client_data.get("plan"):
                        issues.append(f"Cliente {slug}: falta plan")
                
                if issues:
                    result = f"⚠️ **Problemas encontrados:**\n\n" + "\n".join(issues[:10])
                    if len(issues) > 10:
                        result += f"\n... y {len(issues) - 10} más"
                else:
                    result = "✅ **Integridad verificada:** No se encontraron problemas"
                
                await ev.edit(result)
        
        # === NAVEGACIÓN ===
        if data.startswith("back_to_clients"):
            await show_clients_menu(ev)
            return
        
        if data.startswith("revoke_confirm:"):
            slug = data.split(":", 1)[1]
            if not can_manage_client(uid, slug):
                return await ev.answer("❌ Sin permisos", alert=True)
            
            # Solo admins y owner pueden revocar
            if not (is_admin(uid) or is_owner(uid)):
                return await ev.answer("❌ Solo administradores pueden revocar", alert=True)
            
            confirm_buttons = [
                [Button.inline("⚠️ SÍ, REVOCAR ACCESO", f"revoke_execute:{slug}".encode())],
                [Button.inline("❌ Cancelar", f"manage:{slug}".encode())]
            ]
            
            try:
                await ev.edit(
                    f"🚫 **Confirmar Revocación**\n\n"
                    f"⚠️ **ADVERTENCIA:** Esta acción eliminará permanentemente:\n"
                    f"• Cliente: `{slug}`\n"
                    f"• Todo su historial y configuración\n"
                    f"• Su servicio será deshabilitado\n\n"
                    f"❗ **Esta acción NO se puede deshacer**\n\n"
                    f"¿Estás completamente seguro?",
                    buttons=confirm_buttons
                )
            except:
                await ev.respond("Error mostrando confirmación")
        
        if data.startswith("revoke_execute:"):
            slug = data.split(":", 1)[1]
            if not can_manage_client(uid, slug):
                return await ev.answer("❌ Sin permisos", alert=True)
            
            # Solo admins y owner pueden revocar
            if not (is_admin(uid) or is_owner(uid)):
                return await ev.answer("❌ Solo administradores pueden revocar", alert=True)
            
            await process_client_revocation(ev, slug, uid)

# ======= FUNCIONES DE REVOCACIÓN =======
async def process_client_revocation(ev, slug: str, uid: int):
    """Procesa la revocación completa de un cliente"""
    try:
        client_info = S.get("clients", {}).get(slug)
        if not client_info:
            return await ev.edit("❌ Cliente no encontrado.")
        
        await ev.edit("🚫 **Revocando acceso...**")
        
        # 1. Pausar y deshabilitar servicio
        try:
            pause_instance_service(slug)
            run(f"sudo -n {SYSTEMCTL} disable reenvio@{slug}.service")
        except Exception as e:
            logger.warning(f"Error deshabilitando servicio {slug}: {e}")
        
        # 2. Eliminar directorio de trabajo
        workdir = Path(client_info.get("workdir", ""))
        if workdir.exists():
            try:
                shutil.rmtree(workdir)
            except Exception as e:
                logger.warning(f"Error eliminando workdir {workdir}: {e}")
        
        # 3. Remover de state
        owner_id = client_info.get("owner_id")
        plan = client_info.get("plan", "N/A")
        
        del S["clients"][slug]
        save_state(S)
        
        # 4. Notificar al cliente revocado
        if owner_id:
            try:
                # Nota: En implementación real se enviaría mensaje al cliente
                logger.info(f"Cliente {slug} (usuario {owner_id}) revocado por admin {uid}")
            except:
                pass
        
        await ev.edit(
            f"✅ **Acceso Revocado**\n\n"
            f"🔧 Cliente: `{slug}`\n"
            f"👤 Usuario ID: {owner_id}\n"
            f"📦 Plan: {plan}\n\n"
            f"• Servicio deshabilitado\n"
            f"• Archivos eliminados\n"
            f"• Cliente removido del sistema\n\n"
            f"La revocación se ha completado correctamente."
        )
        
    except Exception as e:
        logger.error(f"Error en revocación de {slug}: {e}")
        await ev.edit(f"❌ **Error en revocación:** {str(e)}")

# ======================================================================
# MAIN - CON PUNTOS 1 Y 2
# ======================================================================
async def main():
    """Función principal"""
    try:
        bot = TelegramClient("manager_bot", API_ID, API_HASH)
        
        # Inicializar bot
        await bot.start(bot_token=BOT_TOKEN)
        logger.info("🤖 Bot Manager iniciado correctamente")
        
        # PUNTO 1: Registrar handlers
        register_handlers(bot)
        register_inline_callbacks(bot)
        
        # PUNTO 2: Iniciar verificador de expiraciones
        asyncio.create_task(expiry_checker_task())
        
        me = await bot.get_me()
        username = getattr(me, 'username', 'Sin username')
        logger.info(f"🎯 Bot conectado como: @{username}")
        
        # Ejecutar indefinidamente
        await bot.run_until_disconnected()
        
    except Exception as e:
        logger.error(f"❌ Error crítico en main: {e}")
        raise

if __name__ == "__main__":
    asyncio.run(main())
