# notify_expiries.py
import os, json, asyncio, datetime as dt
from pathlib import Path
from typing import Dict, Any
from telethon import TelegramClient, Button
from dotenv import load_dotenv

ROOT        = Path.home() / "CLIENTES_BOT_REENVIO"
MANAGER_DIR = ROOT / "manager"
STATEF      = MANAGER_DIR / "state.json"

CONTACT_URL = "https://t.me/frankosme1"  # enlace del admin

# ---------- Utilidades ----------
def load_state() -> Dict[str, Any]:
    if not STATEF.exists():
        return {"owner_id":0,"admins":[], "resellers":[], "clients":{}, "notify_expiry": True}
    return json.loads(STATEF.read_text())

def save_state(S: Dict[str, Any]) -> None:
    STATEF.write_text(json.dumps(S, indent=2, ensure_ascii=False))

def safe_get_date(iso_str: str):
    try:
        return dt.date.fromisoformat(iso_str[:10])
    except:
        return None

def today_str():
    return dt.date.today().isoformat()

def ensure_notice_log(client: Dict[str, Any]) -> Dict[str, Any]:
    if "notice_log" not in client:
        client["notice_log"] = {}  # {"pre":"YYYY-MM-DD","due":"YYYY-MM-DD","post":"YYYY-MM-DD"}
    return client["notice_log"]

# ---------- Mensajes ----------
def msg_pre(slug, plan, exp):
    return (
        "⏰ *Recordatorio de renovación*\n\n"
        f"Mañana vence tu plan **{plan}** para `{slug}`.\n"
        "Si no renuevas, tu bot podría pausar sus funciones.\n\n"
        "Pulsa el botón para renovar o hablar con un asesor 👇"
    )

def msg_due(slug, plan, exp):
    return (
        "🔴 *Tu plan ha vencido*\n\n"
        f"El servicio `{slug}` (plan **{plan}**) ha sido *pausado* por vencimiento.\n\n"
        "Pulsa para renovar y reactivar tu bot de inmediato 👇"
    )

def msg_post(slug, plan, exp):
    return (
        "📌 *Seguimiento de renovación*\n\n"
        f"Ayer venció tu plan **{plan}** para `{slug}` y el bot sigue pausado.\n\n"
        "¿Deseas renovarlo ahora? Toca el botón para asistencia 👇"
    )

def buttons():
    return [[
        Button.url("💳 Renovar / Contactar", CONTACT_URL)
    ]]

# ---------- Envío (por bot del cliente) ----------
async def notify_for_client(client, slug):
    # workdir y .env del bot del cliente
    wdir = Path(client.get("workdir", ""))
    envf = wdir / ".env"
    if not wdir.exists() or not envf.exists():
        return  # no provisionado o sin env

    # carga del .env del cliente
    load_dotenv(envf)
    API_ID     = int(os.getenv("API_ID","0"))
    API_HASH   = os.getenv("API_HASH","")
    BOT_TOKEN  = os.getenv("BOT_TOKEN","")
    OWNER_ID   = int(os.getenv("OWNER_ID","0"))
    if not (API_ID and API_HASH and BOT_TOKEN and OWNER_ID):
        return

    exp_str  = client.get("expires_at")
    plan     = client.get("plan","N/A")
    exp_date = safe_get_date(exp_str) if exp_str else None
    if not exp_date:
        return

    today     = dt.date.today()
    days_left = (exp_date - today).days

    # ¿Qué aviso toca?
    notice_type = None
    text = None

    if days_left == 1:
        notice_type = "pre"   # D-1
        text = msg_pre(slug, plan, exp_date.isoformat())
    elif days_left == 0:
        notice_type = "due"   # Día 0
        text = msg_due(slug, plan, exp_date.isoformat())
    elif days_left == -1:
        notice_type = "post"  # D+1
        text = msg_post(slug, plan, exp_date.isoformat())

    if not notice_type:
        return  # hoy no corresponde enviar nada

    # Anti-duplicado
    nlog = ensure_notice_log(client)
    if nlog.get(notice_type) == today.isoformat():
        return  # ya se envió este aviso hoy

    # Enviar desde el bot del cliente
    session_name = f"notice_{slug}"
    c = TelegramClient(session_name, API_ID, API_HASH)
    await c.start(bot_token=BOT_TOKEN)
    try:
        await c.send_message(OWNER_ID, text, buttons=buttons(), parse_mode="md")
        # marcar envío
        nlog[notice_type] = today.isoformat()
    finally:
        await c.disconnect()

async def main():
    S = load_state()
    clients = S.get("clients", {})
    # recorrer todos los clientes
    for slug, client in list(clients.items()):
        try:
            await notify_for_client(client, slug)
        except Exception as e:
            # no rompemos el ciclo por un cliente
            print(f"[WARN] Error notificando {slug}: {e}")

    save_state(S)

if __name__ == "__main__":
    asyncio.run(main())
