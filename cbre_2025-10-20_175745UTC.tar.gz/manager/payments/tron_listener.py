# ~/CLIENTES_BOT_REENVIO/manager/payments/tron_listener.py
import os, json, asyncio, httpx, time
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
API_HOST = os.getenv("MANAGER_HOST","127.0.0.1")
API_PORT = os.getenv("MANAGER_PORT","8080")
MANAGER_TOKEN = os.getenv("MANAGER_TOKEN","supersecreto")
TRONGRID = "https://api.trongrid.io"
TRONGRID_API_KEY = os.getenv("TRONGRID_API_KEY") or None
USDT = os.getenv("USDT_TRC20_CONTRACT","TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t")
CONF = int(os.getenv("CONFIRMATIONS","10"))
INTERVAL = int(os.getenv("CHECK_INTERVAL_SEC","15"))

BASE = Path(__file__).parent
WALLETS = BASE / "wallets.json"
PROCESSED = BASE / "processed.json"

def load_json(p, default):
    if not p.exists(): p.write_text(json.dumps(default, indent=2), encoding="utf-8")
    return json.loads(p.read_text(encoding="utf-8"))

async def credit(reseller_id, amount):
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.post(f"http://{API_HOST}:{API_PORT}/reseller/credit",
                         headers={"x-token":MANAGER_TOKEN},
                         json={"reseller_id": reseller_id, "monto": float(amount)})
        r.raise_for_status()
        return r.json()

async def fetch_trc20(addr):
    headers = {"TRON-PRO-API-KEY": TRONGRID_API_KEY} if TRONGRID_API_KEY else {}
    url = (f"{TRONGRID}/v1/accounts/{addr}/transactions/trc20?"
           f"contract_address={USDT}&only_confirmed=true&limit=50")
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(url, headers=headers)
        r.raise_for_status()
        data = r.json().get("data", []) or []
        return data

def tx_key(tx):
    return f"{tx.get('transaction_id')}"

def confirmations_ok(tx):
    # TronGrid devuelve 'block_timestamp' y ya marca confirmed; usamos CONF como colchón lógico.
    return True  # already confirmed by API

async def loop_listener():
    wallets = load_json(WALLETS, {})
    processed = load_json(PROCESSED, {"txids": []})
    seen = set(processed.get("txids", []))

    while True:
        try:
            for addr, meta in wallets.items():
                reseller_id = meta.get("reseller_id")
                transfers = await fetch_trc20(addr)
                for tx in transfers:
                    if tx.get("to") != addr: 
                        continue
                    if tx.get("token_info",{}).get("address") != USDT:
                        continue
                    tid = tx_key(tx)
                    if tid in seen:
                        continue
                    if not confirmations_ok(tx):
                        continue
                    amount = float(tx.get("value", "0"))
                    if amount <= 0:
                        continue
                    # Acredita
                    resp = await credit(reseller_id, amount)
                    print(f"[CREDIT] {reseller_id} +{amount} USDT via {tid} → saldo {resp.get('saldo')}")
                    seen.add(tid)
                    processed["txids"] = list(seen)
                    PROCESSED.write_text(json.dumps(processed, indent=2), encoding="utf-8")
        except Exception as e:
            print(f"[ERROR] {e}")
        await asyncio.sleep(INTERVAL)

if __name__ == "__main__":
    asyncio.run(loop_listener())
