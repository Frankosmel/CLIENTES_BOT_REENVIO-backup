# manager_api.py
# FastAPI mínimo para Manager (lectura/escritura sobre state.json existente)
# Estructura esperada en state.json:
#   usernames: { "<tg_id>": "Eduard_vene", ... }
#   resellers: [ "<tg_id>", ... ]
#   billing: { resellers: { "<tg_id>": { balance, credits, ... } } }
#
# ENV requeridas:
#   MANAGER_TOKEN=xxxxx
#   STATE_FILE=/home/ubuntu/CLIENTES_BOT_REENVIO/manager/state.json
#
# Ejecutar local:
#   uvicorn manager_api:app --host 127.0.0.1 --port 8080

import os
import json
import time
import threading
from pathlib import Path
from typing import Dict, Any, Optional

from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel

TOKEN = os.getenv("MANAGER_TOKEN")
if not TOKEN:
    raise RuntimeError("MANAGER_TOKEN no definido en entorno.")

STATE_PATH = Path(os.getenv("STATE_FILE", "/home/ubuntu/CLIENTES_BOT_REENVIO/manager/state.json"))
LOCK = threading.Lock()
app = FastAPI()


# ---------- Helpers ----------
def sload() -> Dict[str, Any]:
    """Carga el state.json o crea estructura mínima compatible."""
    if not STATE_PATH.exists():
        return {"usernames": {}, "resellers": [], "billing": {"resellers": {}}, "currency": "USD"}
    with LOCK, STATE_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def ssave(s: Dict[str, Any]) -> None:
    """Guarda de forma atómica."""
    tmp = STATE_PATH.with_suffix(".json.tmp")
    with LOCK, tmp.open("w", encoding="utf-8") as f:
        json.dump(s, f, ensure_ascii=False, indent=2)
    tmp.replace(STATE_PATH)


def require(h: Optional[str]) -> None:
    if h != TOKEN:
        raise HTTPException(status_code=401, detail="No autorizado")


def norm_username(u: str) -> str:
    u = u.strip()
    if u.startswith("@"):
        u = u[1:]
    return u.lower()


def resolve_reseller_id(s: Dict[str, Any], reseller_id: str) -> Optional[str]:
    """Devuelve el TG ID (str) a partir de @username o ID numérico."""
    rid = reseller_id.strip()
    if rid.isdigit():
        return rid
    uname = norm_username(rid)
    usermap: Dict[str, str] = s.get("usernames", {})
    for tg_id, u in usermap.items():
        if isinstance(u, str) and norm_username(u) == uname:
            return tg_id
    return None


def get_or_create_account(s: Dict[str, Any], tg_id: str) -> Dict[str, Any]:
    """Asegura estructura de reseller y devuelve su cuenta de billing."""
    res_arr = s.setdefault("resellers", [])
    if tg_id not in res_arr:
        res_arr.append(tg_id)

    billing = s.setdefault("billing", {}).setdefault("resellers", {})
    acct = billing.setdefault(tg_id, {})
    acct.setdefault("balance", 0.0)
    acct.setdefault("credits", 0)
    acct.setdefault("credit_limit", 0.0)
    acct.setdefault("discount_pct", 0.0)
    acct.setdefault("plan_estandar", 0.0)
    acct.setdefault("plan_plus", 0.0)
    acct.setdefault("plan_pro", 0.0)
    return acct


# ---------- Modelos ----------
class CreditReq(BaseModel):
    reseller_id: str
    monto: float


class DebitReq(BaseModel):
    reseller_id: str
    monto: float


class SetCredReq(BaseModel):
    reseller_id: str
    creditos: int


# ---------- Endpoints ----------
@app.get("/ping")
def ping():
    return JSONResponse({"ok": True, "ts": time.strftime("%Y-%m-%dT%H:%M:%S")})


@app.get("/reseller/get")
def reseller_get(reseller_id: str, x_token: str = Header(default="")):
    require(x_token)
    s = sload()
    tg_id = resolve_reseller_id(s, reseller_id)
    if not tg_id:
        raise HTTPException(status_code=404, detail="reseller not found")

    acct = get_or_create_account(s, tg_id)
    username = s.get("usernames", {}).get(tg_id)
    out = {
        "reseller_id": tg_id,
        "username": username,
        "saldo": float(acct.get("balance", 0.0)),
        "creditos": int(acct.get("credits", 0) or 0),
        "currency": s.get("currency", "USD"),
    }
    return JSONResponse(out)


@app.post("/reseller/credit")
def reseller_credit(body: CreditReq, x_token: str = Header(default="")):
    require(x_token)
    s = sload()
    tg_id = resolve_reseller_id(s, body.reseller_id)
    if not tg_id:
        raise HTTPException(status_code=404, detail="reseller not found")
    acct = get_or_create_account(s, tg_id)
    acct["balance"] = round(float(acct.get("balance", 0.0)) + float(body.monto), 6)
    ssave(s)
    return JSONResponse({"ok": True, "reseller_id": tg_id, "saldo": acct["balance"]})


@app.post("/reseller/debit")
def reseller_debit(body: DebitReq, x_token: str = Header(default="")):
    require(x_token)
    s = sload()
    tg_id = resolve_reseller_id(s, body.reseller_id)
    if not tg_id:
        raise HTTPException(status_code=404, detail="reseller not found")
    acct = get_or_create_account(s, tg_id)
    acct["balance"] = round(float(acct.get("balance", 0.0)) - float(body.monto), 6)
    ssave(s)
    return JSONResponse({"ok": True, "reseller_id": tg_id, "saldo": acct["balance"]})


@app.post("/reseller/set_credits")
def reseller_set_credits(body: SetCredReq, x_token: str = Header(default="")):
    require(x_token)
    s = sload()
    tg_id = resolve_reseller_id(s, body.reseller_id)
    if not tg_id:
        raise HTTPException(status_code=404, detail="reseller not found")
    acct = get_or_create_account(s, tg_id)
    acct["credits"] = int(body.creditos)
    ssave(s)
    return JSONResponse({"ok": True, "reseller_id": tg_id, "creditos": acct["credits"]})
