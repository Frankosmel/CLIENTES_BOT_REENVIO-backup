# pagos_bot.py
# Pagos directos a wallet y recargas en USDT para RESELLERS OFICIALES + Panel Admin
# Formato de mensajes: HTML (negritas correctas, code para IDs/TXID)

import os, json, time, asyncio, re, math, html
from pathlib import Path
from typing import Dict, Any, Tuple, Optional
from dotenv import dotenv_values
from telethon import TelegramClient, events, Button
import httpx

# ================ Config ================
BASE = Path(__file__).parent
cfg  = dotenv_values(BASE / ".env")
def env(k, d=None):
    v = cfg.get(k) if cfg else os.getenv(k)
    return v if v not in (None, "") else d

BOT_TOKEN  = env("BOT_TOKEN")
API_ID     = int(env("API_ID", "0"))
API_HASH   = env("API_HASH")
MANAGER_HOST  = env("MANAGER_HOST","127.0.0.1")
MANAGER_PORT  = env("MANAGER_PORT","8080")
MANAGER_TOKEN = env("MANAGER_TOKEN")
MANAGER_URL   = f"http://{MANAGER_HOST}:{MANAGER_PORT}"

ADMIN_IDS  = [int(x) for x in (env("ADMIN_IDS","") or "").replace(" ","").split(",") if x]

# Wallets
W_USDT_TRC20 = env("WALLET_USDT_TRC20","")
W_USDT_BSC   = env("WALLET_USDT_BSC","")
W_TRX        = env("WALLET_TRX","")
W_BTC        = env("WALLET_BTC","")
W_LTC        = env("WALLET_LTC","")

DEFAULT_METHOD     = (env("DEFAULT_METHOD","usdttrc20") or "usdttrc20").lower()
MIN_RECHARGE_USDT  = float(env("MIN_RECHARGE_USDT","5.0"))

assert BOT_TOKEN and ":" in BOT_TOKEN
assert API_ID and API_HASH
assert MANAGER_TOKEN

bot = TelegramClient("payments_wallet_bot", API_ID, API_HASH).start(bot_token=BOT_TOKEN)

# ================ Archivos locales ================
ORDERS = BASE / "orders.json"
PREFS  = BASE / "prefs.json"
STATE  = BASE / "ui_state.json"

def _load(p: Path, dflt):
    try: return json.loads(p.read_text(encoding="utf-8")) if p.exists() else dflt
    except: return dflt
def _save(p: Path, data): p.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def orders_get(): return _load(ORDERS, {})
def orders_set(d): _save(ORDERS, d)
def prefs_get():  return _load(PREFS, {})
def prefs_set(d): _save(PREFS, d)
def state_get():  return _load(STATE, {})
def state_set(d): _save(STATE, d)

# ================ Util ================
def hx(s) -> str:
    """HTML-escape seguro para Telegram parse_mode='html'."""
    if s is None: return ""
    return html.escape(str(s), quote=False)

def is_admin(uid: int) -> bool: return uid in ADMIN_IDS
def now_ts() -> int: return int(time.time())

_last: Dict[int, float] = {}
def allow(uid: int, secs=0.6) -> bool:
    t = time.time()
    if t - _last.get(uid, 0) >= secs:
        _last[uid] = t
        return True
    return False

METHOD_LABEL = {
    "usdttrc20": "USDT TRC20",
    "usdtbsc":   "USDT BSC",
    "trx":       "TRX",
    "btc":       "BTC",
    "ltc":       "LTC",
}
METHOD_ADDR = {
    "usdttrc20": W_USDT_TRC20,
    "usdtbsc":   W_USDT_BSC,
    "trx":       W_TRX,
    "btc":       W_BTC,
    "ltc":       W_LTC,
}
METHOD_DEC = {"usdttrc20":6,"usdtbsc":6,"trx":6,"btc":8,"ltc":8}

def get_user_method(uid: int) -> str:
    p = prefs_get()
    return (p.get(str(uid), {}) or {}).get("method", DEFAULT_METHOD)

def set_user_method(uid: int, m: str):
    p = prefs_get(); p[str(uid)] = {"method": m}; prefs_set(p)

def sset(uid: int, step: str, extra: Optional[dict]=None):
    st = state_get(); st[str(uid)] = {"step": step, "extra": extra or {}}; state_set(st)

def sget(uid: int) -> dict:
    return (state_get()).get(str(uid), {"step":"idle","extra":{}})

def sclear(uid: int):
    st = state_get(); st.pop(str(uid), None); state_set(st)

async def get_username(evt) -> Optional[str]:
    try:
        u = await evt.get_sender()
        if not u or not u.username: return None
        return "@"+u.username
    except:
        return None

# ================ Teclados ================
def kb_main(uid: int):
    rows = [
        [Button.text("💼 Mi saldo"), Button.text("💳 Recargar")],
        [Button.text("🧾 Estado de pago"), Button.text("⚙️ Método de pago")],
        [Button.text("❓ Ayuda")],
    ]
    if is_admin(uid):
        rows.append([Button.text("🛠️ Admin")])
    return rows

def kb_cancel(): return [[Button.text("❌ Cancelar")]]

def kb_methods(curr: str):
    opts = ["USDT TRC20","USDT BSC","TRX","BTC","LTC","⬅️ Volver"]
    rows=[]
    for o in opts:
        if o=="⬅️ Volver": rows.append([Button.text(o)]); continue
        code={"USDT TRC20":"usdttrc20","USDT BSC":"usdtbsc","TRX":"trx","BTC":"btc","LTC":"ltc"}[o]
        rows.append([Button.text(("✅ " if code==curr else "")+o)])
    return rows

def kb_admin():
    return [
        [Button.text("🧾 Pendientes")],
        [Button.text("✅ Aprobar"), Button.text("🚫 Rechazar")],
        [Button.text("✉️ Mensaje"), Button.text("📣 Broadcast")],
        [Button.text("⬅️ Volver")],
    ]

# ================ Manager API ================
async def mgr_get_reseller(reseller_id: str) -> Optional[dict]:
    url=f"{MANAGER_URL}/reseller/get"
    async with httpx.AsyncClient(timeout=15) as c:
        r=await c.get(url, headers={"x-token": MANAGER_TOKEN}, params={"reseller_id": reseller_id})
        if r.status_code==404: return None
        r.raise_for_status(); return r.json()

async def mgr_credit(reseller_id: str, usdt_amount: float) -> dict:
    url=f"{MANAGER_URL}/reseller/credit"
    async with httpx.AsyncClient(timeout=15) as c:
        r=await c.post(url, headers={"x-token": MANAGER_TOKEN,"Content-Type":"application/json"},
                       json={"reseller_id": reseller_id, "monto": float(usdt_amount)})
        r.raise_for_status(); return r.json()

# ================ Precios ================
async def get_usdt_rate(method: str) -> float:
    m=method.lower()
    if m in ("usdttrc20","usdtbsc"): return 1.0
    sym={"trx":"TRXUSDT","btc":"BTCUSDT","ltc":"LTCUSDT"}[m]
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r=await c.get("https://api.binance.com/api/v3/ticker/price", params={"symbol":sym})
            r.raise_for_status(); return float(r.json()["price"])
    except:
        pass
    ids={"trx":"tron","btc":"bitcoin","ltc":"litecoin"}[m]
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r=await c.get("https://api.coingecko.com/api/v3/simple/price", params={"ids":ids,"vs_currencies":"usd"})
            r.raise_for_status(); return float(r.json()[ids]["usd"])
    except:
        return 0.0

def fmt_amt(x: float, dec: int) -> str:
    q=10**dec
    return f"{math.floor(x*q+0.5)/q:.{dec}f}"

# ================ Verificación de TX (best-effort) ================
async def verify_tx(method: str, txid: str, expected_addr: str) -> Tuple[bool, float, str]:
    m=method.lower(); txid=txid.strip()
    if len(txid)<20: return False, 0.0, "TXID demasiado corto"
    try:
        if m=="btc":
            url=f"https://api.blockcypher.com/v1/btc/main/txs/{txid}"
            async with httpx.AsyncClient(timeout=15) as c:
                j=(await c.get(url)).json()
            sat=0
            for o in j.get("outputs", []):
                if expected_addr in (o.get("addresses") or []): sat+=int(o.get("value",0))
            if sat>0: return True, sat/1e8, "BlockCypher (BTC)"
            return False, 0.0, "Sin salida a tu dirección"
        if m=="ltc":
            url=f"https://api.blockcypher.com/v1/ltc/main/txs/{txid}"
            async with httpx.AsyncClient(timeout=15) as c:
                j=(await c.get(url)).json()
            sat=0
            for o in j.get("outputs", []):
                if expected_addr in (o.get("addresses") or []): sat+=int(o.get("value",0))
            if sat>0: return True, sat/1e8, "BlockCypher (LTC)"
            return False, 0.0, "Sin salida a tu dirección"
        if m in ("trx","usdttrc20"):
            url="https://apilist.tronscanapi.com/api/transaction-info"
            async with httpx.AsyncClient(timeout=15) as c:
                r=await c.get(url, params={"hash": txid})
            if r.status_code!=200: return False, 0.0, "TronScan no disponible"
            j=r.json()
            if m=="trx":
                to_addr = j.get("toAddress") or (j.get("contractData") or {}).get("to_address")
                amt = j.get("amount") or (j.get("contractData") or {}).get("amount")
                if to_addr==expected_addr and amt: return True, float(amt)/1e6, "TronScan (TRX)"
                return False, 0.0, "Destino no coincide"
            if m=="usdttrc20":
                trc = j.get("trc20TransferInfo") or {}
                to_addr = trc.get("to_address")
                sym = (trc.get("symbol") or "").upper()
                val = trc.get("amount_str") or trc.get("amount")
                if sym=="USDT" and to_addr==expected_addr and val:
                    return True, float(val)/1e6, "TronScan (USDT)"
                return False, 0.0, "No es USDT/TRC20 o destino distinto"
        if m=="usdtbsc":
            return False, 0.0, "BSC sin verificación automática"
        return False, 0.0, "Método no soportado"
    except Exception as e:
        return False, 0.0, f"Error: {e}"

# ================ Acceso por @username ================
NEED_USERNAME = (
    "🔒 Necesitas un <b>username</b> en Telegram para usar este bot.\n"
    "Ajustes → Editar perfil → Nombre de usuario. Luego vuelve con /start."
)
ACCESS_DENIED = (
    "⛔ Usted no es <b>reseller oficial</b> del sistema Reenvíos Plus Bot.\n"
    "Contacte a @frankosme1 para habilitar su acceso."
)

async def username_as_reseller(evt) -> Tuple[bool, Optional[str], Optional[dict]]:
    uname = await get_username(evt)
    if not uname: return False, None, None
    try: info = await mgr_get_reseller(uname)
    except: info = None
    return (info is not None), uname, info

# ================ Flujo de orden ================
async def create_order(uid: int, rid: str, method: str, usdt_wanted: float) -> dict:
    addr = METHOD_ADDR.get(method,"")
    if not addr: raise RuntimeError("No hay dirección configurada para ese método.")
    dec  = METHOD_DEC.get(method,6)
    rate = await get_usdt_rate(method)
    if rate<=0: raise RuntimeError("No se pudo obtener precio. Intenta más tarde.")
    coin = float(fmt_amt(usdt_wanted / rate, dec))
    oid  = f"{rid}_{now_ts()}"
    d=orders_get()
    d[oid] = {
        "rid": rid, "uid": uid, "method": method, "address": addr,
        "usdt_wanted": float(f"{usdt_wanted:.2f}"),
        "rate_used": float(f"{rate:.8f}"),
        "coin_amount_expected": coin,
        "status": "awaiting_txid", "txid": "", "created_ts": now_ts()
    }
    orders_set(d)
    return d[oid] | {"order_id": oid}

async def try_credit(order_id: str, txid: str) -> Tuple[bool, str]:
    d=orders_get(); od=d.get(order_id)
    if not od: return False, "Orden no encontrada."
    m=od["method"]; addr=od["address"]; dec=METHOD_DEC.get(m,6)
    ok, coin_got, note = await verify_tx(m, txid, addr)
    if ok:
        rate_now = await get_usdt_rate(m)
        if rate_now<=0: return False, "No se pudo obtener precio para acreditar."
        usdt_amt = float(fmt_amt(coin_got*rate_now, 2))
        try:
            await mgr_credit(od["rid"], usdt_amt)
        except Exception as e:
            od["status"]="confirmed_not_credited"; od["txid"]=txid; orders_set(d)
            return False, f"Confirmado on-chain pero no acreditado en Manager: {hx(e)}"
        od["status"]="credited"; od["txid"]=txid; orders_set(d)
        try:
            await bot.send_message(
                int(od["uid"]),
                "✅ <b>Pago acreditado</b>\n\n"
                f"🆔 Orden: <code>{hx(order_id)}</code>\n"
                f"💱 Método: <b>{METHOD_LABEL[m]}</b>\n"
                f"📦 Monto on-chain: <b>{fmt_amt(coin_got, dec)}</b>\n"
                f"💵 Acreditado: <b>{usdt_amt:.2f}</b> USDT",
                parse_mode="html"
            )
        except: pass
        return True, (
            "✅ <b>Pago confirmado y acreditado</b>\n\n"
            f"🆔 Orden: <code>{hx(order_id)}</code>\n"
            f"🔗 TXID: <code>{hx(txid)}</code>\n"
            f"💱 Método: <b>{METHOD_LABEL[m]}</b>\n"
            f"📦 Monto on-chain: <b>{fmt_amt(coin_got, dec)}</b>\n"
            f"💵 Acreditado: <b>{usdt_amt:.2f}</b> USDT"
        )
    od["status"]="review"; od["txid"]=txid; orders_set(d)
    usdt_estim = float(fmt_amt(od["coin_amount_expected"]*od["rate_used"], 2))
    return False, (
        "🕵️ <b>Pago en revisión manual</b>\n\n"
        f"🆔 Orden: <code>{hx(order_id)}</code>\n"
        f"🔗 TXID: <code>{hx(txid)}</code>\n"
        f"💱 Método: <b>{METHOD_LABEL[m]}</b>\n"
        f"💵 Estimado en USDT: <b>{usdt_estim:.2f}</b>\n"
        f"ℹ️ Nota: {hx(note)}"
    )

# ================ Textos ================
WELCOME = (
    "Notas:\n"
    f"• Mínimo por recarga: <b>{MIN_RECHARGE_USDT:.2f} USDT</b>.\n"
    "• La red cobra <b>network fee</b> aparte.\n"
    "• Envía el <b>monto exacto</b> indicado.\n"
    "• Acreditamos <b>siempre en USDT</b> (equivalente) aunque pagues con TRX/BTC/LTC."
)

# ================ Handlers ================
@bot.on(events.NewMessage(pattern=r"^/start$"))
async def start(evt):
    uid=evt.sender_id
    ok, rid, info = await username_as_reseller(evt)
    if rid is None and not is_admin(uid): return await evt.reply(NEED_USERNAME, parse_mode="html")
    if (not ok) and (not is_admin(uid)):  return await evt.reply(ACCESS_DENIED, parse_mode="html")
    saldo=float((info or {}).get("saldo", (info or {}).get("balance", 0)))
    cred =(info or {}).get("creditos", 0)
    m=get_user_method(uid)
    await evt.reply(
        "✅ <b>Acceso autorizado</b>\n\n"
        f"👤 Reseller: <code>{hx(rid or '@admin')}</code>\n"
        f"💳 Saldo: <b>{saldo:.2f}</b> USDT\n"
        f"📌 Créditos: <b>{cred}</b>\n"
        f"⚙️ Método: <b>{METHOD_LABEL[m]}</b>\n\n"
        f"{WELCOME}\n\n"
        "Selecciona una opción:",
        parse_mode="html", buttons=kb_main(uid)
    )

@bot.on(events.NewMessage)
async def router(evt):
    uid=evt.sender_id; txt=(evt.raw_text or "").strip()
    if not allow(uid): return

    ok, rid, _ = await username_as_reseller(evt)
    if txt not in {"/start","❓ Ayuda","/help"}:
        if rid is None and not is_admin(uid): return await evt.reply(NEED_USERNAME, parse_mode="html")
        if (not ok) and (not is_admin(uid)):  return await evt.reply(ACCESS_DENIED, parse_mode="html")

    st=sget(uid); method=get_user_method(uid)

    # Cancelar
    if txt.lower() in {"❌ cancelar","cancelar","/cancel"}:
        sclear(uid); return await evt.reply("❎ <b>Operación cancelada</b>", parse_mode="html", buttons=kb_main(uid))

    # Ayuda
    if txt in {"❓ Ayuda","/help"}:
        return await evt.reply(
            "🧭 <b>Guía rápida</b>\n"
            "• «💼 Mi saldo»: tu saldo y créditos.\n"
            "• «⚙️ Método de pago»: elige red/moneda.\n"
            "• «💳 Recargar»: ingresa <b>USDT</b> a recargar.\n"
            "• «🧾 Estado de pago»: consulta una orden por ID.",
            parse_mode="html", buttons=kb_main(uid)
        )

    # Saldo
    if txt in {"💼 Mi saldo","/saldo"}:
        info=None
        try: info = await mgr_get_reseller(rid or "")
        except: pass
        saldo=float((info or {}).get("saldo",(info or {}).get("balance",0)))
        cred =(info or {}).get("creditos",0)
        return await evt.reply(
            f"👤 <code>{hx(rid or '@admin')}</code>\n"
            f"💳 <b>Saldo:</b> {saldo:.2f} USDT\n"
            f"📌 <b>Créditos:</b> {cred}",
            parse_mode="html", buttons=kb_main(uid)
        )

    # Método
    if txt in {"⚙️ Método de pago","/metodo"}:
        return await evt.reply(f"Elige red/moneda. Actual: <b>{METHOD_LABEL[method]}</b>",
                               parse_mode="html", buttons=kb_methods(method))
    clean=txt.replace("✅ ","").strip()
    if clean in {"USDT TRC20","USDT BSC","TRX","BTC","LTC"}:
        code={"USDT TRC20":"usdttrc20","USDT BSC":"usdtbsc","TRX":"trx","BTC":"btc","LTC":"ltc"}[clean]
        set_user_method(uid, code)
        return await evt.reply(f"✅ Método guardado: <b>{clean}</b>.", parse_mode="html", buttons=kb_main(uid))
    if txt=="⬅️ Volver": return await evt.reply("🔙 Menú principal.", buttons=kb_main(uid))

    # Recargar
    if txt in {"💳 Recargar","/recargar"}:
        sset(uid,"ask_usdt")
        return await evt.reply(
            "💵 <b>Introduce el monto en USDT</b> a recargar "
            f"(mínimo <b>{MIN_RECHARGE_USDT:.2f}</b>).",
            parse_mode="html", buttons=kb_cancel()
        )

    if st["step"]=="ask_usdt":
        try:
            usdt=float(txt.replace(",","."))
            if usdt<MIN_RECHARGE_USDT:
                return await evt.reply(
                    f"⚠️ Mínimo por recarga: <b>{MIN_RECHARGE_USDT:.2f} USDT</b>.\nIngresa un monto mayor.",
                    parse_mode="html", buttons=kb_cancel()
                )
        except:
            return await evt.reply("❌ Monto inválido. Ej: 10 | 12.5 | 25", buttons=kb_cancel())
        try:
            od=await create_order(uid, rid or "@admin", get_user_method(uid), usdt)
        except Exception as e:
            sclear(uid); return await evt.reply(f"❌ No se pudo crear la orden: <code>{hx(e)}</code>",
                                                parse_mode="html", buttons=kb_main(uid))
        dec=METHOD_DEC.get(od["method"],6); label=METHOD_LABEL[od["method"]]
        sset(uid,"await_txid",{"order_id":od["order_id"]})
        return await evt.reply(
            "🧾 <b>Orden creada</b>\n\n"
            f"🆔 ID: <code>{hx(od['order_id'])}</code>\n"
            f"💵 Recargar: <b>{od['usdt_wanted']:.2f}</b> USDT\n"
            f"💱 Método: <b>{label}</b>\n"
            f"💹 Tipo de cambio usado: <b>{od['rate_used']:.6f}</b> USDT\n"
            f"📦 Debes enviar: <b>{fmt_amt(od['coin_amount_expected'], dec)}</b> {label}\n"
            f"📍 Dirección: <code>{hx(od['address'])}</code>\n\n"
            "✏️ Después de enviar, responde con el <b>TXID</b>.",
            parse_mode="html", buttons=kb_cancel()
        )

    if st["step"]=="await_txid":
        oid=st["extra"].get("order_id"); txid=txt.strip()
        ok, msg = await try_credit(oid, txid)
        sclear(uid)
        return await evt.reply(msg, parse_mode="html", buttons=kb_main(uid))

    # Estado
    if txt in {"🧾 Estado de pago","/estado"}:
        sset(uid,"ask_oid")
        return await evt.reply("✏️ Envía el <b>ID de la orden</b>.", parse_mode="html", buttons=kb_cancel())
    if st["step"]=="ask_oid":
        oid=txt.strip(); d=orders_get(); od=d.get(oid); sclear(uid)
        if not od: return await evt.reply("❌ Orden no encontrada.", buttons=kb_main(uid))
        return await evt.reply(
            "📊 <b>Estado de la orden</b>\n\n"
            f"🆔 ID: <code>{hx(oid)}</code>\n"
            f"👤 Reseller: <code>{hx(od['rid'])}</code>\n"
            f"💱 Método: <b>{METHOD_LABEL[od['method']]}</b>\n"
            f"💵 USDT solicitados: <b>{od['usdt_wanted']:.2f}</b>\n"
            f"📦 Monto coin esperado: <b>{od['coin_amount_expected']}</b>\n"
            f"📍 Dirección: <code>{hx(od['address'])}</code>\n"
            f"📌 Estado: <b>{hx(od['status'])}</b>\n"
            f"🔗 TXID: <code>{hx(od.get('txid',''))}</code>",
            parse_mode="html", buttons=kb_main(uid)
        )

    # ===== Admin =====
    if is_admin(uid) and txt=="🛠️ Admin":
        return await evt.reply("🔧 Panel de administración.", buttons=kb_admin())

    if is_admin(uid) and txt=="🧾 Pendientes":
        d=orders_get()
        pend=[(k,v) for k,v in d.items() if v.get("status") in {"awaiting_txid","review","confirmed_not_credited"}]
        if not pend: return await evt.reply("✅ No hay pendientes.", buttons=kb_admin())
        lines=[]
        for k,v in sorted(pend, key=lambda x: x[1]["created_ts"]):
            lines.append(
                f"• <code>{hx(k)}</code> — <b>{hx(v['status'])}</b> — {METHOD_LABEL[v['method']]} — "
                f"{v['usdt_wanted']:.2f} USDT — tx: <code>{hx(v.get('txid',''))}</code>"
            )
        return await evt.reply("🧾 <b>Pendientes</b>\n\n"+"\n".join(lines), parse_mode="html", buttons=kb_admin())

    # Aprobar (manual)
    if is_admin(uid) and txt=="✅ Aprobar":
        sset(uid,"admin_approve"); return await evt.reply("✏️ Envía el <b>ID</b> de la orden a aprobar.", parse_mode="html", buttons=kb_cancel())
    if is_admin(uid) and st["step"]=="admin_approve":
        oid=txt.strip(); d=orders_get(); od=d.get(oid)
        if not od: sclear(uid); return await evt.reply("❌ Orden no encontrada.", buttons=kb_admin())
        if od["status"] in {"credited","credited_manual"}:
            sclear(uid); return await evt.reply("ℹ️ Ya está acreditada.", buttons=kb_admin())
        rate=await get_usdt_rate(od["method"])
        if rate<=0: sclear(uid); return await evt.reply("⚠️ No se pudo obtener precio.", buttons=kb_admin())
        dec=METHOD_DEC.get(od["method"],6)
        coin_base=float(od["coin_amount_expected"])
        usdt_amt=float(fmt_amt(coin_base*rate,2))
        try: await mgr_credit(od["rid"], usdt_amt)
        except Exception as e:
            sclear(uid); return await evt.reply(f"❌ Error acreditando: <code>{hx(e)}</code>", parse_mode="html", buttons=kb_admin())
        od["status"]="credited_manual"; orders_set(d); sclear(uid)
        try:
            await bot.send_message(
                int(od["uid"]),
                "✅ <b>Pago aprobado por administración</b>\n\n"
                f"🆔 Orden: <code>{hx(oid)}</code>\n"
                f"💱 Método: <b>{METHOD_LABEL[od['method']]}</b>\n"
                f"💵 Acreditado: <b>{usdt_amt:.2f}</b> USDT",
                parse_mode="html"
            )
        except: pass
        return await evt.reply(
            "✅ <b>Acreditado manualmente</b>\n\n"
            f"🆔 Orden: <code>{hx(oid)}</code>\n"
            f"💱 Moneda: <b>{METHOD_LABEL[od['method']]}</b>\n"
            f"📦 Monto coin base: <b>{fmt_amt(coin_base, dec)}</b>\n"
            f"💵 Acreditado: <b>{usdt_amt:.2f}</b> USDT",
            parse_mode="html", buttons=kb_admin()
        )

    # Rechazar (con motivo)
    if is_admin(uid) and txt=="🚫 Rechazar":
        sset(uid,"admin_reject_id"); return await evt.reply("✏️ Envía el <b>ID</b> de la orden a rechazar.", parse_mode="html", buttons=kb_cancel())
    if is_admin(uid) and st["step"]=="admin_reject_id":
        oid=txt.strip(); d=orders_get(); od=d.get(oid)
        if not od: sclear(uid); return await evt.reply("❌ Orden no encontrada.", buttons=kb_admin())
        sset(uid,"admin_reject_reason",{"oid":oid})
        return await evt.reply("📝 Escribe el <b>motivo</b> del rechazo.", parse_mode="html", buttons=kb_cancel())
    if is_admin(uid) and st["step"]=="admin_reject_reason":
        reason=txt.strip(); oid=sget(uid)["extra"]["oid"]; d=orders_get(); od=d.get(oid)
        if not od: sclear(uid); return await evt.reply("❌ Orden no encontrada.", buttons=kb_admin())
        od["status"]="rejected"; od["reject_reason"]=reason; orders_set(d); sclear(uid)
        try:
            await bot.send_message(
                int(od["uid"]),
                "❌ <b>Su solicitud ha sido cancelada</b>\n\n"
                f"🆔 ID de la orden: <code>{hx(oid)}</code>\n"
                f"💱 Método: <b>{METHOD_LABEL[od['method']]}</b>\n"
                f"💵 Monto solicitado: <b>{od['usdt_wanted']:.2f}</b> USDT\n"
                f"📩 Motivo: {hx(reason)}",
                parse_mode="html"
            )
        except: pass
        return await evt.reply("🚫 Orden rechazada y usuario notificado.", buttons=kb_admin())

    # Mensaje directo o a todos
    if is_admin(uid) and txt=="✉️ Mensaje":
        sset(uid,"admin_msg_target"); 
        return await evt.reply("👤 Destino: escribe <b>@usuario</b>, <b>tg_id</b> o <b>TODOS</b>.", parse_mode="html", buttons=kb_cancel())
    if is_admin(uid) and st["step"]=="admin_msg_target":
        target=txt.strip(); sset(uid,"admin_msg_body",{"target":target})
        return await evt.reply("✏️ Escribe el <b>mensaje</b> a enviar.", parse_mode="html", buttons=kb_cancel())
    if is_admin(uid) and st["step"]=="admin_msg_body":
        target=sget(uid)["extra"]["target"]; msg=txt; d=orders_get()
        uids=set()
        if target.upper() in {"TODOS","*"}:
            uids={int(v["uid"]) for v in d.values()}
        elif target.startswith("@"):
            uids={int(v["uid"]) for v in d.values() if v.get("rid")==target}
        else:
            try: uids={int(target)}
            except: uids=set()
        sent=0
        for u in uids:
            try: await bot.send_message(u, msg, parse_mode="html"); sent+=1
            except: pass
        sclear(uid)
        return await evt.reply(f"📨 Enviado a <b>{sent}</b> usuario(s).", parse_mode="html", buttons=kb_admin())

    # Broadcast
    if is_admin(uid) and txt=="📣 Broadcast":
        sset(uid,"admin_bc"); return await evt.reply("✏️ Escribe el <b>mensaje</b> para todos con órdenes.", parse_mode="html", buttons=kb_cancel())
    if is_admin(uid) and st["step"]=="admin_bc":
        msg=txt; d=orders_get(); targets=sorted(set(int(v["uid"]) for v in d.values()))
        sent=0
        for t in targets:
            try: await bot.send_message(t, msg, parse_mode="html"); sent+=1
            except: pass
        sclear(uid); return await evt.reply(f"📣 Enviado a <b>{sent}</b> usuarios.", parse_mode="html", buttons=kb_admin())

    # Fallback
    return await evt.reply("👇 Usa los botones del teclado para continuar.", buttons=kb_main(uid))

# ================ Run ================
print("🤖 Bot de pagos directo a wallet iniciado (HTML formatting).")
bot.run_until_disconnected()
