#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os, json, asyncio, shutil, subprocess, datetime as dt, re, logging
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple
import aiohttp
from fastapi import FastAPI, Request
import uvicorn
from filelock import FileLock
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger

from telethon import TelegramClient, events, Button
from telethon.tl.types import User
from dotenv import load_dotenv

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

SYSTEMCTL = "/usr/bin/systemctl"

ROOT = Path.home() / "CLIENTES_BOT_REENVIO"
MANAGER_DIR = ROOT / "manager"
TEMPL_DIR = ROOT / "TEMPLATES"
STATEF = MANAGER_DIR / "state.json"
STATE_LOCK = MANAGER_DIR / "state.json.lock"
CLIENTS_DIR = ROOT / "clients"
CLIENTS_DIR.mkdir(parents=True, exist_ok=True)
MANAGER_DIR.mkdir(parents=True, exist_ok=True)

TEMPL = {
    "default":      TEMPL_DIR / "default",
    "plan_estandar": TEMPL_DIR / "plan_estandar",
    "plan_plus":     TEMPL_DIR / "plan_plus",
    "plan_pro":      TEMPL_DIR / "plan_pro",
    "plan_trial":    TEMPL_DIR / "plan_estandar",
}

load_dotenv(MANAGER_DIR / ".env")
API_ID = int(os.getenv("API_ID", "0"))
API_HASH = os.getenv("API_HASH", "")
BOT_TOKEN = os.getenv("MANAGER_BOT_TOKEN", "")
QVAPAY_APP_ID = os.getenv("QVAPAY_APP_ID", "")
QVAPAY_APP_SECRET = os.getenv("QVAPAY_APP_SECRET", "")

if not API_ID or not API_HASH or not BOT_TOKEN:
    logger.warning("❌ Faltan credenciales en ~/CLIENTES_BOT_REENVIO/manager/.env")

if not QVAPAY_APP_ID or not QVAPAY_APP_SECRET:
    logger.warning("⚠️ Credenciales de QvaPay no configuradas. Los pagos no funcionarán.")

# Scheduler global para tareas programadas
scheduler = AsyncIOScheduler()

def load_state() -> Dict[str, Any]:
    if not STATEF.exists():
        STATEF.write_text(
            json.dumps({
                "owner_id": 0,
                "admins": [],
                "resellers": [],
                "clients": {},
                "usernames": {},
                "last_expiry_check": None,
                "notify_expiry": True,
            }, indent=2, ensure_ascii=False)
        )
    
    S = json.loads(STATEF.read_text())
    
    # Migración: agregar nuevas claves de facturación con defaults (sin sobrescribir existentes)
    if "prices" not in S:
        S["prices"] = {
            "plan_estandar": 4.00,
            "plan_plus": 4.00,
            "plan_pro": 4.00,
            "plan_trial": 0.00
        }
    
    if "currency" not in S:
        S["currency"] = "USD"
    
    if "resellers_meta" not in S:
        S["resellers_meta"] = {}
    
    if "invoices" not in S:
        S["invoices"] = []
    
    if "payments" not in S:
        S["payments"] = []
    
    if "settings" not in S:
        S["settings"] = {
            "grace_days": 2,
            "notify_expiry_reseller": True,
            "auto_pause_on_expiry": True,
            "invoice_seq": 1
        }
    
    # Migración: agregar campos de monitoreo de balance
    if "low_balance_threshold" not in S["settings"]:
        S["settings"]["low_balance_threshold"] = 5.0
    
    if "credit_warn_threshold" not in S["settings"]:
        S["settings"]["credit_warn_threshold"] = -5.0
    
    if "notify_cooldown_hours" not in S["settings"]:
        S["settings"]["notify_cooldown_hours"] = 12
    
    # Migración: agregar last_notify a todos los resellers_meta existentes
    for rid_str in S["resellers_meta"].keys():
        if "last_notify" not in S["resellers_meta"][rid_str]:
            S["resellers_meta"][rid_str]["last_notify"] = {
                "low_balance": None,
                "credit_in_use": None,
                "credit_exhausted": None,
                "paused_for_balance": None
            }
        if "exhausted_seen" not in S["resellers_meta"][rid_str]:
            S["resellers_meta"][rid_str]["exhausted_seen"] = False
    
    # Guardar state migrado
    save_state(S)
    
    return S

def save_state(S: Dict[str, Any]):
    """Guarda el estado en state.json con filelock para evitar race conditions"""
    with FileLock(STATE_LOCK, timeout=10):
        try:
            STATEF.write_text(json.dumps(S, indent=2, ensure_ascii=False))
            logger.debug(f"💾 Estado guardado correctamente")
        except Exception as e:
            logger.error(f"❌ Error guardando estado: {e}")
            raise

S = load_state()

def is_owner(uid: int) -> bool:
    return uid == S.get("owner_id", 0)

def is_admin(uid: int) -> bool:
    return is_owner(uid) or uid in S.get("admins", [])

def is_reseller(uid: int) -> bool:
    return uid in S.get("resellers", [])

def can_manage_client(uid: int, slug: str) -> bool:
    c = S.get("clients", {}).get(slug) or {}
    if is_admin(uid):
        return True
    if is_reseller(uid) and c.get("reseller_id") == uid:
        return True
    return c.get("owner_id") == uid

def get_username_display(uid: int) -> str:
    """Obtiene el username cacheado o muestra el ID"""
    username = S.get("usernames", {}).get(str(uid))
    return f"@{username}" if username else f"ID:{uid}"

def format_text(text: str) -> str:
    """Formato simple para Telegram - NO escapa asteriscos para permitir negrita Markdown"""
    return text.replace('_', '\\_')

def run(cmd: str):
    p = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode != 0:
        raise RuntimeError(f"RC={p.returncode} CMD={cmd}\nSTDOUT:\n{p.stdout}\nSTDERR:\n{p.stderr}")
    return p.stdout

def _svc_status(svc: str) -> str:
    try:
        out = subprocess.run(
            [SYSTEMCTL, "is-active", svc],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, check=False
        ).stdout.strip()
        return "active" if out == "active" else out or "unknown"
    except Exception:
        return "unknown"

def check_single_instance():
    """Verifica que no haya otra instancia del manager_bot corriendo"""
    try:
        # Buscar procesos Python que ejecuten manager_bot.py
        result = subprocess.run(
            ["ps", "aux"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=False
        )
        
        current_pid = os.getpid()
        manager_bot_processes = []
        
        for line in result.stdout.splitlines():
            if "manager_bot.py" in line and "python" in line.lower():
                # Extraer PID (segunda columna)
                parts = line.split()
                if len(parts) > 1:
                    try:
                        pid = int(parts[1])
                        if pid != current_pid:
                            manager_bot_processes.append(pid)
                    except ValueError:
                        continue
        
        if manager_bot_processes:
            logger.error(
                f"❌ INSTANCIA DUPLICADA DETECTADA!\n"
                f"Ya hay {len(manager_bot_processes)} instancia(s) de manager_bot.py corriendo: {manager_bot_processes}\n"
                f"PID actual: {current_pid}\n"
                f"Terminando para prevenir race conditions..."
            )
            raise RuntimeError(f"Instancia duplicada detectada. PIDs existentes: {manager_bot_processes}")
        
        logger.info(f"✅ Verificación de instancia única exitosa (PID: {current_pid})")
        
    except RuntimeError:
        raise
    except Exception as e:
        logger.warning(f"⚠️ Error verificando instancia única: {e}. Continuando...")

def enable_instance_service(slug: str):
    run(f"sudo -n {SYSTEMCTL} daemon-reload")
    run(f"sudo -n {SYSTEMCTL} enable --now 'reenvio@{slug}.service'")

def disable_instance_service(slug: str):
    run(f"sudo -n {SYSTEMCTL} disable --now 'reenvio@{slug}.service' || true")

def pause_instance_service(slug: str):
    run(f"sudo -n {SYSTEMCTL} stop 'reenvio@{slug}.service' || true")

def resume_instance_service(slug: str):
    run(f"sudo -n {SYSTEMCTL} start 'reenvio@{slug}.service' || true")

def slugify_from_user(entity) -> str:
    if getattr(entity, "username", None):
        return re.sub(r"[^a-zA-Z0-9_]+", "", entity.username)[:32] or f"tenant{entity.id}"
    return f"tenant{entity.id}"

def fmt_date(d: dt.date) -> str:
    return d.isoformat()

# ============================================================================
# QVAPAY INTEGRATION
# ============================================================================

class QvaPayService:
    """Servicio para integración con QvaPay API"""
    
    BASE_URL = "https://qvapay.com/api/v1"
    
    def __init__(self, app_id: str, app_secret: str):
        self.app_id = app_id
        self.app_secret = app_secret
        self.pending_invoices = {}  # {transaction_uuid: {user_id, amount, type}}
    
    async def create_invoice(self, amount: float, description: str, remote_id: str) -> Dict[str, Any]:
        """
        Crea una factura de pago en QvaPay
        Returns: {transaction_uuid, url, signed_url, amount, description}
        """
        if not self.app_id or not self.app_secret:
            raise ValueError("QvaPay credentials not configured")
        
        url = f"{self.BASE_URL}/create_invoice"
        params = {
            "app_id": self.app_id,
            "app_secret": self.app_secret,
            "amount": f"{amount:.2f}",
            "description": description,
            "remote_id": remote_id,
            "signed": "1"
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, params=params) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        logger.info(f"✅ QvaPay invoice created: {data.get('transation_uuid')}")
                        return data
                    else:
                        error_text = await resp.text()
                        logger.error(f"❌ QvaPay error: {resp.status} - {error_text}")
                        raise Exception(f"QvaPay API error: {resp.status}")
        except Exception as e:
            logger.error(f"❌ QvaPay create_invoice error: {e}")
            raise
    
    async def get_transaction(self, transaction_uuid: str) -> Dict[str, Any]:
        """Obtiene el estado de una transacción"""
        url = f"{self.BASE_URL}/transaction/{transaction_uuid}"
        params = {
            "app_id": self.app_id,
            "app_secret": self.app_secret
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, params=params) as resp:
                    if resp.status == 200:
                        return await resp.json()
                    else:
                        return None
        except Exception as e:
            logger.error(f"❌ QvaPay get_transaction error: {e}")
            return None
    
    async def get_balance(self) -> float:
        """Obtiene el balance de la cuenta QvaPay"""
        url = f"{self.BASE_URL}/balance"
        params = {
            "app_id": self.app_id,
            "app_secret": self.app_secret
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, params=params) as resp:
                    if resp.status == 200:
                        balance = await resp.text()
                        return float(balance)
                    else:
                        return 0.0
        except Exception as e:
            logger.error(f"❌ QvaPay get_balance error: {e}")
            return 0.0
    
    def register_pending_invoice(self, transaction_uuid: str, user_id: int, amount: float, invoice_type: str):
        """Registra una factura pendiente de confirmación"""
        self.pending_invoices[transaction_uuid] = {
            "user_id": user_id,
            "amount": amount,
            "type": invoice_type,  # "client_payment" o "reseller_topup"
            "created_at": dt.datetime.now().isoformat()
        }
    
    def get_pending_invoice(self, transaction_uuid: str) -> Optional[Dict]:
        """Obtiene info de una factura pendiente"""
        return self.pending_invoices.get(transaction_uuid)
    
    def clear_pending_invoice(self, transaction_uuid: str):
        """Elimina una factura pendiente tras procesarla"""
        self.pending_invoices.pop(transaction_uuid, None)

# Instancia global del servicio
qvapay_service = QvaPayService(QVAPAY_APP_ID, QVAPAY_APP_SECRET)

# ============================================================================
# WEBHOOK SERVER (FastAPI para recibir notificaciones de QvaPay)
# ============================================================================

webhook_app = FastAPI(title="QvaPay Webhook Server")

@webhook_app.post("/qvapay/webhook")
async def qvapay_webhook(request: Request):
    """Recibe notificaciones de pagos completados desde QvaPay"""
    try:
        data = await request.json()
        logger.info(f"📥 QvaPay webhook received: {data}")
        
        transaction_uuid = data.get("uuid") or data.get("transation_uuid")
        status = data.get("status")
        
        if not transaction_uuid:
            logger.warning("⚠️ Webhook sin transaction_uuid")
            return {"status": "error", "message": "Missing transaction_uuid"}
        
        # Verificar el estado de la transacción
        if status == "paid" or status == "completed":
            pending = qvapay_service.get_pending_invoice(transaction_uuid)
            
            if not pending:
                logger.warning(f"⚠️ Transaction {transaction_uuid} not found in pending")
                return {"status": "ok", "message": "Transaction not pending"}
            
            # Procesar el pago según el tipo
            user_id = pending["user_id"]
            amount = pending["amount"]
            invoice_type = pending["type"]
            
            if invoice_type == "reseller_topup":
                # Recargar saldo de reseller
                topup_reseller(user_id, amount, "QvaPay", f"Pago QvaPay: {transaction_uuid}")
                
                # Notificar al reseller
                asyncio.create_task(
                    bot.send_message(
                        user_id,
                        f"✅ *Recarga Confirmada*\n\n"
                        f"Monto: `${amount:.2f} USD`\n"
                        f"Método: QvaPay\n"
                        f"Transacción: `{transaction_uuid}`\n\n"
                        f"Tu nuevo saldo está disponible.",
                        parse_mode="Markdown"
                    )
                )
                
                logger.info(f"✅ Reseller {user_id} recargado: ${amount}")
            
            elif invoice_type == "client_payment":
                # Registrar pago de cliente
                meta = get_reseller_meta(user_id)
                meta["balance"] += amount
                meta["balance"] = round(meta["balance"], 2)
                S["resellers_meta"][str(user_id)] = meta
                save_state(S)
                
                # Notificar al cliente
                asyncio.create_task(
                    bot.send_message(
                        user_id,
                        f"✅ *Pago Recibido*\n\n"
                        f"Monto: `${amount:.2f} USD`\n"
                        f"Transacción: `{transaction_uuid}`\n\n"
                        f"Gracias por tu pago.",
                        parse_mode="Markdown"
                    )
                )
                
                logger.info(f"✅ Client payment {user_id}: ${amount}")
            
            # Limpiar factura pendiente
            qvapay_service.clear_pending_invoice(transaction_uuid)
            
            return {"status": "ok", "message": "Payment processed"}
        
        else:
            logger.info(f"ℹ️ Transaction {transaction_uuid} status: {status}")
            return {"status": "ok", "message": f"Status: {status}"}
            
    except Exception as e:
        logger.error(f"❌ Webhook error: {e}")
        return {"status": "error", "message": str(e)}

@webhook_app.get("/payment/success")
async def payment_success():
    """Página de pago exitoso"""
    return {"status": "success", "message": "Pago completado. Puedes cerrar esta ventana."}

@webhook_app.get("/payment/cancel")
async def payment_cancel():
    """Página de pago cancelado"""
    return {"status": "cancelled", "message": "Pago cancelado."}

@webhook_app.get("/health")
async def webhook_health():
    """Health check del servidor webhook"""
    return {"status": "ok", "service": "QvaPay Webhook Server"}

# ============================================================================
# FACTURACIÓN HELPERS
# ============================================================================

def fmt_money(x: float) -> str:
    """Formato de dinero con 2 decimales"""
    return f"{x:.2f}"

def get_price_30(plan: str) -> float:
    """Obtiene el precio de 30 días para un plan"""
    return S.get("prices", {}).get(plan, 4.00)

def get_unit_day(plan: str) -> float:
    """Obtiene el precio por día de un plan"""
    price_30 = get_price_30(plan)
    return price_30 / 30.0

def get_reseller_meta(reseller_id: int) -> dict:
    """Obtiene o crea metadata de reseller con defaults"""
    meta = S.get("resellers_meta", {})
    
    if str(reseller_id) not in meta:
        meta[str(reseller_id)] = {
            "balance": 0.0,
            "credit_limit": 0.0,
            "discount_pct": {
                "plan_estandar": 0,
                "plan_plus": 0,
                "plan_pro": 0
            },
            "last_notify": {
                "low_balance": None,
                "credit_in_use": None,
                "credit_exhausted": None,
                "paused_for_balance": None
            },
            "exhausted_seen": False
        }
        S["resellers_meta"] = meta
        save_state(S)
    
    return meta[str(reseller_id)]

def calc_total(plan: str, days: int, reseller_id: int | None) -> tuple[float, float, float]:
    """
    Calcula total para renovación.
    Returns: (unit_day, discount_pct, total)
    
    Regla: trial → (0, 0, 0)
           otros → unit_day * days * (1 - discount_pct/100)
    """
    if plan == "plan_trial":
        return (0.0, 0.0, 0.0)
    
    unit_day = get_unit_day(plan)
    discount_pct = 0.0
    
    if reseller_id:
        meta = get_reseller_meta(reseller_id)
        discount_pct = meta.get("discount_pct", {}).get(plan, 0.0)
    
    total = unit_day * days * (1.0 - discount_pct / 100.0)
    
    return (unit_day, discount_pct, total)

def invoice_id() -> int:
    """Obtiene y auto-incrementa el sequence de invoice"""
    current_id = S.get("settings", {}).get("invoice_seq", 1)
    S.setdefault("settings", {})["invoice_seq"] = current_id + 1
    save_state(S)
    return current_id

def record_invoice(item: dict) -> None:
    """Registra una factura en el state"""
    S.setdefault("invoices", []).append(item)
    save_state(S)
    logger.info(f"Invoice #{item.get('id')} registrado: type={item.get('type')}, total={item.get('total')}")

def has_balance(reseller_id: int, total: float) -> bool:
    """Verifica si el reseller tiene saldo suficiente"""
    meta = get_reseller_meta(reseller_id)
    disponible = meta["balance"] + meta["credit_limit"]
    return disponible >= total

def debit_reseller(reseller_id: int, total: float, note: str, *, client_slug: str, plan: str, days: int) -> dict:
    """
    Debita del saldo del reseller y crea invoice type="renew"
    Returns: invoice dict
    """
    meta = get_reseller_meta(reseller_id)
    unit_price = get_unit_day(plan)
    discount_pct = meta.get("discount_pct", {}).get(plan, 0.0)
    
    # Crear invoice
    inv = {
        "id": invoice_id(),
        "type": "renew",
        "who": "reseller",
        "reseller_id": reseller_id,
        "client_slug": client_slug,
        "plan": plan,
        "days": days,
        "unit_price": round(unit_price, 5),
        "discount": discount_pct,
        "total": round(total, 2),
        "currency": S.get("currency", "USD"),
        "ts": dt.datetime.now().isoformat(timespec="seconds"),
        "note": note
    }
    
    # Actualizar balance
    meta["balance"] -= total
    meta["balance"] = round(meta["balance"], 2)
    
    S["resellers_meta"][str(reseller_id)] = meta
    record_invoice(inv)
    
    logger.info(f"Debit reseller {reseller_id}: -{total} USD, balance={meta['balance']}, client={client_slug}")
    
    return inv

def topup_reseller(reseller_id: int, amount: float, method: str, note: str) -> dict:
    """
    Recarga saldo del reseller.
    Crea invoice type="topup" y payment record.
    Returns: invoice dict
    """
    meta = get_reseller_meta(reseller_id)
    
    # Crear invoice topup
    inv = {
        "id": invoice_id(),
        "type": "topup",
        "who": "reseller",
        "reseller_id": reseller_id,
        "total": round(amount, 2),
        "currency": S.get("currency", "USD"),
        "ts": dt.datetime.now().isoformat(timespec="seconds"),
        "method": method,
        "note": note
    }
    
    # Crear payment
    payment = {
        "id": len(S.get("payments", [])) + 1,
        "reseller_id": reseller_id,
        "amount": round(amount, 2),
        "method": method,
        "ts": dt.datetime.now().isoformat(timespec="seconds"),
        "note": note
    }
    
    # Actualizar balance
    meta["balance"] += amount
    meta["balance"] = round(meta["balance"], 2)
    
    S["resellers_meta"][str(reseller_id)] = meta
    S.setdefault("payments", []).append(payment)
    record_invoice(inv)
    
    logger.info(f"Topup reseller {reseller_id}: +{amount} USD, balance={meta['balance']}, method={method}")
    
    return inv

def adjust_reseller(reseller_id: int, amount: float, note: str) -> dict:
    """
    Ajuste manual de saldo (positivo = suma, negativo = resta).
    Crea invoice type="adjust".
    Returns: invoice dict
    """
    meta = get_reseller_meta(reseller_id)
    
    # Crear invoice adjust
    inv = {
        "id": invoice_id(),
        "type": "adjust",
        "who": "reseller",
        "reseller_id": reseller_id,
        "total": round(amount, 2),
        "currency": S.get("currency", "USD"),
        "ts": dt.datetime.now().isoformat(timespec="seconds"),
        "note": note
    }
    
    # Actualizar balance
    meta["balance"] += amount
    meta["balance"] = round(meta["balance"], 2)
    
    S["resellers_meta"][str(reseller_id)] = meta
    record_invoice(inv)
    
    logger.info(f"Adjust reseller {reseller_id}: {'+' if amount >= 0 else ''}{amount} USD, balance={meta['balance']}")
    
    return inv

def parse_iso(iso_str: str | None) -> dt.datetime | None:
    """Parse ISO datetime string"""
    if not iso_str:
        return None
    try:
        return dt.datetime.fromisoformat(iso_str)
    except:
        return None

def should_notify(rid: int, kind: str, now: dt.datetime) -> bool:
    """
    Verifica si debe enviar notificación respetando cooldown.
    kind: low_balance, credit_in_use, credit_exhausted, paused_for_balance
    """
    meta = get_reseller_meta(rid)
    last = meta.get("last_notify", {}).get(kind)
    
    if not last:
        return True
    
    cooldown_hours = S.get("settings", {}).get("notify_cooldown_hours", 12)
    last_dt = parse_iso(last)
    
    if not last_dt:
        return True
    
    elapsed_hours = (now - last_dt).total_seconds() / 3600
    return elapsed_hours >= cooldown_hours

def mark_notified(rid: int, kind: str, now: dt.datetime):
    """Marca que se envió notificación del tipo kind"""
    meta = get_reseller_meta(rid)
    if "last_notify" not in meta:
        meta["last_notify"] = {
            "low_balance": None,
            "credit_in_use": None,
            "credit_exhausted": None,
            "paused_for_balance": None
        }
    meta["last_notify"][kind] = now.isoformat(timespec="seconds")
    S["resellers_meta"][str(rid)] = meta
    save_state(S)

def get_active_bots_count(rid: int) -> int:
    """Cuenta bots activos de un reseller"""
    count = 0
    for slug, c in S.get("clients", {}).items():
        if c.get("reseller_id") == rid and c.get("provisioned"):
            svc = f"reenvio@{slug}.service"
            if _svc_status(svc) == "active":
                count += 1
    return count

async def notify_low_balance(rid: int):
    """
    Alerta tipo 1: Saldo bajo (balance <= low_balance_threshold y balance >= 0)
    """
    now = dt.datetime.now()
    
    if not should_notify(rid, "low_balance", now):
        return
    
    meta = get_reseller_meta(rid)
    balance = meta["balance"]
    credit_limit = meta["credit_limit"]
    currency = S.get("currency", "USD")
    threshold = S["settings"].get("low_balance_threshold", 5.0)
    
    # Calcular sugerencia de recarga para ~7 días
    active_bots = get_active_bots_count(rid)
    daily_cost = active_bots * (4.0 / 30.0)
    suggested_topup = max(5.0, round(7 * daily_cost, 2))
    
    msg = (
        f"⚠️ *Saldo Bajo*\n\n"
        f"Tu saldo: `{fmt_money(balance)} {currency}`\n"
        f"Umbral: `{fmt_money(threshold)} {currency}`\n\n"
        f"💡 Sugerencia: recarga `{fmt_money(suggested_topup)} {currency}` para cubrir ~7 días\n"
        f"_(Estimado: {active_bots} bot{'s' if active_bots != 1 else ''} activo{'s' if active_bots != 1 else ''} × {fmt_money(daily_cost)} {currency}/día)_"
    )
    
    kb = [
        [Button.inline("💼 Ver saldo", b"res_balance")],
        [Button.inline("💳 Pedir recarga", b"res_topup_help")],
        [Button.url("💬 Contactar @frankosmel", "https://t.me/frankosmel")]
    ]
    
    try:
        await bot.send_message(rid, msg, buttons=kb, parse_mode="Markdown")
        mark_notified(rid, "low_balance", now)
        logger.info(f"Notificación low_balance enviada a reseller {rid}")
    except Exception as e:
        logger.error(f"Error enviando notify_low_balance a {rid}: {e}")

async def notify_credit_in_use(rid: int):
    """
    Alerta tipo 2: Usando crédito (balance < 0 y balance >= -credit_limit)
    """
    now = dt.datetime.now()
    
    if not should_notify(rid, "credit_in_use", now):
        return
    
    meta = get_reseller_meta(rid)
    balance = meta["balance"]
    credit_limit = meta["credit_limit"]
    currency = S.get("currency", "USD")
    disponible = balance + credit_limit
    
    msg = (
        f"ℹ️ *Estás Usando Crédito* (saldo negativo)\n\n"
        f"Saldo: `{fmt_money(balance)} {currency}`\n"
        f"Límite crédito: `{fmt_money(credit_limit)} {currency}`\n"
        f"Disponible: `{fmt_money(disponible)} {currency}`\n\n"
        f"⚠️ Debes pagar tu deuda y luego recargar para evitar pausas."
    )
    
    kb = [
        [Button.inline("💼 Ver saldo", b"res_balance")],
        [Button.inline("📈 Estado de cuenta", b"res_statement")],
        [Button.inline("💳 Pedir recarga", b"res_topup_help")],
        [Button.url("💬 Contactar @frankosmel", "https://t.me/frankosmel")]
    ]
    
    try:
        await bot.send_message(rid, msg, buttons=kb, parse_mode="Markdown")
        mark_notified(rid, "credit_in_use", now)
        logger.info(f"Notificación credit_in_use enviada a reseller {rid}")
    except Exception as e:
        logger.error(f"Error enviando notify_credit_in_use a {rid}: {e}")

async def notify_credit_exhausted(rid: int):
    """
    Alerta tipo 3: Crédito agotado (balance < -credit_limit)
    Última advertencia antes de pausar servicios
    """
    now = dt.datetime.now()
    
    if not should_notify(rid, "credit_exhausted", now):
        return
    
    meta = get_reseller_meta(rid)
    balance = meta["balance"]
    credit_limit = meta["credit_limit"]
    currency = S.get("currency", "USD")
    
    msg = (
        f"⛔ *Crédito Agotado*\n\n"
        f"Saldo: `{fmt_money(balance)} {currency}`\n"
        f"Límite crédito: `{fmt_money(credit_limit)} {currency}`\n\n"
        f"🚨 No se pudo cobrar el uso de hoy.\n"
        f"*Si no recargas, tus bots serán pausados.*"
    )
    
    kb = [
        [Button.inline("💳 Pedir recarga", b"res_topup_help")],
        [Button.inline("💼 Ver saldo", b"res_balance")],
        [Button.url("💬 Contactar @frankosmel", "https://t.me/frankosmel")]
    ]
    
    try:
        await bot.send_message(rid, msg, buttons=kb, parse_mode="Markdown")
        mark_notified(rid, "credit_exhausted", now)
        logger.info(f"Notificación credit_exhausted enviada a reseller {rid}")
    except Exception as e:
        logger.error(f"Error enviando notify_credit_exhausted a {rid}: {e}")

async def notify_paused_for_balance(rid: int, affected_slugs: list):
    """
    Alerta tipo 4: Servicios pausados por saldo insuficiente
    Notifica al reseller y a cada cliente afectado
    """
    now = dt.datetime.now()
    
    meta = get_reseller_meta(rid)
    balance = meta["balance"]
    credit_limit = meta["credit_limit"]
    currency = S.get("currency", "USD")
    
    # Notificar al reseller
    if should_notify(rid, "paused_for_balance", now):
        msg_reseller = (
            f"🔴 *Servicios Pausados por Saldo/Crédito*\n\n"
            f"Saldo: `{fmt_money(balance)} {currency}`\n"
            f"Límite crédito: `{fmt_money(credit_limit)} {currency}`\n"
            f"Clientes afectados: `{len(affected_slugs)}`\n\n"
            f"💳 Recarga para reactivar automáticamente."
        )
        
        kb_reseller = [
            [Button.inline("👥 Ver clientes", b"reseller_clients")],
            [Button.inline("💳 Pedir recarga", b"res_topup_help")],
            [Button.url("💬 Contactar @frankosmel", "https://t.me/frankosmel")]
        ]
        
        try:
            await bot.send_message(rid, msg_reseller, buttons=kb_reseller, parse_mode="Markdown")
            mark_notified(rid, "paused_for_balance", now)
            logger.info(f"Notificación paused_for_balance enviada a reseller {rid}")
        except Exception as e:
            logger.error(f"Error enviando notify_paused_for_balance (reseller) a {rid}: {e}")
    
    # Notificar a cada cliente
    for slug in affected_slugs:
        c = S.get("clients", {}).get(slug)
        if not c:
            continue
        
        client_id = c.get("owner_id")
        if not client_id:
            continue
        
        msg_client = (
            f"⏸️ *Tu Bot fue Pausado*\n\n"
            f"Bot: `{slug}`\n"
            f"Motivo: Saldo insuficiente de tu reseller\n\n"
            f"📞 Contacta a tu reseller o a @frankosmel para reactivar."
        )
        
        kb_client = [
            [Button.inline("📊 Ver estado", f"status:{slug}".encode())],
            [Button.url("💬 Contactar soporte", "https://t.me/frankosmel")]
        ]
        
        try:
            await bot.send_message(client_id, msg_client, buttons=kb_client, parse_mode="Markdown")
            logger.info(f"Notificación paused_for_balance enviada a cliente {client_id} (slug={slug})")
        except Exception as e:
            logger.error(f"Error enviando notify_paused_for_balance (cliente) a {client_id}: {e}")

async def notify_service_reactivated(rid: int, reactivated_slugs: list):
    """
    Notifica al reseller que sus servicios fueron reactivados tras recarga
    """
    meta = get_reseller_meta(rid)
    balance = meta["balance"]
    currency = S.get("currency", "USD")
    
    msg = (
        f"🟢 *Servicios Reactivados*\n\n"
        f"Saldo actual: `{fmt_money(balance)} {currency}`\n"
        f"Bots reactivados: `{len(reactivated_slugs)}`\n\n"
        f"Si el saldo vuelve a caer bajo, te avisaremos."
    )
    
    kb = [[Button.inline("💼 Ver saldo", b"res_balance")]]
    
    try:
        await bot.send_message(rid, msg, buttons=kb, parse_mode="Markdown")
        logger.info(f"Notificación service_reactivated enviada a reseller {rid}")
    except Exception as e:
        logger.error(f"Error enviando notify_service_reactivated a {rid}: {e}")

# ============================================================================
# FIN FACTURACIÓN HELPERS
# ============================================================================

def kb_clients_paginated(prefix: str, *, for_user: int, page: int = 0, page_size: int = 8) -> List[List[Button]]:
    """Lista clientes con paginación"""
    clients_list = []
    for slug, c in sorted(S.get("clients", {}).items()):
        if is_admin(for_user) or (is_reseller(for_user) and c.get("reseller_id") == for_user) or c.get("owner_id") == for_user:
            clients_list.append((slug, c))
    
    total = len(clients_list)
    total_pages = (total + page_size - 1) // page_size if total > 0 else 1
    page = max(0, min(page, total_pages - 1))
    
    start = page * page_size
    end = start + page_size
    page_clients = clients_list[start:end]
    
    rows = []
    row = []
    for slug, c in page_clients:
        row.append(Button.inline(f"👤 {slug}", f"{prefix}:{slug}:p{page}".encode()))
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    
    nav_row = []
    if page > 0:
        nav_row.append(Button.inline("◀️ Anterior", f"{prefix}:nav:p{page-1}".encode()))
    if page < total_pages - 1:
        nav_row.append(Button.inline("▶️ Siguiente", f"{prefix}:nav:p{page+1}".encode()))
    if nav_row:
        rows.append(nav_row)
    
    rows.append([Button.inline("❌ Cancelar", f"{prefix}:cancel".encode())])
    return rows

def clone_template(plan: str, workdir: Path):
    if plan not in TEMPL:
        raise RuntimeError(f"❌ Plan inválido: {plan}")
    if workdir.exists():
        shutil.rmtree(workdir)
    if not TEMPL[plan].exists():
        raise RuntimeError(f"❌ Falta plantilla: {TEMPL[plan]}")
    shutil.copytree(TEMPL[plan], workdir)

def ensure_venv_and_requirements(workdir: Path):
    venv = workdir / "venv"
    if not venv.exists():
        run(f"python3 -m venv '{venv}'")
        run(f"'{venv}/bin/pip' install --upgrade pip")
    req = workdir / "requirements.txt"
    if req.exists():
        run(f"'{venv}/bin/pip' install -r '{req}'")
    else:
        run(f"'{venv}/bin/pip' install telethon==1.36.0 python-dotenv==1.0.1 requests==2.31.0")

def write_env(workdir: Path, *, bot_token: str, owner_id: int, slug: str,
              tz: str = "UTC", qstart: str = "00:30", qend: str = "07:00"):
    apid, apih = API_ID, API_HASH
    tpl_env = workdir / ".env"
    if tpl_env.exists():
        try:
            from dotenv import dotenv_values
            vals = dotenv_values(tpl_env)
            apid = int(vals.get("API_ID", apid) or apid)
            apih = vals.get("API_HASH", apih) or apih
        except Exception:
            pass
    ENV = (
        f"API_ID={apid}\n"
        f"API_HASH={apih}\n"
        f"BOT_TOKEN={bot_token}\n"
        f"OWNER_ID={owner_id}\n"
        f"USER_SESSION={slug}_user\n"
        f"BOT_SESSION={slug}panel\n"
        f"STATE_FILE=state{slug}.json\n"
        f"TIMEZONE={tz}\n"
        f"QUIET_START={qstart}\n"
        f"QUIET_END={qend}\n"
    )
    (workdir / ".env").write_text(ENV)

def force_load_dotenv_override(workdir: Path):
    py = workdir / "telethon_userbot_listas_publicaciones.py"
    if not py.exists():
        return
    txt = py.read_text()
    if "load_dotenv(" in txt and "override=True" in txt:
        return
    if "load_dotenv" not in txt:
        txt = (
            "from pathlib import Path as _P\n"
            "from dotenv import load_dotenv\n"
            "load_dotenv(dotenv_path=_P(__file__).with_name('.env'), override=True)\n"
        ) + txt
    else:
        txt = re.sub(r"load_dotenv\(.*?\)", r"load_dotenv(\1, override=True)", txt, count=1, flags=re.S)
    py.write_text(txt)

def _read_env(workdir: Path) -> dict:
    envp = workdir / ".env"
    out = {}
    if not envp.exists(): 
        return out
    for line in envp.read_text().splitlines():
        if "=" in line and not line.strip().startswith("#"):
            k, v = line.split("=", 1)
            out[k.strip()] = v.strip()
    return out

def _get_bot_meta(token: str) -> dict:
    try:
        import requests
        r = requests.get(f"https://api.telegram.org/bot{token}/getMe", timeout=6)
        j = r.json()
        if j.get("ok"):
            res = j.get("result", {})
            return {"ok": True, "username": res.get("username"), "id": res.get("id")}
        return {"ok": False, "username": None, "id": None}
    except Exception:
        return {"ok": False, "username": None, "id": None}

def uniq_slug(base: str) -> str:
    base = (base or "").strip().lstrip("@")
    base = re.sub(r"[^a-zA-Z0-9_]+", "", base) or "cliente"
    slug = base
    n = 2
    while slug in S.get("clients", {}):
        slug = f"{base}{n}"
        n += 1
    return slug

flows: Dict[int, Dict[str, Any]] = {}

bot = TelegramClient("manager_bot", API_ID, API_HASH)

LBL_BACK = "◀️ Volver"

ADMIN_MAIN = [
    ["👥 Clientes", "🤝 Resellers"],
    ["💰 Facturación", "🛠️ Mantenimiento"],
    ["⚙️ Configuración", "📊 Reportes"],
    ["❓ Ayuda"],
]

ADMIN_CLIENTS = [
    ["➕ Autorizar cliente", "🔁 Renovar"],
    ["🗂 Cambiar plan", "🚫 Revocar acceso"],
    ["🖥 Estado/Servicio"],
    [LBL_BACK],
]

ADMIN_RESELLERS = [
    ["➕ Agregar reseller", "🗒 Listar resellers"],
    ["👥 Ver clientes por reseller"],
    ["🗑️ Remover reseller"],
    [LBL_BACK],
]

ADMIN_CONFIG = [
    ["👮 Admins"],
    ["⏱ Notificaciones de vencimiento"],
    ["📦 Plantillas por plan"],
    [LBL_BACK],
]

ADMIN_ADMINS = [
    ["➕ Agregar admin", "🗑️ Remover admin"],
    ["📋 Listar admins"],
    [LBL_BACK],
]

ADMIN_MAINT = [
    ["⬆️ Upgrade cliente", "⬆️⬆️ Upgrade todos"],
    ["🔄 Reiniciar servicio", "🧹 Limpiar sesiones"],
    [LBL_BACK],
]

ADMIN_REPORTS = [
    ["🗓 Vencen hoy/mañana", "🧮 Clientes por reseller"],
    ["🟢/🔴 Servicios activos/caídos"],
    [LBL_BACK],
]

ADMIN_BILLING = [
    ["🏷️ Lista de precios", "✏️ Cambiar precios"],
    ["💼 Ver movimientos", "📊 Reportes facturación"],
    ["💳 Recargar saldo reseller", "⚖️ Ajuste manual"],
    ["💰 Cambiar límite crédito", "🎁 Descuentos reseller"],
    [LBL_BACK],
]

RESELLER_MAIN = [
    ["👥 Mis clientes", "➕ Autorizar"],
    ["🔁 Renovar", "🗂 Cambiar plan"],
    ["💼 Mi saldo", "💳 Recargar saldo"],
    ["🚫 Revocar", "❓ Ayuda"],
]

CLIENT_MAIN = [
    ["🚀 Provisionar", "📊 Status"],
    ["💳 Pagar servicio", "🧑‍💻 Soporte"],
]

def rk(rows):
    return [[Button.text(x) for x in row] for row in rows]

async def show_admin_main(ev):
    await ev.respond("🔧 *Panel Administrador*\n\nSelecciona una opción:", buttons=rk(ADMIN_MAIN), parse_mode="Markdown")

async def show_admin_clients(ev):
    flows[ev.sender_id] = {**flows.get(ev.sender_id, {}), "menu": "admin_clients"}
    await ev.respond("👥 *Gestión de Clientes*\n\nOpciones disponibles:", buttons=rk(ADMIN_CLIENTS), parse_mode="Markdown")

async def show_admin_resellers(ev):
    flows[ev.sender_id] = {**flows.get(ev.sender_id, {}), "menu": "admin_resellers"}
    await ev.respond("🤝 *Gestión de Resellers*\n\nOpciones disponibles:", buttons=rk(ADMIN_RESELLERS), parse_mode="Markdown")

async def show_admin_config(ev):
    flows[ev.sender_id] = {**flows.get(ev.sender_id, {}), "menu": "admin_config"}
    await ev.respond("⚙️ *Configuración del Sistema*\n\nOpciones:", buttons=rk(ADMIN_CONFIG), parse_mode="Markdown")

async def show_admin_admins(ev):
    flows[ev.sender_id] = {**flows.get(ev.sender_id, {}), "menu": "admin_admins"}
    await ev.respond("👮 *Gestión de Administradores*\n\nOpciones:", buttons=rk(ADMIN_ADMINS), parse_mode="Markdown")

async def show_admin_maint(ev):
    flows[ev.sender_id] = {**flows.get(ev.sender_id, {}), "menu": "admin_maint"}
    await ev.respond("🛠️ *Mantenimiento del Sistema*\n\nOpciones:", buttons=rk(ADMIN_MAINT), parse_mode="Markdown")

async def show_admin_reports(ev):
    flows[ev.sender_id] = {**flows.get(ev.sender_id, {}), "menu": "admin_reports"}
    await ev.respond("📊 *Reportes y Estadísticas*\n\nSelecciona:", buttons=rk(ADMIN_REPORTS), parse_mode="Markdown")

async def show_admin_billing(ev):
    flows[ev.sender_id] = {**flows.get(ev.sender_id, {}), "menu": "admin_billing"}
    
    # Estadísticas rápidas
    total_invoices = len(S.get("invoices", []))
    total_payments = len(S.get("payments", []))
    
    msg = (
        f"💰 *Sistema de Facturación*\n\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"📋 Invoices registrados: `{total_invoices}`\n"
        f"💳 Pagos registrados: `{total_payments}`\n"
        f"━━━━━━━━━━━━━━━━\n\n"
        f"Selecciona una opción:"
    )
    
    await ev.respond(msg, buttons=rk(ADMIN_BILLING), parse_mode="Markdown")

async def show_reseller_main(ev):
    flows[ev.sender_id] = {**flows.get(ev.sender_id, {}), "menu": "reseller_main"}
    await ev.respond("🧑‍💼 *Panel Reseller*\n\nOpciones disponibles:", buttons=rk(RESELLER_MAIN), parse_mode="Markdown")

async def show_client_main(ev):
    flows[ev.sender_id] = {**flows.get(ev.sender_id, {}), "menu": "client_main"}
    await ev.respond("👤 *Panel Cliente*\n\nOpciones:", buttons=rk(CLIENT_MAIN), parse_mode="Markdown")

async def resolve_user_to_id(bot_instance, identifier: str) -> Tuple[Optional[int], Optional[str]]:
    """Resuelve @usuario o ID a (user_id, username) con validación robusta"""
    try:
        # Limpiar entrada
        identifier = identifier.strip()
        if not identifier:
            logger.error("Identificador vacío en resolve_user_to_id")
            return None, None
        
        if identifier.startswith("@"):
            identifier = identifier[1:]
        
        if identifier.isdigit():
            user_id = int(identifier)
            try:
                entity = await bot_instance.get_entity(user_id)
                username = getattr(entity, "username", None)
                logger.info(f"✅ Usuario resuelto por ID: {user_id} (@{username or 'sin_username'})")
                return user_id, username
            except Exception as e:
                logger.warning(f"Usuario ID {user_id} no encontrado o inaccesible: {e}")
                return user_id, None
        else:
            entity = await bot_instance.get_entity(identifier)
            user_id = entity.id
            username = getattr(entity, "username", None)
            logger.info(f"✅ Usuario resuelto por username: @{identifier} → ID {user_id}")
            return user_id, username
    except ValueError as e:
        logger.error(f"❌ Identificador inválido '{identifier}': {e}")
        return None, None
    except Exception as e:
        logger.error(f"❌ Error resolviendo usuario '{identifier}': {e}")
        return None, None

async def check_expiring_plans():
    """🔔 Revisa planes que vencen mañana y maneja expirados con días de gracia"""
    try:
        if not S.get("notify_expiry", True):
            return
        
        current_state = load_state()
        grace_days = current_state.get("settings", {}).get("grace_days", 2)
        auto_pause = current_state.get("settings", {}).get("auto_pause_on_expiry", True)
        notify_reseller = current_state.get("settings", {}).get("notify_expiry_reseller", True)
        
        tomorrow = (dt.date.today() + dt.timedelta(days=1)).isoformat()
        today = dt.date.today().isoformat()

        for slug, client_info in current_state.get("clients", {}).items():
            expires_at = client_info.get("expires_at")
            owner_id = client_info.get("owner_id")
            if not expires_at or not owner_id:
                continue
            
            # Vence mañana: aviso preventivo
            if expires_at == tomorrow:
                await send_expiry_notification(slug, client_info, "warning")
                
                # Notificar al reseller si está habilitado
                if notify_reseller:
                    reseller_id = client_info.get("reseller_id")
                    if reseller_id:
                        await notify_reseller_expiry(reseller_id, slug, client_info, "warning")
            
            # Ya venció: manejar con días de gracia
            elif expires_at <= today:
                exp_date = dt.date.fromisoformat(expires_at)
                days_expired = (dt.date.today() - exp_date).days
                
                if days_expired == 0:
                    # Primer día vencido
                    if grace_days > 0:
                        # Avisar que entró en periodo de gracia
                        await send_expiry_notification(slug, client_info, "grace_start")
                        if notify_reseller:
                            reseller_id = client_info.get("reseller_id")
                            if reseller_id:
                                await notify_reseller_expiry(reseller_id, slug, client_info, "grace_start")
                    elif auto_pause:
                        # Sin gracia, pausar inmediatamente
                        await handle_expired_service(slug, client_info)
                        if notify_reseller:
                            reseller_id = client_info.get("reseller_id")
                            if reseller_id:
                                await notify_reseller_expiry(reseller_id, slug, client_info, "expired")
                
                elif days_expired >= grace_days and grace_days > 0:
                    # Terminó el periodo de gracia, pausar
                    if auto_pause:
                        await handle_expired_service(slug, client_info)
                        if notify_reseller:
                            reseller_id = client_info.get("reseller_id")
                            if reseller_id:
                                await notify_reseller_expiry(reseller_id, slug, client_info, "expired")
                
                # Notificación de amenaza de eliminación 1 día después de pausa
                elif days_expired == grace_days + 1 and grace_days > 0:
                    # Ya fue pausado hace 1 día, enviar amenaza de eliminación
                    await send_expiry_notification(slug, client_info, "deletion_threat")
                    if notify_reseller:
                        reseller_id = client_info.get("reseller_id")
                        if reseller_id:
                            await notify_reseller_expiry(reseller_id, slug, client_info, "deletion_threat")

        current_state["last_expiry_check"] = dt.datetime.now().isoformat()
        save_state(current_state)

    except Exception as e:
        logger.error(f"Error en check_expiring_plans: {e}")

async def send_expiry_notification(slug: str, client_info: dict, notification_type: str):
    try:
        owner_id = client_info.get("owner_id")
        expires_at = client_info.get("expires_at")
        plan = client_info.get("plan", "plan_estandar")
        workdir = Path(client_info.get("workdir", ""))

        env = _read_env(workdir)
        token = env.get("BOT_TOKEN", "")
        bot_meta = {"username": None, "id": None}
        if token:
            try:
                bot_meta = _get_bot_meta(token)
            except Exception:
                pass

        svc = f"reenvio@{slug}.service"
        status = _svc_status(svc)
        status_emoji = "🟢" if status == "active" else "🔴"
        
        grace_days = S.get("settings", {}).get("grace_days", 2)

        if notification_type == "warning":
            message = (
                "⚠️ *AVISO DE VENCIMIENTO* ⚠️\n\n"
                f"🎫 *Plan:* {plan}\n"
                f"📅 *Vence mañana:* {expires_at}\n"
                f"{status_emoji} *Servicio:* {status}\n"
                f"🤖 *Tu bot:* @{bot_meta.get('username', 'N/A')}\n\n"
                f"📞 *Para renovar tu plan, contacta:*\n"
                f"👨‍💻 @frankosmel\n\n"
                f"ℹ️ Si no renuevas, tu servicio se pausará automáticamente."
            )
            keyboard = [
                [Button.url("💬 Contactar @frankosmel", "https://t.me/frankosmel")],
                [Button.inline("📊 Ver estado", f"status:{slug}".encode())],
            ]
        elif notification_type == "grace_start":
            message = (
                "🔶 *SERVICIO VENCIDO - PERIODO DE GRACIA* 🔶\n\n"
                f"🎫 *Plan:* {plan}\n"
                f"📅 *Venció:* {expires_at}\n"
                f"⏳ *Periodo de gracia:* {grace_days} días\n"
                f"{status_emoji} *Servicio:* {status} (por ahora)\n"
                f"🤖 *Tu bot:* @{bot_meta.get('username', 'N/A')}\n\n"
                f"⚠️ *Tu servicio seguirá activo por {grace_days} días más.*\n"
                f"Si no renuevas en este periodo, se pausará automáticamente.\n\n"
                f"📞 *Para renovar, contacta:*\n"
                f"👨‍💻 @frankosmel"
            )
            keyboard = [
                [Button.url("💬 Contactar @frankosmel para renovar", "https://t.me/frankosmel")],
                [Button.inline("📊 Ver estado", f"status:{slug}".encode())],
            ]
        elif notification_type == "deletion_threat":
            message = (
                "⚠️ *ÚLTIMA ADVERTENCIA - ELIMINACIÓN INMINENTE* ⚠️\n\n"
                f"🎫 *Plan:* {plan}\n"
                f"📅 *Venció:* {expires_at}\n"
                f"⏸️ *Estado:* Pausado hace 1 día\n"
                f"🤖 *Bot afectado:* @{bot_meta.get('username', 'N/A')}\n\n"
                f"🚨 *Si no renuevas en los próximos 5 días, tu bot será ELIMINADO PERMANENTEMENTE.*\n\n"
                f"📞 *Para renovar AHORA y evitar la eliminación, contacta:*\n"
                f"👨‍💻 @frankosmel"
            )
            keyboard = [
                [Button.url("💬 ¡RENOVAR AHORA! - Contactar @frankosmel", "https://t.me/frankosmel")],
                [Button.inline("📊 Ver estado", f"status:{slug}".encode())]
            ]
        else:  # expired
            message = (
                "🔴 *SERVICIO PAUSADO* 🔴\n\n"
                f"🎫 *Plan:* {plan}\n"
                f"📅 *Venció:* {expires_at}\n"
                f"⏸️ *Estado:* Servicio pausado\n"
                f"🤖 *Bot afectado:* @{bot_meta.get('username', 'N/A')}\n\n"
                f"📞 *Para reactivar, contacta:*\n"
                f"👨‍💻 @frankosmel"
            )
            keyboard = [[Button.url("💬 Contactar @frankosmel para renovar", "https://t.me/frankosmel")]]

        await bot.send_message(owner_id, message, buttons=keyboard, parse_mode="Markdown")
        logger.info(f"Notificación de {notification_type} enviada a {owner_id} para {slug}")

    except Exception as e:
        logger.error(f"Error enviando notificación a {client_info.get('owner_id')}: {e}")

async def notify_reseller_expiry(reseller_id: int, slug: str, client_info: dict, notification_type: str):
    """Notifica al reseller sobre vencimientos de sus clientes"""
    try:
        expires_at = client_info.get("expires_at")
        plan = client_info.get("plan", "plan_estandar")
        grace_days = S.get("settings", {}).get("grace_days", 2)
        username_display = get_username_display(reseller_id)
        
        if notification_type == "warning":
            message = (
                f"⚠️ *Vencimiento Próximo - Cliente*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"🎫 Cliente: `{slug}`\n"
                f"📦 Plan: {plan}\n"
                f"📅 Vence: *mañana* ({expires_at})\n"
                f"━━━━━━━━━━━━━━━━\n\n"
                f"Recuerda contactar al cliente para renovar."
            )
            kb = [
                [Button.inline("👤 Ver cliente", f"status_inline:{slug}".encode())],
                [Button.inline("🔁 Renovar ahora", f"renew_inline:{slug}".encode())],
                [Button.inline("💼 Ver mi saldo", b"reseller_balance")]
            ]
        elif notification_type == "grace_start":
            message = (
                f"🔶 *Cliente Vencido - En Gracia*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"🎫 Cliente: `{slug}`\n"
                f"📦 Plan: {plan}\n"
                f"📅 Venció: {expires_at}\n"
                f"⏳ Gracia: {grace_days} días\n"
                f"━━━━━━━━━━━━━━━━\n\n"
                f"El servicio seguirá activo por {grace_days} días más.\n"
                f"Después se pausará automáticamente."
            )
            kb = [
                [Button.inline("🔁 Renovar ahora", f"renew_inline:{slug}".encode())],
                [Button.inline("💼 Ver mi saldo", b"reseller_balance")]
            ]
        elif notification_type == "deletion_threat":
            message = (
                f"🚨 *ALERTA: Cliente Será Eliminado*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"🎫 Cliente: `{slug}`\n"
                f"📦 Plan: {plan}\n"
                f"📅 Venció: {expires_at}\n"
                f"⏸️ Estado: *Pausado hace 1 día*\n"
                f"━━━━━━━━━━━━━━━━\n\n"
                f"⚠️ *Si no renuevas en 5 días, el bot será ELIMINADO.*\n"
                f"Contacta a @frankosmel URGENTE."
            )
            kb = [
                [Button.inline("🔁 Renovar ahora", f"renew_inline:{slug}".encode())],
                [Button.inline("💼 Ver mi saldo", b"reseller_balance")],
                [Button.url("💬 Contactar @frankosmel", "https://t.me/frankosmel")]
            ]
        else:  # expired
            message = (
                f"🔴 *Cliente Pausado*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"🎫 Cliente: `{slug}`\n"
                f"📦 Plan: {plan}\n"
                f"📅 Venció: {expires_at}\n"
                f"⏸️ Estado: *Pausado*\n"
                f"━━━━━━━━━━━━━━━━\n\n"
                f"El servicio ha sido pausado por falta de renovación."
            )
            kb = [
                [Button.inline("🔁 Renovar ahora", f"renew_inline:{slug}".encode())],
                [Button.inline("💼 Ver mi saldo", b"reseller_balance")]
            ]
        
        await bot.send_message(reseller_id, message, buttons=kb, parse_mode="Markdown")
        logger.info(f"Notificación de {notification_type} enviada a reseller {reseller_id} para cliente {slug}")
        
    except Exception as e:
        logger.error(f"Error notificando reseller {reseller_id} sobre {slug}: {e}")

async def handle_expired_service(slug: str, client_info: dict):
    try:
        svc = f"reenvio@{slug}.service"
        status = _svc_status(svc)
        if status == "active":
            pause_instance_service(slug)
            logger.info(f"Servicio {svc} pausado por expiración")
            await send_expiry_notification(slug, client_info, "expired")
    except Exception as e:
        logger.error(f"Error pausando servicio {slug}: {e}")

async def daily_usage_billing():
    """
    💰 Cobra diariamente a cada reseller por bots activos.
    Costo: bots_activos × $0.1333/día
    Evalúa alertas de balance y pausa servicios si es necesario.
    """
    try:
        current_state = load_state()
        resellers = current_state.get("resellers", [])
        
        logger.info("Iniciando cobro diario automático...")
        
        for rid in resellers:
            try:
                # Contar bots activos del reseller
                active_bots = get_active_bots_count(rid)
                
                if active_bots == 0:
                    continue
                
                # Calcular costo diario
                unit_day = 4.0 / 30.0  # $0.1333
                daily_cost = round(active_bots * unit_day, 2)
                
                meta = get_reseller_meta(rid)
                balance = meta["balance"]
                credit_limit = meta["credit_limit"]
                available = balance + credit_limit
                
                logger.info(f"Reseller {rid}: {active_bots} bots activos, costo diario={daily_cost}, disponible={available}")
                
                # Verificar si tiene saldo disponible
                if available >= daily_cost:
                    # Debitar el costo diario
                    invoice = debit_reseller(
                        reseller_id=rid,
                        total=daily_cost,
                        note=f"Cobro diario automático: {active_bots} bot{'s' if active_bots != 1 else ''}",
                        client_slug="daily_usage",
                        plan="daily",
                        days=1
                    )
                    
                    # Recargar meta actualizado
                    meta = get_reseller_meta(rid)
                    new_balance = meta["balance"]
                    
                    logger.info(f"💸 Descuento diario aplicado: Reseller {rid}, ${daily_cost} USD, nuevo saldo: ${new_balance} USD")
                    
                    # Resetear exhausted_seen si logró pagar
                    if meta.get("exhausted_seen"):
                        meta["exhausted_seen"] = False
                        S["resellers_meta"][str(rid)] = meta
                        save_state(S)
                    
                    # Evaluar alertas después del cobro
                    threshold_low = S["settings"].get("low_balance_threshold", 5.0)
                    
                    if new_balance >= 0 and new_balance <= threshold_low:
                        # Alerta 1: Saldo bajo
                        await notify_low_balance(rid)
                    elif new_balance < 0 and new_balance >= -credit_limit:
                        # Alerta 2: Usando crédito
                        await notify_credit_in_use(rid)
                    
                else:
                    # No tiene suficiente saldo disponible
                    meta = get_reseller_meta(rid)
                    
                    if not meta.get("exhausted_seen"):
                        # Primera vez que no puede pagar: notificar credit_exhausted
                        await notify_credit_exhausted(rid)
                        meta["exhausted_seen"] = True
                        S["resellers_meta"][str(rid)] = meta
                        save_state(S)
                        logger.warning(f"Reseller {rid}: Crédito agotado, no se pudo cobrar {daily_cost}")
                    else:
                        # Ya fue notificado antes y sigue sin saldo: pausar servicios
                        slugs_to_pause = []
                        for slug, c in current_state.get("clients", {}).items():
                            if c.get("reseller_id") == rid and c.get("provisioned"):
                                svc = f"reenvio@{slug}.service"
                                if _svc_status(svc) == "active":
                                    pause_instance_service(slug)
                                    slugs_to_pause.append(slug)
                                    logger.info(f"Servicio {svc} pausado por saldo insuficiente del reseller {rid}")
                        
                        if slugs_to_pause:
                            # Notificar pausa por balance
                            await notify_paused_for_balance(rid, slugs_to_pause)
                        
                        logger.warning(f"Reseller {rid}: Servicios pausados por saldo/crédito agotado")
            
            except Exception as e:
                logger.error(f"Error procesando cobro diario para reseller {rid}: {e}")
        
        logger.info("Cobro diario automático completado")
        
    except Exception as e:
        logger.error(f"Error en daily_usage_billing: {e}")

async def scheduled_daily_billing():
    """Wrapper para APScheduler: ejecuta cobro diario"""
    try:
        await daily_usage_billing()
    except Exception as e:
        logger.error(f"Error en scheduled_daily_billing: {e}")

async def check_balance_reactivations():
    """
    Verifica si resellers con servicios pausados por balance han recargado.
    Si balance >= 0, reactiva automáticamente todos sus servicios.
    """
    try:
        current_state = load_state()
        resellers = current_state.get("resellers", [])
        
        for rid in resellers:
            try:
                meta = get_reseller_meta(rid)
                balance = meta["balance"]
                credit_limit = meta["credit_limit"]
                
                # Solo procesar si ha salido del crédito agotado (balance >= 0)
                if balance >= 0 and meta.get("exhausted_seen"):
                    # Buscar servicios pausados de este reseller
                    reactivated_slugs = []
                    
                    for slug, c in current_state.get("clients", {}).items():
                        if c.get("reseller_id") == rid and c.get("provisioned"):
                            svc = f"reenvio@{slug}.service"
                            status = _svc_status(svc)
                            
                            if status != "active":
                                # Intentar reactivar
                                try:
                                    resume_instance_service(slug)
                                    if _svc_status(svc) == "active":
                                        reactivated_slugs.append(slug)
                                        logger.info(f"Servicio {svc} reactivado automáticamente para reseller {rid}")
                                except Exception as e:
                                    logger.error(f"Error reactivando {svc}: {e}")
                    
                    if reactivated_slugs:
                        # Resetear exhausted_seen
                        meta["exhausted_seen"] = False
                        S["resellers_meta"][str(rid)] = meta
                        save_state(S)
                        
                        # Notificar reactivación
                        await notify_service_reactivated(rid, reactivated_slugs)
                        logger.info(f"Reseller {rid}: {len(reactivated_slugs)} servicios reactivados")
            
            except Exception as e:
                logger.error(f"Error verificando reactivación para reseller {rid}: {e}")
    
    except Exception as e:
        logger.error(f"Error en check_balance_reactivations: {e}")

async def scheduled_expiry_checker():
    """Wrapper para APScheduler: verifica expiración de planes y reactivaciones"""
    try:
        await check_expiring_plans()
        await check_balance_reactivations()
    except Exception as e:
        logger.error(f"Error en scheduled_expiry_checker: {e}")

@bot.on(events.NewMessage(pattern=r"^/start$"))
async def start_cmd(ev):
    uid = ev.sender_id
    
    if is_admin(uid):
        await ev.reply(
            "🔧 *Bot Manager - Panel de Administración*\n\n"
            "Bienvenido administrador. Usa el teclado para navegar.",
            parse_mode="Markdown"
        )
        await show_admin_main(ev)
        return
    
    if is_reseller(uid):
        username = get_username_display(uid)
        await ev.reply(
            f"🧑‍💼 *Panel de Reseller*\n\n"
            f"Bienvenido {username}. Usa el teclado para gestionar tus clientes.",
            parse_mode="Markdown"
        )
        await show_reseller_main(ev)
        return
    
    my = None
    for slug, c in S["clients"].items():
        if c.get("owner_id") == uid:
            my = (slug, c)
            break
    
    if my:
        slug, c = my
        exp = c.get("expires_at", "N/A")
        plan = c.get("plan", "N/A")
        svc = f"reenvio@{slug}.service"
        status = _svc_status(svc)
        status_emoji = "🟢" if status == "active" else "🔴"
        
        await ev.reply(
            f"👋 *Bienvenido*\n\n"
            f"🎫 Plan: `{plan}`\n"
            f"📅 Vence: `{exp}`\n"
            f"{status_emoji} Servicio: `{status}`\n"
            f"🔧 ID: `{slug}`\n\n"
            "Usa el teclado para acceder a tus opciones.",
            parse_mode="Markdown"
        )
        await show_client_main(ev)
    else:
        await ev.reply(
            "👋 Hola. Aún no estás autorizado.\n\n"
            "💬 Contacta a @frankosmel para solicitar tu trial de 7 días.",
            parse_mode="Markdown"
        )

@bot.on(events.NewMessage)
async def reply_keyboard_router(ev):
    if not ev.is_private:
        return
    
    txt = (ev.raw_text or "").strip()
    uid = ev.sender_id
    
    if txt == LBL_BACK:
        if is_admin(uid):
            return await show_admin_main(ev)
        elif is_reseller(uid):
            return await show_reseller_main(ev)
        else:
            return await show_client_main(ev)
    
    if is_admin(uid):
        if txt == "👥 Clientes":
            return await show_admin_clients(ev)
        if txt == "🤝 Resellers":
            return await show_admin_resellers(ev)
        if txt == "⚙️ Configuración":
            return await show_admin_config(ev)
        if txt == "🛠️ Mantenimiento":
            return await show_admin_maint(ev)
        if txt == "📊 Reportes":
            return await show_admin_reports(ev)
        if txt == "💰 Facturación":
            return await show_admin_billing(ev)
        if txt == "❓ Ayuda":
            return await help_cmd(ev)
        
        if txt == "➕ Autorizar cliente":
            return await auth_start(ev)
        if txt == "🔁 Renovar":
            return await renew_start(ev)
        if txt == "🗂 Cambiar plan":
            return await edit_plan_start(ev)
        if txt == "🚫 Revocar acceso":
            return await revoke_start(ev)
        if txt == "🖥 Estado/Servicio":
            return await clients_list(ev)
        
        if txt == "🗒 Listar resellers":
            return await resellers_list(ev)
        if txt == "👥 Ver clientes por reseller":
            return await view_reseller_clients_menu(ev)
        if txt == "➕ Agregar reseller":
            flows[uid] = {"action": "add_reseller"}
            await ev.reply(
                "👤 *Agregar Reseller*\n\n"
                "Envíame el @usuario del reseller o reenvía un mensaje suyo.",
                parse_mode="Markdown"
            )
            raise events.StopPropagation()
        if txt == "🗑️ Remover reseller":
            flows[uid] = {"action": "remove_reseller"}
            await ev.reply(
                "🗑️ *Remover Reseller*\n\n"
                "Envíame el @usuario del reseller a remover o reenvía un mensaje suyo.",
                parse_mode="Markdown"
            )
            raise events.StopPropagation()
        
        if txt == "👮 Admins":
            return await show_admin_admins(ev)
        if txt == "➕ Agregar admin":
            flows[uid] = {"action": "add_admin"}
            await ev.reply(
                "👤 *Agregar Admin*\n\n"
                "Envíame el @usuario del admin o reenvía un mensaje suyo.",
                parse_mode="Markdown"
            )
            raise events.StopPropagation()
        if txt == "🗑️ Remover admin":
            flows[uid] = {"action": "remove_admin"}
            await ev.reply(
                "🗑️ *Remover Admin*\n\n"
                "Envíame el @usuario del admin a remover o reenvía un mensaje suyo.",
                parse_mode="Markdown"
            )
            raise events.StopPropagation()
        if txt == "📋 Listar admins":
            return await admins_list(ev)
        
        if txt == "⏱ Notificaciones de vencimiento":
            S["notify_expiry"] = not S.get("notify_expiry", True)
            save_state(S)
            status = "✅ ON" if S["notify_expiry"] else "⏸️ OFF"
            return await ev.reply(f"⏱ *Notificaciones de vencimiento:* {status}", parse_mode="Markdown")
        
        if txt == "📦 Plantillas por plan":
            paths = "\n".join([f"• *{k}:* `{v}`" for k, v in TEMPL.items()])
            return await ev.reply(f"📦 *Rutas de plantillas:*\n\n{paths}", parse_mode="Markdown")
        
        if txt == "⬆️⬆️ Upgrade todos":
            return await cmd_upgrade_all(ev)
        if txt == "⬆️ Upgrade cliente":
            return await ev.reply("⬆️ Selecciona cliente para upgrade:", buttons=kb_clients_paginated("upgrade", for_user=uid))
        if txt == "🔄 Reiniciar servicio":
            return await ev.reply("🔄 Selecciona cliente para reiniciar:", buttons=kb_clients_paginated("svc_restart", for_user=uid))
        if txt == "🧹 Limpiar sesiones":
            return await ev.reply("🧹 Selecciona cliente para limpiar sesiones:", buttons=kb_clients_paginated("cleanup", for_user=uid))
        
        if txt == "🗓 Vencen hoy/mañana":
            today = dt.date.today().isoformat()
            tomorrow = (dt.date.today() + dt.timedelta(days=1)).isoformat()
            lines = ["📆 *Vencen hoy/mañana:*\n"]
            for slug, c in S.get("clients", {}).items():
                if c.get("expires_at") in (today, tomorrow):
                    lines.append(f"• `{slug}` → {c['expires_at']}")
            msg = "\n".join(lines) if len(lines) > 1 else "Sin vencimientos hoy/mañana."
            return await ev.reply(msg, parse_mode="Markdown")
        
        if txt == "🧮 Clientes por reseller":
            counts = {}
            for c in S.get("clients", {}).values():
                rid = c.get("reseller_id") or 0
                counts[rid] = counts.get(rid, 0) + 1
            lines = ["🧮 *Clientes por reseller:*\n"]
            for rid, n in sorted(counts.items(), key=lambda x: -x[1]):
                username = get_username_display(rid) if rid != 0 else "Sin reseller"
                lines.append(f"• {username}: *{n}*")
            return await ev.reply("\n".join(lines), parse_mode="Markdown")
        
        if txt == "🟢/🔴 Servicios activos/caídos":
            up, down = [], []
            for slug in S.get("clients", {}):
                st = _svc_status(f"reenvio@{slug}.service")
                (up if st == "active" else down).append(slug)
            msg = f"🟢 *Activos:* {', '.join(up) or '0'}\n🔴 *Caídos:* {', '.join(down) or '0'}"
            return await ev.reply(msg, parse_mode="Markdown")
        
        if txt == "🏷️ Lista de precios":
            # Mostrar lista de precios
            prices = S.get("prices", {})
            currency = S.get("currency", "USD")
            
            msg = (
                f"🏷️ *Lista de Precios del Sistema*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"📦 Plan Estándar: `{fmt_money(prices.get('plan_estandar', 4.0))} {currency}/30 días`\n"
                f"📦 Plan Plus: `{fmt_money(prices.get('plan_plus', 4.0))} {currency}/30 días`\n"
                f"📦 Plan Pro: `{fmt_money(prices.get('plan_pro', 4.0))} {currency}/30 días`\n"
                f"🎁 Plan Trial: `GRATIS`\n"
                f"━━━━━━━━━━━━━━━━\n\n"
                f"💡 Precio unitario por día: `{fmt_money(4.0/30)} {currency}`\n\n"
                f"_Todos los planes de pago tienen el mismo precio base._\n"
                f"_Las renovaciones se cobran proporcionalmente por día._"
            )
            
            return await ev.reply(msg, parse_mode="Markdown")
        
        if txt == "💼 Ver movimientos":
            # Ver movimientos recientes
            invoices = S.get("invoices", [])
            
            if not invoices:
                return await ev.reply("No hay movimientos registrados.", parse_mode="Markdown")
            
            currency = S.get("currency", "USD")
            recent = invoices[-15:] if len(invoices) > 15 else invoices
            
            msg = "💼 *Movimientos Recientes*\n\n━━━━━━━━━━━━━━━━\n"
            
            for inv in reversed(recent):
                inv_id = inv.get("id", "N/A")
                tipo = inv.get("type", "N/A")
                total = inv.get("total", 0)
                reseller_id = inv.get("reseller_id", 0)
                username = get_username_display(reseller_id) if reseller_id else "N/A"
                ts = inv.get("ts", "")[:10]
                
                tipo_emoji = {"renew": "🔄", "topup": "💳", "adjust": "⚖️"}.get(tipo, "📄")
                
                msg += f"{tipo_emoji} #{inv_id} · {ts}\n{username} · `{fmt_money(total)} {currency}`\n\n"
            
            return await ev.reply(msg, parse_mode="Markdown")
        
        if txt == "💳 Recargar saldo reseller":
            # Listar resellers con inline buttons para seleccionar
            resellers = S.get("resellers", [])
            
            if not resellers:
                return await ev.reply("No hay resellers registrados.", parse_mode="Markdown")
            
            kb = []
            for rid in resellers:
                username = get_username_display(rid)
                meta = get_reseller_meta(rid)
                balance = meta["balance"]
                kb.append([Button.inline(f"{username} (${fmt_money(balance)})", f"topup_select:{rid}".encode())])
            
            kb.append([Button.inline("❌ Cancelar", b"cancel_action")])
            
            return await ev.reply("💳 *Recargar Saldo a Reseller*\n\nSelecciona el reseller:", buttons=kb, parse_mode="Markdown")
        
        if txt == "⚖️ Ajuste manual":
            # Listar resellers con inline buttons para ajuste
            resellers = S.get("resellers", [])
            
            if not resellers:
                return await ev.reply("No hay resellers registrados.", parse_mode="Markdown")
            
            kb = []
            for rid in resellers:
                username = get_username_display(rid)
                meta = get_reseller_meta(rid)
                balance = meta["balance"]
                kb.append([Button.inline(f"{username} (${fmt_money(balance)})", f"adjust_select:{rid}".encode())])
            
            kb.append([Button.inline("❌ Cancelar", b"cancel_action")])
            
            return await ev.reply("⚖️ *Ajuste Manual de Saldo*\n\nSelecciona el reseller:", buttons=kb, parse_mode="Markdown")
        
        if txt == "📊 Reportes facturación":
            # Menú de reportes con inline buttons
            kb = [
                [Button.inline("📊 Consumo mensual", b"report_monthly")],
                [Button.inline("🔴 Clientes pausados", b"report_paused")],
                [Button.inline("💰 Balance de resellers", b"report_balances")],
                [Button.inline("❌ Cancelar", b"cancel_action")]
            ]
            
            return await ev.reply("📊 *Reportes del Sistema*\n\nSelecciona un reporte:", buttons=kb, parse_mode="Markdown")
        
        if txt == "✏️ Cambiar precios":
            # Menú inline para seleccionar qué plan cambiar
            kb = [
                [Button.inline("📦 Plan Estándar", b"change_price:plan_estandar")],
                [Button.inline("⭐ Plan Plus", b"change_price:plan_plus")],
                [Button.inline("👑 Plan Pro", b"change_price:plan_pro")],
                [Button.inline("❌ Cancelar", b"cancel_action")]
            ]
            
            prices = S.get("prices", {})
            currency = S.get("currency", "USD")
            
            msg = (
                f"✏️ *Cambiar Precios de Planes*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"📦 Estándar: `{fmt_money(prices.get('plan_estandar', 4.0))} {currency}`\n"
                f"⭐ Plus: `{fmt_money(prices.get('plan_plus', 4.0))} {currency}`\n"
                f"👑 Pro: `{fmt_money(prices.get('plan_pro', 4.0))} {currency}`\n"
                f"━━━━━━━━━━━━━━━━\n\n"
                f"💡 Selecciona el plan a modificar:"
            )
            
            return await ev.reply(msg, buttons=kb, parse_mode="Markdown")
        
        if txt == "💰 Cambiar límite crédito":
            # Listar resellers con inline buttons
            resellers = S.get("resellers", [])
            
            if not resellers:
                return await ev.reply("No hay resellers registrados.", parse_mode="Markdown")
            
            kb = []
            for rid in resellers:
                username = get_username_display(rid)
                meta = get_reseller_meta(rid)
                credit_limit = meta.get("credit_limit", 0)
                kb.append([Button.inline(f"{username} (límite: ${fmt_money(credit_limit)})", f"credit_limit_select:{rid}".encode())])
            
            kb.append([Button.inline("❌ Cancelar", b"cancel_action")])
            
            return await ev.reply("💰 *Cambiar Límite de Crédito*\n\nSelecciona el reseller:", buttons=kb, parse_mode="Markdown")
        
        if txt == "🎁 Descuentos reseller":
            # Listar resellers con sus descuentos actuales
            resellers = S.get("resellers", [])
            
            if not resellers:
                return await ev.reply("No hay resellers registrados.", parse_mode="Markdown")
            
            kb = []
            for rid in resellers:
                username = get_username_display(rid)
                meta = get_reseller_meta(rid)
                discount_text = ""
                discounts = meta.get("discount_pct", {})
                if discounts:
                    avg_discount = sum(discounts.values()) / len(discounts) if discounts else 0
                    discount_text = f" ({avg_discount:.0f}% desc.)"
                else:
                    discount_text = " (sin descuento)"
                
                kb.append([Button.inline(f"{username}{discount_text}", f"discount_select:{rid}".encode())])
            
            kb.append([Button.inline("❌ Cancelar", b"cancel_action")])
            
            return await ev.reply("🎁 *Descuentos por Reseller*\n\nSelecciona el reseller:", buttons=kb, parse_mode="Markdown")
    
    if is_reseller(uid) and not is_admin(uid):
        if txt == "👥 Mis clientes":
            return await clients_list(ev)
        if txt == "➕ Autorizar":
            return await auth_start(ev)
        if txt == "🔁 Renovar":
            return await renew_start(ev)
        if txt == "🗂 Cambiar plan":
            return await edit_plan_start(ev)
        if txt == "💼 Mi saldo":
            # Mostrar saldo del reseller con alertas y números claros
            meta = get_reseller_meta(uid)
            balance = meta["balance"]
            credit_limit = meta["credit_limit"]
            disponible = balance + credit_limit
            currency = S.get("currency", "USD")
            threshold_low = S["settings"].get("low_balance_threshold", 5.0)
            
            # Calcular estimaciones
            active_bots = get_active_bots_count(uid)
            daily_cost = active_bots * (4.0 / 30.0)
            suggested_topup = max(5.0, round(7 * daily_cost, 2))
            
            # Banner de alerta según estado
            alert_banner = ""
            if balance < -credit_limit:
                alert_banner = (
                    f"⛔ *CRÉDITO AGOTADO*\n"
                    f"Tu saldo está bajo el límite de crédito.\n"
                    f"Algunos servicios podrían estar pausados.\n\n"
                )
            elif balance < 0:
                alert_banner = (
                    f"ℹ️ *USANDO CRÉDITO*\n"
                    f"Tu saldo es negativo. Debes pagar y recargar.\n\n"
                )
            elif balance <= threshold_low:
                alert_banner = (
                    f"⚠️ *SALDO BAJO*\n"
                    f"Te recomendamos recargar `{fmt_money(suggested_topup)} {currency}` para ~7 días.\n\n"
                )
            
            # Obtener últimos movimientos
            my_invoices = [inv for inv in S.get("invoices", []) if inv.get("reseller_id") == uid]
            recent = my_invoices[-5:] if len(my_invoices) > 5 else my_invoices
            
            msg = (
                f"💼 *Tu Estado de Cuenta*\n\n"
                f"{alert_banner}"
                f"━━━━━━━━━━━━━━━━\n"
                f"💵 Saldo: `{fmt_money(balance)} {currency}`\n"
                f"💳 Crédito: `{fmt_money(credit_limit)} {currency}`\n"
                f"✅ Disponible: `{fmt_money(disponible)} {currency}`\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"🤖 Bots activos: `{active_bots}`\n"
                f"💰 Costo diario: `~{fmt_money(daily_cost)} {currency}`\n"
                f"━━━━━━━━━━━━━━━━\n\n"
            )
            
            if recent:
                msg += "📋 *Últimos 5 movimientos:*\n"
                for inv in reversed(recent):
                    tipo = inv.get("type", "")
                    total = inv.get("total", 0)
                    note = inv.get("note", "")[:30]
                    emoji = "➖" if tipo == "renew" else "➕" if tipo in ["topup", "adjust"] and total > 0 else "🔄"
                    msg += f"{emoji} `{fmt_money(total)} {currency}` — {note}\n"
            
            kb = [
                [Button.inline("📈 Estado de cuenta", b"res_statement")],
                [Button.inline("🧾 Mis facturas", b"reseller_invoices")],
                [Button.inline("💳 Pedir recarga", b"res_topup_help")],
                [Button.inline("🏷️ Ver precios", b"view_prices")],
                [Button.url("💬 Contactar @frankosmel", "https://t.me/frankosmel")]
            ]
            
            return await ev.reply(msg, buttons=kb, parse_mode="Markdown")
        if txt == "🚫 Revocar":
            return await revoke_start(ev)
        if txt == "❓ Ayuda":
            return await help_cmd(ev)
    
    for slug, c in S.get("clients", {}).items():
        if c.get("owner_id") == uid:
            if txt == "🚀 Provisionar":
                return await provision_start(ev)
            if txt == "📊 Status":
                return await status_cmd(ev)
            if txt == "🧑‍💻 Soporte":
                return await ev.reply("📞 *Soporte:* @frankosmel", parse_mode="Markdown")
            break

@bot.on(events.NewMessage(func=lambda e: e.is_private and e.forward))
async def handle_forwarded(ev):
    """Maneja mensajes reenviados para resolver usuario"""
    uid = ev.sender_id
    flow = flows.get(uid, {})
    action = flow.get("action")
    
    if not action:
        return
    
    forward = ev.forward
    from_id = None
    username = None
    
    if hasattr(forward, 'from_id'):
        if hasattr(forward.from_id, 'user_id'):
            from_id = forward.from_id.user_id
    
    if from_id:
        try:
            entity = await bot.get_entity(from_id)
            username = getattr(entity, "username", None)
        except:
            pass
        
        if action == "add_reseller":
            await handle_add_reseller(ev, from_id, username)
        elif action == "remove_reseller":
            await handle_remove_reseller(ev, from_id, username)
        elif action == "add_admin":
            await handle_add_admin(ev, from_id, username)
        elif action == "remove_admin":
            await handle_remove_admin(ev, from_id, username)
        
        flows.pop(uid, None)

@bot.on(events.NewMessage(func=lambda e: e.is_private and not e.forward and (e.raw_text or "").startswith("@")))
async def handle_username_input(ev):
    """Maneja entrada de @usuario"""
    uid = ev.sender_id
    flow = flows.get(uid, {})
    action = flow.get("action")
    
    if not action:
        return
    
    identifier = ev.raw_text.strip()
    user_id, username = await resolve_user_to_id(bot, identifier)
    
    if not user_id:
        return await ev.reply("❌ No se pudo resolver ese usuario. Intenta con @usuario o reenviando un mensaje.", parse_mode="Markdown")
    
    if action == "add_reseller":
        await handle_add_reseller(ev, user_id, username)
    elif action == "remove_reseller":
        await handle_remove_reseller(ev, user_id, username)
    elif action == "add_admin":
        await handle_add_admin(ev, user_id, username)
    elif action == "remove_admin":
        await handle_remove_admin(ev, user_id, username)
    
    flows.pop(uid, None)

async def handle_add_reseller(ev, user_id: int, username: Optional[str]):
    if user_id in S.get("resellers", []):
        return await ev.reply("⚠️ Ya es reseller.", parse_mode="Markdown")
    
    S.setdefault("resellers", []).append(user_id)
    if username:
        S.setdefault("usernames", {})[str(user_id)] = username
    save_state(S)
    
    display = f"@{username}" if username else f"ID:{user_id}"
    await ev.reply(f"✅ *Reseller agregado:* {display}", parse_mode="Markdown")

async def handle_remove_reseller(ev, user_id: int, username: Optional[str]):
    if user_id not in S.get("resellers", []):
        return await ev.reply("⚠️ No es reseller.", parse_mode="Markdown")
    
    S["resellers"].remove(user_id)
    save_state(S)
    
    display = f"@{username}" if username else f"ID:{user_id}"
    await ev.reply(f"✅ *Reseller removido:* {display}", parse_mode="Markdown")

async def handle_add_admin(ev, user_id: int, username: Optional[str]):
    if not is_owner(ev.sender_id):
        return await ev.reply("⛔ Solo el owner puede agregar admins.", parse_mode="Markdown")
    
    if user_id in S.get("admins", []) or user_id == S.get("owner_id"):
        return await ev.reply("⚠️ Ya es admin.", parse_mode="Markdown")
    
    S.setdefault("admins", []).append(user_id)
    if username:
        S.setdefault("usernames", {})[str(user_id)] = username
    save_state(S)
    
    display = f"@{username}" if username else f"ID:{user_id}"
    await ev.reply(f"✅ *Admin agregado:* {display}", parse_mode="Markdown")

async def handle_remove_admin(ev, user_id: int, username: Optional[str]):
    if not is_owner(ev.sender_id):
        return await ev.reply("⛔ Solo el owner puede remover admins.", parse_mode="Markdown")
    
    if user_id not in S.get("admins", []):
        return await ev.reply("⚠️ No es admin.", parse_mode="Markdown")
    
    S["admins"].remove(user_id)
    save_state(S)
    
    display = f"@{username}" if username else f"ID:{user_id}"
    await ev.reply(f"✅ *Admin removido:* {display}", parse_mode="Markdown")

async def billing_history(ev):
    """Muestra historial de pagos"""
    payments = S.get("payments", [])
    if not payments:
        return await ev.reply(
            "💳 *Historial de Pagos*\n\n"
            "No hay pagos registrados.",
            parse_mode="Markdown"
        )
    
    lines = ["💳 *Historial de Pagos*\n"]
    for p in payments[-15:]:
        date = p.get("date", "N/A")
        client = p.get("client", "N/A")
        amount = p.get("amount", 0)
        status = "✅" if p.get("paid") else "⏳"
        lines.append(f"{status} `{date}` - {client} - ${amount}")
    
    await ev.reply("\n".join(lines), parse_mode="Markdown")

async def billing_monthly_income(ev):
    """Ingresos del mes actual"""
    payments = S.get("payments", [])
    current_month = dt.date.today().strftime("%Y-%m")
    
    total = 0
    count = 0
    for p in payments:
        if p.get("date", "").startswith(current_month) and p.get("paid"):
            total += p.get("amount", 0)
            count += 1
    
    await ev.reply(
        f"📊 *Ingresos del Mes*\n\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"💰 Total: *${total}*\n"
        f"📦 Pagos: *{count}*\n"
        f"📅 Mes: `{current_month}`\n"
        f"━━━━━━━━━━━━━━━━",
        parse_mode="Markdown"
    )

async def billing_mark_paid(ev):
    """Marcar cliente como pagado"""
    uid = ev.sender_id
    await ev.reply(
        "✅ *Marcar como Pagado*\n\n"
        "Selecciona el cliente:",
        buttons=kb_clients_paginated("mark_paid", for_user=uid)
    )

async def billing_generate_invoice(ev):
    """Generar factura para cliente"""
    uid = ev.sender_id
    await ev.reply(
        "📝 *Generar Factura*\n\n"
        "Selecciona el cliente:",
        buttons=kb_clients_paginated("gen_invoice", for_user=uid)
    )

async def billing_pending_debts(ev):
    """Ver deudas pendientes"""
    clients = S.get("clients", {})
    lines = ["💰 *Deudas Pendientes*\n"]
    
    pending = []
    for slug, c in clients.items():
        payment_status = c.get("payment_status", "pending")
        if payment_status == "pending":
            plan = c.get("plan", "N/A")
            exp = c.get("expires_at", "N/A")
            pending.append(f"• `{slug}` - {plan} (vence: {exp})")
    
    if pending:
        lines.extend(pending)
    else:
        lines.append("✅ No hay deudas pendientes")
    
    await ev.reply("\n".join(lines), parse_mode="Markdown")

async def billing_stats(ev):
    """Estadísticas de facturación"""
    clients = S.get("clients", {})
    payments = S.get("payments", [])
    
    total_clients = len(clients)
    paid = sum(1 for c in clients.values() if c.get("payment_status") == "paid")
    pending = total_clients - paid
    
    monthly_revenue = sum(p.get("amount", 0) for p in payments 
                         if p.get("date", "").startswith(dt.date.today().strftime("%Y-%m")) 
                         and p.get("paid"))
    
    await ev.reply(
        f"📈 *Estadísticas de Facturación*\n\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"👥 Total clientes: *{total_clients}*\n"
        f"✅ Pagados: *{paid}*\n"
        f"⏳ Pendientes: *{pending}*\n"
        f"💰 Ingresos mes: *${monthly_revenue}*\n"
        f"━━━━━━━━━━━━━━━━",
        parse_mode="Markdown"
    )

async def view_reseller_clients_menu(ev):
    """Menú para ver clientes por reseller"""
    resellers = S.get("resellers", [])
    if not resellers:
        return await ev.reply("No hay resellers registrados.", parse_mode="Markdown")
    
    buttons = []
    for rid in resellers:
        username = get_username_display(rid)
        count = sum(1 for c in S.get("clients", {}).values() if c.get("reseller_id") == rid)
        buttons.append([Button.inline(f"{username} ({count} clientes)", f"view_r_clients:{rid}".encode())])
    
    buttons.append([Button.inline("❌ Cancelar", b"cancel")])
    
    await ev.reply(
        "👥 *Ver Clientes por Reseller*\n\n"
        "Selecciona un reseller:",
        buttons=buttons,
        parse_mode="Markdown"
    )

async def reseller_income(ev):
    """Ingresos del reseller"""
    uid = ev.sender_id
    my_clients = [c for c in S.get("clients", {}).values() if c.get("reseller_id") == uid]
    
    total_clients = len(my_clients)
    paid = sum(1 for c in my_clients if c.get("payment_status") == "paid")
    
    payments = S.get("payments", [])
    my_revenue = sum(
        p.get("amount", 0) * 0.3  # 30% comisión
        for p in payments
        if p.get("reseller_id") == uid and p.get("paid")
    )
    
    await ev.reply(
        f"💰 *Mis Ingresos*\n\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"👥 Mis clientes: *{total_clients}*\n"
        f"✅ Pagados: *{paid}*\n"
        f"💵 Comisiones: *${my_revenue:.2f}*\n"
        f"━━━━━━━━━━━━━━━━\n\n"
        f"_Comisión: 30% por cada pago_",
        parse_mode="Markdown"
    )

async def resellers_list(ev):
    resellers = S.get("resellers", [])
    if not resellers:
        return await ev.reply("📋 No hay resellers registrados.", parse_mode="Markdown")
    
    lines = ["📋 *Resellers Registrados:*\n"]
    for rid in resellers:
        username = get_username_display(rid)
        count = sum(1 for c in S.get("clients", {}).values() if c.get("reseller_id") == rid)
        lines.append(f"• {username} — *{count} clientes*")
        
        kb = [[Button.inline("👥 Ver clientes", f"reseller_clients:{rid}".encode())]]
        
    await ev.reply("\n".join(lines), parse_mode="Markdown")

async def admins_list(ev):
    owner_id = S.get("owner_id", 0)
    admins = S.get("admins", [])
    
    lines = ["👮 *Administradores del Sistema:*\n"]
    
    if owner_id:
        owner_username = get_username_display(owner_id)
        lines.append(f"👑 *Owner:* {owner_username}\n")
    
    if admins:
        lines.append("*Admins:*")
        for aid in admins:
            username = get_username_display(aid)
            lines.append(f"• {username}")
    else:
        lines.append("_Sin admins adicionales._")
    
    await ev.reply("\n".join(lines), parse_mode="Markdown")

async def help_cmd(ev):
    await ev.reply(
        "❓ *Ayuda*\n\n"
        "• *Reseller:* Autoriza, renueva, cambia plan y revoca desde el menú.\n"
        "• *Cliente:* usa 🚀 Provisionar para instalar tu bot y 📊 Status para ver estado.\n"
        "• *Soporte:* @frankosmel",
        parse_mode="Markdown"
    )

async def provision_start(ev):
    uid = ev.sender_id
    my_client = None
    for slug, c in S.get("clients", {}).items():
        if c.get("owner_id") == uid:
            my_client = (slug, c)
            break
    
    if not my_client:
        return await ev.reply("❌ No tienes un cliente asignado para provisionar.", parse_mode="Markdown")
    
    slug, client_info = my_client
    
    flows[uid] = {"action": "provision_wizard", "step": "ask_token", "slug": slug}
    
    await ev.reply(
        f"🚀 *Provisionar Bot*\n\n"
        f"🔧 Cliente: `{slug}`\n"
        f"📦 Plan: `{client_info.get('plan','N/A')}`\n\n"
        f"📝 Envíame el token de tu bot que obtuviste de @BotFather\n\n"
        f"_Ejemplo: 123456789:ABC-DEF1234ghIkl-zyx57W2v1u123ew11_",
        parse_mode="Markdown"
    )
    raise events.StopPropagation()

@bot.on(events.NewMessage(pattern=r"^/set_token\s+(\S+)\s+(\S+)$"))
async def set_token(ev):
    uid = ev.sender_id
    slug = ev.pattern_match.group(1)
    token = ev.pattern_match.group(2)
    
    c = S.get("clients", {}).get(slug)
    if not c:
        return await ev.reply("❌ Cliente no encontrado.", parse_mode="Markdown")
    
    if c.get("owner_id") != uid and not can_manage_client(uid, slug):
        return await ev.reply("❌ No autorizado.", parse_mode="Markdown")
    
    workdir = CLIENTS_DIR / slug
    try:
        clone_template(c.get("plan", "default"), workdir)
        write_env(workdir, bot_token=token, owner_id=c["owner_id"], slug=slug)
        ensure_venv_and_requirements(workdir)
        force_load_dotenv_override(workdir)
        enable_instance_service(slug)
        
        c["workdir"] = str(workdir)
        c["provisioned"] = True
        c["provisioned_at"] = dt.datetime.now().isoformat(timespec="seconds")
        save_state(S)
        
        await ev.reply(
            f"✅ *Bot provisionado y servicio habilitado.*\n📁 `{workdir}`",
            parse_mode="Markdown"
        )
    except Exception as e:
        logger.error(f"Provision error {slug}: {e}")
        await ev.reply(f"❌ Error provisionando: {str(e)[:120]}", parse_mode="Markdown")

async def status_cmd(ev):
    uid = ev.sender_id
    
    for slug, c in S.get("clients", {}).items():
        if c.get("owner_id") == uid:
            svc = _svc_status(f"reenvio@{slug}.service")
            emoji = "🟢" if svc == "active" else "🔴"
            
            workdir = Path(c.get("workdir", ""))
            env = _read_env(workdir)
            token = env.get("BOT_TOKEN", "")
            bot_username = "N/A"
            
            if token:
                try:
                    meta = _get_bot_meta(token)
                    if meta.get("username"):
                        bot_username = meta["username"]
                except:
                    pass
            
            if is_admin(uid) or is_reseller(uid):
                btns = [
                    [Button.inline("🔄 Reiniciar", f"svc_restart:{slug}".encode()),
                     Button.inline("🧹 Limpiar", f"cleanup:{slug}".encode())],
                    [Button.inline("🔁 Renovar", f"renew_inline:{slug}".encode()),
                     Button.inline("🗂 Plan", f"editplan_pick:{slug}".encode())],
                    [Button.inline("🚫 Revocar", f"revoke:{slug}".encode())]
                ]
            else:
                btns = [
                    [Button.inline("🔄 Reiniciar", f"svc_restart:{slug}".encode()),
                     Button.inline("🧹 Limpiar", f"cleanup:{slug}".encode())],
                    [Button.url("💬 Contactar Soporte", "https://t.me/frankosmel")]
                ]
            
            return await ev.reply(
                f"📊 *Status de {slug}*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"🎫 *Plan:* `{c.get('plan','N/A')}`\n"
                f"📅 *Vence:* `{c.get('expires_at','N/A')}`\n"
                f"🤖 *Bot:* @{bot_username}\n"
                f"{emoji} *Servicio:* `{svc}`\n"
                f"━━━━━━━━━━━━━━━━",
                buttons=btns,
                parse_mode="Markdown"
            )
    
    if is_admin(uid) or is_reseller(uid):
        return await ev.reply("📊 Selecciona cliente:", buttons=kb_clients_paginated("status", for_user=uid))
    
    return await ev.reply("❌ No tienes servicio asignado.", parse_mode="Markdown")

async def auth_start(ev):
    uid = ev.sender_id
    flows[uid] = {"action": "auth_wizard", "step": "ask_user"}
    await ev.reply(
        "➕ *Autorizar Cliente*\n\n"
        "Envíame el @usuario del cliente o reenvía un mensaje suyo.",
        parse_mode="Markdown"
    )
    raise events.StopPropagation()

async def renew_start(ev):
    uid = ev.sender_id
    await ev.reply("🔁 *Renovar* — Selecciona cliente:", buttons=kb_clients_paginated("renew_pick", for_user=uid))

async def edit_plan_start(ev):
    uid = ev.sender_id
    await ev.reply("🗂 *Cambiar Plan* — Selecciona cliente:", buttons=kb_clients_paginated("editplan_pick", for_user=uid))

async def revoke_start(ev):
    uid = ev.sender_id
    await ev.reply("🚫 *Revocar* — Selecciona cliente:", buttons=kb_clients_paginated("revoke", for_user=uid))

async def clients_list(ev):
    uid = ev.sender_id
    await ev.reply("🖥 *Clientes* — Selecciona para ver estado:", buttons=kb_clients_paginated("status", for_user=uid))

async def cmd_upgrade_all(ev):
    count = 0
    for slug in S.get("clients", {}):
        try:
            _upgrade_client(slug)
            count += 1
        except Exception as e:
            logger.error(f"Error upgrading {slug}: {e}")
    
    await ev.reply(f"✅ Upgrade completado en *{count}* clientes.", parse_mode="Markdown")

def _upgrade_client(slug: str) -> str:
    """Actualiza dependencias de un cliente"""
    c = S.get("clients", {}).get(slug)
    if not c:
        return f"❌ Cliente {slug} no encontrado"
    
    workdir = Path(c.get("workdir", ""))
    if not workdir.exists():
        return f"❌ Workdir no existe para {slug}"
    
    try:
        ensure_venv_and_requirements(workdir)
        return f"✅ Upgrade completado para {slug}"
    except Exception as e:
        return f"❌ Error en {slug}: {str(e)[:80]}"

@bot.on(events.CallbackQuery)
async def inline_handler(ev):
    data = (ev.data or b"").decode(errors="ignore")
    uid = ev.sender_id
    
    if data.startswith("upgrade:"):
        parts = data.split(":")
        slug = parts[1]
        if not can_manage_client(uid, slug):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        res = _upgrade_client(slug)
        try:
            await ev.edit(res, parse_mode="Markdown")
        except:
            await ev.respond(res, parse_mode="Markdown")
        return
    
    if data.startswith("svc_restart:"):
        slug = data.split(":", 1)[1]
        if not can_manage_client(uid, slug):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        try:
            resume_instance_service(slug)
            st = _svc_status(f"reenvio@{slug}.service")
            await ev.answer(f"🔄 Servicio reiniciado → {st}", alert=True)
        except Exception as e:
            await ev.answer(f"❌ Error: {str(e)[:60]}", alert=True)
        return
    
    if data.startswith("cleanup:"):
        slug = data.split(":", 1)[1]
        if not can_manage_client(uid, slug):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        info = S.get("clients", {}).get(slug, {})
        wdir = Path(info.get("workdir", ""))
        removed = 0
        
        try:
            if wdir.exists():
                for p in wdir.glob("*.session*"):
                    try:
                        p.unlink()
                        removed += 1
                    except:
                        pass
            
            pause_instance_service(slug)
            resume_instance_service(slug)
            await ev.answer(f"🧹 {removed} sesiones eliminadas. Servicio reiniciado.", alert=True)
        except Exception as e:
            await ev.answer(f"❌ Error: {str(e)[:60]}", alert=True)
        return
    
    if data.startswith("status:"):
        parts = data.split(":")
        slug = parts[1]
        
        client = S.get("clients", {}).get(slug)
        if not client:
            return await ev.answer("❌ Cliente no encontrado", alert=True)
        
        is_client_owner = client.get("owner_id") == uid
        is_manager = is_admin(uid) or (is_reseller(uid) and client.get("reseller_id") == uid)
        
        if not (is_client_owner or is_manager):
            return await ev.answer("❌ No autorizado", alert=True)
        
        svc = _svc_status(f"reenvio@{slug}.service")
        emoji = "🟢" if svc == "active" else "🔴"
        
        workdir = Path(client.get("workdir", ""))
        env = _read_env(workdir)
        token = env.get("BOT_TOKEN", "")
        bot_username = "N/A"
        
        if token:
            try:
                meta = _get_bot_meta(token)
                if meta.get("username"):
                    bot_username = meta["username"]
            except:
                pass
        
        if is_manager:
            btns = [
                [Button.inline("🔄 Reiniciar", f"svc_restart:{slug}".encode()),
                 Button.inline("🧹 Limpiar", f"cleanup:{slug}".encode())],
                [Button.inline("🔁 Renovar", f"renew_inline:{slug}".encode()),
                 Button.inline("🗂 Plan", f"editplan_pick:{slug}".encode())],
                [Button.inline("🚫 Revocar", f"revoke:{slug}".encode())]
            ]
        else:
            btns = [[Button.url("💬 Contactar soporte", "https://t.me/frankosmel")]]
        
        try:
            await ev.edit(
                f"📊 *Status de {slug}*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"🎫 *Plan:* `{client.get('plan','N/A')}`\n"
                f"📅 *Vence:* `{client.get('expires_at','N/A')}`\n"
                f"🤖 *Bot:* @{bot_username}\n"
                f"{emoji} *Servicio:* `{svc}`\n"
                f"━━━━━━━━━━━━━━━━",
                buttons=btns,
                parse_mode="Markdown"
            )
        except:
            await ev.respond(
                f"📊 *Status de {slug}*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"🎫 *Plan:* `{client.get('plan','N/A')}`\n"
                f"📅 *Vence:* `{client.get('expires_at','N/A')}`\n"
                f"🤖 *Bot:* @{bot_username}\n"
                f"{emoji} *Servicio:* `{svc}`\n"
                f"━━━━━━━━━━━━━━━━",
                buttons=btns,
                parse_mode="Markdown"
            )
        return
    
    if ":nav:p" in data:
        parts = data.split(":")
        prefix = parts[0]
        page = int(parts[2][1:])
        
        try:
            await ev.edit(f"Página {page + 1}", buttons=kb_clients_paginated(prefix, for_user=uid, page=page))
        except:
            await ev.respond(f"Página {page + 1}", buttons=kb_clients_paginated(prefix, for_user=uid, page=page))
        return
    
    if data.endswith(":cancel") or data == "cancel":
        try:
            await ev.edit("❌ Cancelado")
        except:
            await ev.respond("❌ Cancelado")
        flows.pop(uid, None)
        return
    
    if data.startswith("editplan_pick:"):
        parts = data.split(":")
        slug = parts[1]
        
        if not can_manage_client(uid, slug):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        kb = [
            [Button.inline("🎁 Trial", f"setplan:{slug}:plan_trial".encode())],
            [Button.inline("📦 Estándar", f"setplan:{slug}:plan_estandar".encode()),
             Button.inline("⭐ Plus", f"setplan:{slug}:plan_plus".encode())],
            [Button.inline("👑 Pro", f"setplan:{slug}:plan_pro".encode())],
            [Button.inline("❌ Cancelar", b"setplan:cancel")],
        ]
        
        try:
            await ev.edit(f"🗂 *Cambiar plan de* `{slug}`", buttons=kb, parse_mode="Markdown")
        except:
            await ev.respond(f"🗂 *Cambiar plan de* `{slug}`", buttons=kb, parse_mode="Markdown")
        return
    
    if data.startswith("setplan:"):
        parts = data.split(":")
        if len(parts) < 3:
            return
        
        slug, plan = parts[1], parts[2]
        
        if plan == "cancel":
            return await ev.edit("❌ Cancelado")
        
        if not can_manage_client(uid, slug):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        if slug not in S.get("clients", {}):
            return await ev.answer("❌ Cliente no encontrado", alert=True)
        
        old = S["clients"][slug].get("plan", "N/A")
        S["clients"][slug]["plan"] = plan
        save_state(S)
        
        try:
            await ev.edit(f"✅ Plan actualizado `{slug}`:\n`{old}` → *{plan}*", parse_mode="Markdown")
        except:
            await ev.respond(f"✅ Plan actualizado `{slug}`:\n`{old}` → *{plan}*", parse_mode="Markdown")
        return
    
    if data.startswith("revoke:"):
        slug = data.split(":", 1)[1]
        
        if slug == "cancel":
            return await ev.edit("❌ Cancelado")
        
        if not can_manage_client(uid, slug):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        kb = [
            [Button.inline("⚠️ SÍ, REVOCAR", f"revoke_exec:{slug}".encode())],
            [Button.inline("❌ Cancelar", b"revoke:cancel")]
        ]
        
        try:
            await ev.edit(
                f"🚫 *Confirmar revocación de* `{slug}`\n\n"
                f"Esta acción eliminará archivos, deshabilitará servicio y removerá el cliente.",
                buttons=kb,
                parse_mode="Markdown"
            )
        except:
            await ev.respond(
                f"🚫 *Confirmar revocación de* `{slug}`\n\n"
                f"Esta acción eliminará archivos, deshabilitará servicio y removerá el cliente.",
                buttons=kb,
                parse_mode="Markdown"
            )
        return
    
    if data.startswith("revoke_exec:"):
        slug = data.split(":", 1)[1]
        
        if not can_manage_client(uid, slug):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        c = S.get("clients", {}).get(slug)
        if not c:
            return await ev.answer("❌ Cliente no encontrado", alert=True)
        
        try:
            disable_instance_service(slug)
            wdir = Path(c.get("workdir", ""))
            if wdir.exists():
                shutil.rmtree(wdir)
            
            del S["clients"][slug]
            save_state(S)
            
            await ev.edit(f"✅ Cliente `{slug}` revocado completamente.", parse_mode="Markdown")
        except Exception as e:
            await ev.edit(f"❌ Error revocando: {str(e)[:100]}", parse_mode="Markdown")
        return
    
    if data.startswith("renew_pick:"):
        parts = data.split(":")
        slug = parts[1]
        
        if not can_manage_client(uid, slug):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        kb = [
            [Button.inline("7 días", f"renew_duration:{slug}:7".encode()),
             Button.inline("30 días", f"renew_duration:{slug}:30".encode())],
            [Button.inline("90 días", f"renew_duration:{slug}:90".encode()),
             Button.inline("365 días", f"renew_duration:{slug}:365".encode())],
            [Button.inline("❌ Cancelar", b"renew:cancel")]
        ]
        
        try:
            await ev.edit(f"🔁 *Renovar* `{slug}` — Elige duración:", buttons=kb, parse_mode="Markdown")
        except:
            await ev.respond(f"🔁 *Renovar* `{slug}` — Elige duración:", buttons=kb, parse_mode="Markdown")
        return
    
    if data.startswith("renew_inline:"):
        slug = data.split(":", 1)[1]
        
        if not can_manage_client(uid, slug):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        kb = [
            [Button.inline("7 días", f"renew_duration:{slug}:7".encode()),
             Button.inline("30 días", f"renew_duration:{slug}:30".encode())],
            [Button.inline("90 días", f"renew_duration:{slug}:90".encode()),
             Button.inline("365 días", f"renew_duration:{slug}:365".encode())],
            [Button.inline("❌ Cancelar", b"renew:cancel")]
        ]
        
        try:
            await ev.edit(f"🔁 *Renovar* `{slug}` — Elige duración:", buttons=kb, parse_mode="Markdown")
        except:
            await ev.respond(f"🔁 *Renovar* `{slug}` — Elige duración:", buttons=kb, parse_mode="Markdown")
        return
    
    if data.startswith("renew_duration:"):
        # NUEVO FLUJO: Muestra resumen con costos antes de confirmar
        parts = data.split(":")
        slug = parts[1]
        days = int(parts[2])
        
        if not can_manage_client(uid, slug):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        c = S.get("clients", {}).get(slug)
        if not c:
            return await ev.answer("❌ Cliente no encontrado", alert=True)
        
        plan = c.get("plan", "plan_estandar")
        reseller_id = c.get("reseller_id") if is_reseller(uid) and not is_admin(uid) else None
        
        # Calcular costos
        unit_day, discount_pct, total = calc_total(plan, days, reseller_id)
        
        # Si es trial, no hay cobro
        if plan == "plan_trial":
            # Calcular nueva fecha y renovar directamente (sin cobro)
            current_exp = c.get("expires_at")
            if current_exp:
                try:
                    exp_date = dt.date.fromisoformat(current_exp)
                    new_exp = exp_date + dt.timedelta(days=days) if exp_date > dt.date.today() else dt.date.today() + dt.timedelta(days=days)
                except:
                    new_exp = dt.date.today() + dt.timedelta(days=days)
            else:
                new_exp = dt.date.today() + dt.timedelta(days=days)
            
            c["expires_at"] = new_exp.isoformat()
            save_state(S)
            
            # Reactivar servicio si está pausado
            svc = f"reenvio@{slug}.service"
            if _svc_status(svc) != "active":
                try:
                    resume_instance_service(slug)
                except:
                    pass
            
            try:
                await ev.edit(
                    f"✅ *Trial renovado (sin cargo)*\n\n"
                    f"━━━━━━━━━━━━━━━━\n"
                    f"🎫 Cliente: `{slug}`\n"
                    f"📅 Días: {days}\n"
                    f"📆 Vence: `{new_exp.isoformat()}`\n"
                    f"━━━━━━━━━━━━━━━━",
                    parse_mode="Markdown"
                )
            except:
                await ev.respond(
                    f"✅ *Trial renovado (sin cargo)*\n\n"
                    f"━━━━━━━━━━━━━━━━\n"
                    f"🎫 Cliente: `{slug}`\n"
                    f"📅 Días: {days}\n"
                    f"📆 Vence: `{new_exp.isoformat()}`\n"
                    f"━━━━━━━━━━━━━━━━",
                    parse_mode="Markdown"
                )
            return
        
        # Para planes de pago, mostrar resumen y pedir confirmación
        if reseller_id:
            meta = get_reseller_meta(reseller_id)
            balance = meta["balance"]
            credit_limit = meta["credit_limit"]
            disponible = balance + credit_limit
            
            plan_name = {
                "plan_estandar": "Estándar",
                "plan_plus": "Plus",
                "plan_pro": "Pro"
            }.get(plan, plan)
            
            currency = S.get("currency", "USD")
            
            resumen = (
                f"📋 *Resumen de Renovación*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"🎫 Plan: *{plan_name}*\n"
                f"📅 Días: *{days}*\n"
                f"💵 Precio/día: `{fmt_money(unit_day)} {currency}`\n"
                f"🏷️ Descuento: `{discount_pct}%`\n"
                f"💰 *TOTAL: {fmt_money(total)} {currency}*\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"💼 Saldo: `{fmt_money(balance)} {currency}`\n"
                f"💳 Crédito: `{fmt_money(credit_limit)} {currency}`\n"
                f"✅ Disponible: `{fmt_money(disponible)} {currency}`\n"
                f"━━━━━━━━━━━━━━━━\n\n"
            )
            
            # Verificar si tiene saldo suficiente
            if disponible >= total:
                resumen += "¿Confirmar renovación y cobrar del saldo?"
                kb = [
                    [Button.inline("✅ Confirmar y cobrar", f"renew_confirm:{slug}:{days}".encode())],
                    [Button.inline("❌ Cancelar", b"renew:cancel")]
                ]
            else:
                falta = total - disponible
                resumen += f"⛔ *Saldo insuficiente*\nFalta: `{fmt_money(falta)} {currency}`"
                kb = [
                    [Button.inline("💼 Ver mi saldo", b"reseller_balance".encode())],
                    [Button.inline("💳 Pedir recarga", b"request_topup".encode())],
                    [Button.inline("❌ Cancelar", b"renew:cancel")]
                ]
            
            try:
                await ev.edit(resumen, buttons=kb, parse_mode="Markdown")
            except:
                await ev.respond(resumen, buttons=kb, parse_mode="Markdown")
            return
        else:
            # Admin o sin reseller: renovar directamente sin cobro
            current_exp = c.get("expires_at")
            if current_exp:
                try:
                    exp_date = dt.date.fromisoformat(current_exp)
                    new_exp = exp_date + dt.timedelta(days=days) if exp_date > dt.date.today() else dt.date.today() + dt.timedelta(days=days)
                except:
                    new_exp = dt.date.today() + dt.timedelta(days=days)
            else:
                new_exp = dt.date.today() + dt.timedelta(days=days)
            
            c["expires_at"] = new_exp.isoformat()
            save_state(S)
            
            svc = f"reenvio@{slug}.service"
            if _svc_status(svc) != "active":
                try:
                    resume_instance_service(slug)
                except:
                    pass
            
            try:
                await ev.edit(
                    f"✅ Cliente `{slug}` renovado por *{days} días*.\n"
                    f"📅 Nueva fecha: `{new_exp.isoformat()}`",
                    parse_mode="Markdown"
                )
            except:
                await ev.respond(
                    f"✅ Cliente `{slug}` renovado por *{days} días*.\n"
                    f"📅 Nueva fecha: `{new_exp.isoformat()}`",
                    parse_mode="Markdown"
                )
            return
    
    if data.startswith("renew_confirm:"):
        # CONFIRMACIÓN: Cobra y renueva
        parts = data.split(":")
        slug = parts[1]
        days = int(parts[2])
        
        if not can_manage_client(uid, slug):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        c = S.get("clients", {}).get(slug)
        if not c:
            return await ev.answer("❌ Cliente no encontrado", alert=True)
        
        plan = c.get("plan", "plan_estandar")
        reseller_id = c.get("reseller_id") if is_reseller(uid) and not is_admin(uid) else None
        
        if not reseller_id:
            return await ev.answer("⛔ Sin reseller asignado", alert=True)
        
        # Calcular costos
        unit_day, discount_pct, total = calc_total(plan, days, reseller_id)
        
        # Revalidar saldo
        if not has_balance(reseller_id, total):
            meta = get_reseller_meta(reseller_id)
            disponible = meta["balance"] + meta["credit_limit"]
            falta = total - disponible
            return await ev.answer(f"⛔ Saldo insuficiente. Falta: {fmt_money(falta)} USD", alert=True)
        
        # Debitar saldo y crear invoice
        invoice = debit_reseller(
            reseller_id, 
            total, 
            f"Renovación {slug} por {days} días",
            client_slug=slug,
            plan=plan,
            days=days
        )
        
        # Calcular nueva fecha de expiración
        current_exp = c.get("expires_at")
        if current_exp:
            try:
                exp_date = dt.date.fromisoformat(current_exp)
                new_exp = exp_date + dt.timedelta(days=days) if exp_date > dt.date.today() else dt.date.today() + dt.timedelta(days=days)
            except:
                new_exp = dt.date.today() + dt.timedelta(days=days)
        else:
            new_exp = dt.date.today() + dt.timedelta(days=days)
        
        c["expires_at"] = new_exp.isoformat()
        save_state(S)
        
        # Reactivar servicio si está pausado
        svc = f"reenvio@{slug}.service"
        if _svc_status(svc) != "active":
            try:
                resume_instance_service(slug)
            except:
                pass
        
        # Obtener nuevo balance
        meta = get_reseller_meta(reseller_id)
        new_balance = meta["balance"]
        currency = S.get("currency", "USD")
        
        # Notificar al reseller
        try:
            await ev.edit(
                f"✅ *Renovación Exitosa*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"🎫 Cliente: `{slug}`\n"
                f"📅 Días: {days}\n"
                f"📆 Vence: `{new_exp.isoformat()}`\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"💰 Cobrado: `{fmt_money(total)} {currency}`\n"
                f"💼 Nuevo saldo: `{fmt_money(new_balance)} {currency}`\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"📄 Invoice #`{invoice['id']}`",
                parse_mode="Markdown"
            )
        except:
            await ev.respond(
                f"✅ *Renovación Exitosa*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"🎫 Cliente: `{slug}`\n"
                f"📅 Días: {days}\n"
                f"📆 Vence: `{new_exp.isoformat()}`\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"💰 Cobrado: `{fmt_money(total)} {currency}`\n"
                f"💼 Nuevo saldo: `{fmt_money(new_balance)} {currency}`\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"📄 Invoice #`{invoice['id']}`",
                parse_mode="Markdown"
            )
        
        # Notificar al cliente
        owner_id = c.get("owner_id")
        if owner_id:
            try:
                await bot.send_message(
                    owner_id,
                    f"🔁 *Renovación Exitosa*\n\n"
                    f"━━━━━━━━━━━━━━━━\n"
                    f"🎫 Tu servicio ha sido renovado\n"
                    f"📅 Días: {days}\n"
                    f"📆 Vence: `{new_exp.isoformat()}`\n"
                    f"🟢 Servicio: Activo\n"
                    f"━━━━━━━━━━━━━━━━",
                    parse_mode="Markdown"
                )
            except Exception as e:
                logger.error(f"Error notificando cliente {owner_id}: {e}")
        
        return
    
    if data.startswith("reseller_clients:"):
        reseller_id = int(data.split(":")[1])
        
        if not is_admin(uid):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        clients = [slug for slug, c in S.get("clients", {}).items() if c.get("reseller_id") == reseller_id]
        
        if not clients:
            return await ev.answer("Este reseller no tiene clientes asignados", alert=True)
        
        lines = [f"👥 *Clientes del reseller* {get_username_display(reseller_id)}:\n"]
        for slug in clients:
            c = S["clients"][slug]
            exp = c.get("expires_at", "N/A")
            plan = c.get("plan", "N/A")
            lines.append(f"• `{slug}` — {plan} (vence: {exp})")
        
        try:
            await ev.edit("\n".join(lines), parse_mode="Markdown")
        except:
            await ev.respond("\n".join(lines), parse_mode="Markdown")
        return
    
    if data.startswith("view_r_clients:"):
        reseller_id = int(data.split(":")[1])
        
        if not is_admin(uid):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        clients = [slug for slug, c in S.get("clients", {}).items() if c.get("reseller_id") == reseller_id]
        
        if not clients:
            return await ev.answer("Este reseller no tiene clientes asignados", alert=True)
        
        lines = [f"👥 *Clientes de* {get_username_display(reseller_id)}\n"]
        for slug in clients:
            c = S["clients"][slug]
            exp = c.get("expires_at", "N/A")
            plan = c.get("plan", "N/A")
            status = c.get("payment_status", "pending")
            emoji = "✅" if status == "paid" else "⏳"
            lines.append(f"{emoji} `{slug}` — {plan} (vence: {exp})")
        
        try:
            await ev.edit("\n".join(lines), parse_mode="Markdown")
        except:
            await ev.respond("\n".join(lines), parse_mode="Markdown")
        return
    
    if data.startswith("mark_paid:"):
        parts = data.split(":")
        slug = parts[1]
        
        if not can_manage_client(uid, slug):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        client = S.get("clients", {}).get(slug)
        if client:
            client["payment_status"] = "paid"
            
            payments = S.get("payments", [])
            payments.append({
                "date": dt.date.today().isoformat(),
                "client": slug,
                "amount": 30,  # Precio ejemplo
                "paid": True,
                "reseller_id": client.get("reseller_id")
            })
            S["payments"] = payments
            save_state(S)
            
            await ev.answer(f"✅ {slug} marcado como pagado", alert=True)
        return
    
    if data.startswith("gen_invoice:"):
        parts = data.split(":")
        slug = parts[1]
        
        if not can_manage_client(uid, slug):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        client = S.get("clients", {}).get(slug)
        if client:
            plan = client.get("plan", "N/A")
            exp = client.get("expires_at", "N/A")
            
            invoice = (
                f"📝 *FACTURA - {slug}*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"📅 Fecha: {dt.date.today().isoformat()}\n"
                f"🎫 Plan: {plan}\n"
                f"📆 Vence: {exp}\n"
                f"💰 Monto: $30\n"
                f"━━━━━━━━━━━━━━━━\n\n"
                f"Gracias por su preferencia."
            )
            
            try:
                await ev.edit(invoice, parse_mode="Markdown")
            except:
                await ev.respond(invoice, parse_mode="Markdown")
        return
    
    if data == "reseller_balance":
        # Mostrar saldo del reseller
        if not is_reseller(uid):
            return await ev.answer("⛔ No eres reseller", alert=True)
        
        meta = get_reseller_meta(uid)
        balance = meta["balance"]
        credit_limit = meta["credit_limit"]
        disponible = balance + credit_limit
        currency = S.get("currency", "USD")
        
        # Obtener últimos movimientos (invoices)
        my_invoices = [inv for inv in S.get("invoices", []) if inv.get("reseller_id") == uid]
        recent = my_invoices[-5:] if len(my_invoices) > 5 else my_invoices
        
        msg = (
            f"💼 *Tu Estado de Cuenta*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"💵 Saldo actual: `{fmt_money(balance)} {currency}`\n"
            f"💳 Crédito disponible: `{fmt_money(credit_limit)} {currency}`\n"
            f"✅ Total disponible: `{fmt_money(disponible)} {currency}`\n"
            f"━━━━━━━━━━━━━━━━\n\n"
        )
        
        if recent:
            msg += "📋 *Últimos movimientos:*\n"
            for inv in reversed(recent):
                tipo = inv.get("type", "")
                total = inv.get("total", 0)
                note = inv.get("note", "")[:30]
                emoji = "➖" if tipo == "renew" else "➕" if tipo in ["topup", "adjust"] and total > 0 else "🔄"
                msg += f"{emoji} `{fmt_money(total)} {currency}` — {note}\n"
        
        kb = [
            [Button.inline("💳 Pedir recarga", b"request_topup")],
            [Button.inline("🔙 Volver", b"back_to_menu")]
        ]
        
        try:
            await ev.edit(msg, buttons=kb, parse_mode="Markdown")
        except:
            await ev.respond(msg, buttons=kb, parse_mode="Markdown")
        return
    
    if data == "request_topup":
        # Instrucciones para pedir recarga
        if not is_reseller(uid):
            return await ev.answer("⛔ No eres reseller", alert=True)
        
        meta = get_reseller_meta(uid)
        balance = meta["balance"]
        currency = S.get("currency", "USD")
        
        msg = (
            f"💳 *Solicitar Recarga de Saldo*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"💼 Tu saldo actual: `{fmt_money(balance)} {currency}`\n"
            f"━━━━━━━━━━━━━━━━\n\n"
            f"📝 *Instrucciones:*\n\n"
            f"1️⃣ Realiza tu pago por el método acordado\n"
            f"2️⃣ Envía el comprobante al administrador\n"
            f"3️⃣ Espera la confirmación de tu recarga\n\n"
            f"El administrador será notificado de tu solicitud.\n\n"
            f"💡 *Tip:* Incluye tu username y el monto en el mensaje."
        )
        
        kb = [
            [Button.inline("✅ Entendido", b"back_to_menu")]
        ]
        
        # Notificar a los admins
        admin_ids = [S.get("owner_id")] + S.get("admins", [])
        username_display = get_username_display(uid)
        
        for admin_id in admin_ids:
            if admin_id:
                try:
                    await bot.send_message(
                        admin_id,
                        f"💳 *Solicitud de Recarga*\n\n"
                        f"━━━━━━━━━━━━━━━━\n"
                        f"👤 Reseller: {username_display}\n"
                        f"💼 Saldo actual: `{fmt_money(balance)} {currency}`\n"
                        f"━━━━━━━━━━━━━━━━\n\n"
                        f"El reseller necesita una recarga de saldo.",
                        parse_mode="Markdown"
                    )
                except Exception as e:
                    logger.error(f"Error notificando admin {admin_id}: {e}")
        
        try:
            await ev.edit(msg, buttons=kb, parse_mode="Markdown")
        except:
            await ev.respond(msg, buttons=kb, parse_mode="Markdown")
        return
    
    if data == "res_balance":
        # Mostrar saldo actualizado con alertas
        if not is_reseller(uid):
            return await ev.answer("⛔ No eres reseller", alert=True)
        
        meta = get_reseller_meta(uid)
        balance = meta["balance"]
        credit_limit = meta["credit_limit"]
        disponible = balance + credit_limit
        currency = S.get("currency", "USD")
        threshold_low = S["settings"].get("low_balance_threshold", 5.0)
        
        # Calcular estimaciones
        active_bots = get_active_bots_count(uid)
        daily_cost = active_bots * (4.0 / 30.0)
        suggested_topup = max(5.0, round(7 * daily_cost, 2))
        
        # Banner de alerta según estado
        alert_banner = ""
        if balance < -credit_limit:
            alert_banner = (
                f"⛔ *CRÉDITO AGOTADO*\n"
                f"Tu saldo está bajo el límite de crédito.\n"
                f"Algunos servicios podrían estar pausados.\n\n"
            )
        elif balance < 0:
            alert_banner = (
                f"ℹ️ *USANDO CRÉDITO*\n"
                f"Tu saldo es negativo. Debes pagar y recargar.\n\n"
            )
        elif balance <= threshold_low:
            alert_banner = (
                f"⚠️ *SALDO BAJO*\n"
                f"Te recomendamos recargar `{fmt_money(suggested_topup)} {currency}` para ~7 días.\n\n"
            )
        
        # Obtener últimos movimientos
        my_invoices = [inv for inv in S.get("invoices", []) if inv.get("reseller_id") == uid]
        recent = my_invoices[-5:] if len(my_invoices) > 5 else my_invoices
        
        msg = (
            f"💼 *Tu Estado de Cuenta*\n\n"
            f"{alert_banner}"
            f"━━━━━━━━━━━━━━━━\n"
            f"💵 Saldo: `{fmt_money(balance)} {currency}`\n"
            f"💳 Crédito: `{fmt_money(credit_limit)} {currency}`\n"
            f"✅ Disponible: `{fmt_money(disponible)} {currency}`\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"🤖 Bots activos: `{active_bots}`\n"
            f"💰 Costo diario: `~{fmt_money(daily_cost)} {currency}`\n"
            f"━━━━━━━━━━━━━━━━\n\n"
        )
        
        if recent:
            msg += "📋 *Últimos 5 movimientos:*\n"
            for inv in reversed(recent):
                tipo = inv.get("type", "")
                total = inv.get("total", 0)
                note = inv.get("note", "")[:30]
                emoji = "➖" if tipo == "renew" else "➕" if tipo in ["topup", "adjust"] and total > 0 else "🔄"
                msg += f"{emoji} `{fmt_money(total)} {currency}` — {note}\n"
        
        kb = [
            [Button.inline("📈 Estado completo", b"res_statement")],
            [Button.inline("💳 Pedir recarga", b"res_topup_help")]
        ]
        
        try:
            await ev.edit(msg, buttons=kb, parse_mode="Markdown")
        except:
            await ev.respond(msg, buttons=kb, parse_mode="Markdown")
        return
    
    if data == "res_statement":
        # Estado de cuenta detallado (todos los movimientos)
        if not is_reseller(uid):
            return await ev.answer("⛔ No eres reseller", alert=True)
        
        my_invoices = [inv for inv in S.get("invoices", []) if inv.get("reseller_id") == uid]
        
        if not my_invoices:
            return await ev.answer("No tienes movimientos registrados", alert=True)
        
        currency = S.get("currency", "USD")
        msg = "📈 *Estado de Cuenta Completo*\n\n━━━━━━━━━━━━━━━━\n"
        
        # Mostrar últimos 15 movimientos
        recent = my_invoices[-15:] if len(my_invoices) > 15 else my_invoices
        
        for inv in reversed(recent):
            inv_id = inv.get("id", "N/A")
            tipo = inv.get("type", "")
            total = inv.get("total", 0)
            note = inv.get("note", "")[:35]
            ts = inv.get("ts", "")[:10]
            
            tipo_emoji = {
                "renew": "🔄",
                "topup": "💳",
                "adjust": "⚖️"
            }.get(tipo, "📄")
            
            msg += f"{tipo_emoji} #{inv_id} · {ts}\n`{fmt_money(total)} {currency}` — {note}\n\n"
        
        msg += f"━━━━━━━━━━━━━━━━\n_Mostrando últimos {len(recent)} movimientos_"
        
        try:
            await ev.edit(msg, parse_mode="Markdown")
        except:
            await ev.respond(msg, parse_mode="Markdown")
        return
    
    if data == "res_topup_help":
        # Instrucciones mejoradas para pedir recarga
        if not is_reseller(uid):
            return await ev.answer("⛔ No eres reseller", alert=True)
        
        meta = get_reseller_meta(uid)
        balance = meta["balance"]
        credit_limit = meta["credit_limit"]
        currency = S.get("currency", "USD")
        
        active_bots = get_active_bots_count(uid)
        daily_cost = active_bots * (4.0 / 30.0)
        suggested_topup = max(5.0, round(7 * daily_cost, 2))
        
        msg = (
            f"💳 *Solicitar Recarga de Saldo*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"💵 Saldo actual: `{fmt_money(balance)} {currency}`\n"
            f"💳 Crédito: `{fmt_money(credit_limit)} {currency}`\n"
            f"💡 Sugerido: `{fmt_money(suggested_topup)} {currency}` (~7 días)\n"
            f"━━━━━━━━━━━━━━━━\n\n"
            f"📝 *Instrucciones:*\n\n"
            f"1️⃣ Realiza tu pago por el método acordado\n"
            f"2️⃣ Envía el comprobante al administrador\n"
            f"3️⃣ Incluye tu @username y monto en el mensaje\n"
            f"4️⃣ Espera la confirmación de tu recarga\n\n"
            f"El administrador será notificado de tu solicitud."
        )
        
        kb = [
            [Button.url("💬 Contactar @frankosmel", "https://t.me/frankosmel")]
        ]
        
        # Notificar a los admins
        admin_ids = [S.get("owner_id")] + S.get("admins", [])
        username_display = get_username_display(uid)
        
        for admin_id in admin_ids:
            if admin_id:
                try:
                    await bot.send_message(
                        admin_id,
                        f"💳 *Solicitud de Recarga*\n\n"
                        f"━━━━━━━━━━━━━━━━\n"
                        f"👤 Reseller: {username_display}\n"
                        f"💼 Saldo: `{fmt_money(balance)} {currency}`\n"
                        f"💡 Sugerido: `{fmt_money(suggested_topup)} {currency}`\n"
                        f"🤖 Bots activos: {active_bots}\n"
                        f"━━━━━━━━━━━━━━━━\n\n"
                        f"El reseller necesita una recarga de saldo.",
                        parse_mode="Markdown"
                    )
                except Exception as e:
                    logger.error(f"Error notificando admin {admin_id}: {e}")
        
        try:
            await ev.edit(msg, buttons=kb, parse_mode="Markdown")
        except:
            await ev.respond(msg, buttons=kb, parse_mode="Markdown")
        return
    
    if data == "reseller_invoices":
        # Mostrar facturas del reseller
        if not is_reseller(uid):
            return await ev.answer("⛔ No eres reseller", alert=True)
        
        my_invoices = [inv for inv in S.get("invoices", []) if inv.get("reseller_id") == uid and inv.get("type") == "renew"]
        
        if not my_invoices:
            return await ev.answer("No tienes facturas registradas", alert=True)
        
        currency = S.get("currency", "USD")
        msg = "🧾 *Tus Facturas de Renovación*\n\n━━━━━━━━━━━━━━━━\n"
        
        for inv in reversed(my_invoices[-10:]):  # Últimas 10
            inv_id = inv.get("id", "N/A")
            client_slug = inv.get("client_slug", "N/A")
            days = inv.get("days", 0)
            total = inv.get("total", 0)
            ts = inv.get("ts", "")[:10]  # Solo fecha
            msg += f"Invoice #{inv_id}\n📅 {ts} · 🎫 {client_slug}\n💰 {fmt_money(total)} {currency} ({days}d)\n\n"
        
        kb = [[Button.inline("🔙 Volver", b"back_to_menu")]]
        
        try:
            await ev.edit(msg, buttons=kb, parse_mode="Markdown")
        except:
            await ev.respond(msg, buttons=kb, parse_mode="Markdown")
        return
    
    if data == "view_prices":
        # Mostrar lista de precios
        prices = S.get("prices", {})
        currency = S.get("currency", "USD")
        
        msg = (
            f"🏷️ *Lista de Precios*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"📦 Plan Estándar: `{fmt_money(prices.get('plan_estandar', 4.0))} {currency}/30d`\n"
            f"📦 Plan Plus: `{fmt_money(prices.get('plan_plus', 4.0))} {currency}/30d`\n"
            f"📦 Plan Pro: `{fmt_money(prices.get('plan_pro', 4.0))} {currency}/30d`\n"
            f"🎁 Plan Trial: `GRATIS`\n"
            f"━━━━━━━━━━━━━━━━\n\n"
            f"💡 Precio por día: `{fmt_money(4.0/30)} {currency}`\n\n"
            f"_Renovaciones se cobran proporcionalmente por día._"
        )
        
        kb = [[Button.inline("🔙 Volver", b"back_to_menu")]]
        
        try:
            await ev.edit(msg, buttons=kb, parse_mode="Markdown")
        except:
            await ev.respond(msg, buttons=kb, parse_mode="Markdown")
        return
    
    if data.startswith("topup_select:"):
        # Admin: seleccionó reseller, pedir monto
        if not is_admin(uid):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        reseller_id = int(data.split(":")[1])
        flows[uid] = {"action": "admin_topup", "reseller_id": reseller_id, "step": "amount"}
        
        username = get_username_display(reseller_id)
        meta = get_reseller_meta(reseller_id)
        currency = S.get("currency", "USD")
        
        msg = (
            f"💳 *Recargar Saldo*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"👤 Reseller: {username}\n"
            f"💼 Saldo actual: `{fmt_money(meta['balance'])} {currency}`\n"
            f"━━━━━━━━━━━━━━━━\n\n"
            f"📝 Envía el monto a recargar (solo número, ej: 50 o 100.50)"
        )
        
        try:
            await ev.edit(msg, parse_mode="Markdown")
        except:
            await ev.respond(msg, parse_mode="Markdown")
        return
    
    if data.startswith("adjust_select:"):
        # Admin: seleccionó reseller para ajuste, pedir monto
        if not is_admin(uid):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        reseller_id = int(data.split(":")[1])
        flows[uid] = {"action": "admin_adjust", "reseller_id": reseller_id, "step": "amount"}
        
        username = get_username_display(reseller_id)
        meta = get_reseller_meta(reseller_id)
        currency = S.get("currency", "USD")
        
        msg = (
            f"⚖️ *Ajuste Manual de Saldo*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"👤 Reseller: {username}\n"
            f"💼 Saldo actual: `{fmt_money(meta['balance'])} {currency}`\n"
            f"━━━━━━━━━━━━━━━━\n\n"
            f"📝 Envía el ajuste:\n"
            f"• Positivo para sumar: `50` o `+50`\n"
            f"• Negativo para restar: `-30`\n\n"
            f"_Luego te pediré una nota explicativa._"
        )
        
        try:
            await ev.edit(msg, parse_mode="Markdown")
        except:
            await ev.respond(msg, parse_mode="Markdown")
        return
    
    if data == "report_monthly":
        # Reporte: consumo mensual por reseller
        if not is_admin(uid):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        invoices = [inv for inv in S.get("invoices", []) if inv.get("type") == "renew"]
        current_month = dt.datetime.now().strftime("%Y-%m")
        
        # Agrupar por reseller
        by_reseller = {}
        for inv in invoices:
            if inv.get("ts", "").startswith(current_month):
                rid = inv.get("reseller_id", 0)
                by_reseller[rid] = by_reseller.get(rid, 0) + inv.get("total", 0)
        
        currency = S.get("currency", "USD")
        msg = f"📉 *Consumo del Mes* ({current_month})\n\n━━━━━━━━━━━━━━━━\n"
        
        if by_reseller:
            for rid, total in sorted(by_reseller.items(), key=lambda x: -x[1]):
                username = get_username_display(rid) if rid else "Sin reseller"
                msg += f"{username}: `{fmt_money(total)} {currency}`\n"
        else:
            msg += "Sin movimientos este mes."
        
        try:
            await ev.edit(msg, parse_mode="Markdown")
        except:
            await ev.respond(msg, parse_mode="Markdown")
        return
    
    if data == "report_paused":
        # Reporte: clientes pausados
        if not is_admin(uid):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        paused = []
        for slug, c in S.get("clients", {}).items():
            svc = f"reenvio@{slug}.service"
            if _svc_status(svc) != "active":
                paused.append(slug)
        
        msg = f"🔴 *Clientes Pausados*\n\n━━━━━━━━━━━━━━━━\n"
        
        if paused:
            for slug in paused:
                c = S["clients"][slug]
                exp = c.get("expires_at", "N/A")
                msg += f"• `{slug}` (vence: {exp})\n"
        else:
            msg += "✅ Todos los servicios están activos."
        
        try:
            await ev.edit(msg, parse_mode="Markdown")
        except:
            await ev.respond(msg, parse_mode="Markdown")
        return
    
    if data == "report_balances":
        # Reporte: balance de todos los resellers
        if not is_admin(uid):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        resellers = S.get("resellers", [])
        currency = S.get("currency", "USD")
        
        msg = f"💰 *Balance de Resellers*\n\n━━━━━━━━━━━━━━━━\n"
        
        if resellers:
            for rid in resellers:
                username = get_username_display(rid)
                meta = get_reseller_meta(rid)
                balance = meta["balance"]
                credit = meta["credit_limit"]
                disponible = balance + credit
                msg += f"{username}:\n💼 `{fmt_money(balance)} {currency}` · ✅ `{fmt_money(disponible)} {currency}`\n\n"
        else:
            msg += "No hay resellers registrados."
        
        try:
            await ev.edit(msg, parse_mode="Markdown")
        except:
            await ev.respond(msg, parse_mode="Markdown")
        return
    
    if data.startswith("change_price:"):
        # Admin: cambiar precio de un plan
        if not is_admin(uid):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        plan_name = data.split(":")[1]
        flows[uid] = {"action": "change_price", "plan": plan_name, "step": "amount"}
        
        prices = S.get("prices", {})
        currency = S.get("currency", "USD")
        current_price = prices.get(plan_name, 4.0)
        
        plan_display = {
            "plan_estandar": "📦 Plan Estándar",
            "plan_plus": "⭐ Plan Plus",
            "plan_pro": "👑 Plan Pro"
        }.get(plan_name, plan_name)
        
        msg = (
            f"✏️ *Cambiar Precio*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"{plan_display}\n"
            f"💵 Precio actual: `{fmt_money(current_price)} {currency}/30 días`\n"
            f"━━━━━━━━━━━━━━━━\n\n"
            f"📝 Envía el nuevo precio (solo número, ej: 5.50 o 10)"
        )
        
        try:
            await ev.edit(msg, parse_mode="Markdown")
        except:
            await ev.respond(msg, parse_mode="Markdown")
        return
    
    if data.startswith("credit_limit_select:"):
        # Admin: cambiar límite de crédito de reseller
        if not is_admin(uid):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        reseller_id = int(data.split(":")[1])
        flows[uid] = {"action": "change_credit_limit", "reseller_id": reseller_id, "step": "amount"}
        
        username = get_username_display(reseller_id)
        meta = get_reseller_meta(reseller_id)
        current_limit = meta.get("credit_limit", 0)
        currency = S.get("currency", "USD")
        
        msg = (
            f"💰 *Cambiar Límite de Crédito*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"👤 Reseller: {username}\n"
            f"💳 Límite actual: `{fmt_money(current_limit)} {currency}`\n"
            f"━━━━━━━━━━━━━━━━\n\n"
            f"📝 Envía el nuevo límite de crédito (solo número, ej: 50 o 100)"
        )
        
        try:
            await ev.edit(msg, parse_mode="Markdown")
        except:
            await ev.respond(msg, parse_mode="Markdown")
        return
    
    if data.startswith("discount_select:"):
        # Admin: cambiar descuentos de reseller
        if not is_admin(uid):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        reseller_id = int(data.split(":")[1])
        
        # Mostrar menú de planes para seleccionar cuál configurar
        kb = [
            [Button.inline("📦 Plan Estándar", f"discount_plan:{reseller_id}:plan_estandar".encode())],
            [Button.inline("⭐ Plan Plus", f"discount_plan:{reseller_id}:plan_plus".encode())],
            [Button.inline("👑 Plan Pro", f"discount_plan:{reseller_id}:plan_pro".encode())],
            [Button.inline("🔄 Aplicar a todos", f"discount_all:{reseller_id}".encode())],
            [Button.inline("❌ Cancelar", b"cancel_action")]
        ]
        
        username = get_username_display(reseller_id)
        meta = get_reseller_meta(reseller_id)
        discounts = meta.get("discount_pct", {})
        
        msg = f"🎁 *Descuentos para* {username}\n\n━━━━━━━━━━━━━━━━\n"
        
        if discounts:
            for plan, pct in discounts.items():
                plan_name = plan.replace("plan_", "").capitalize()
                msg += f"{plan_name}: `{pct}%`\n"
        else:
            msg += "_Sin descuentos configurados_\n"
        
        msg += "━━━━━━━━━━━━━━━━\n\n💡 Selecciona plan a configurar:"
        
        try:
            await ev.edit(msg, buttons=kb, parse_mode="Markdown")
        except:
            await ev.respond(msg, buttons=kb, parse_mode="Markdown")
        return
    
    if data.startswith("discount_plan:"):
        # Admin: seleccionó plan específico para descuento
        if not is_admin(uid):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        parts = data.split(":")
        reseller_id = int(parts[1])
        plan_name = parts[2]
        
        flows[uid] = {"action": "set_discount", "reseller_id": reseller_id, "plan": plan_name, "step": "percent"}
        
        username = get_username_display(reseller_id)
        meta = get_reseller_meta(reseller_id)
        current_discount = meta.get("discount_pct", {}).get(plan_name, 0)
        
        plan_display = {
            "plan_estandar": "📦 Plan Estándar",
            "plan_plus": "⭐ Plan Plus",
            "plan_pro": "👑 Plan Pro"
        }.get(plan_name, plan_name)
        
        msg = (
            f"🎁 *Configurar Descuento*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"👤 Reseller: {username}\n"
            f"{plan_display}\n"
            f"💸 Descuento actual: `{current_discount}%`\n"
            f"━━━━━━━━━━━━━━━━\n\n"
            f"📝 Envía el porcentaje de descuento (0-100, ej: 10 para 10%)"
        )
        
        try:
            await ev.edit(msg, parse_mode="Markdown")
        except:
            await ev.respond(msg, parse_mode="Markdown")
        return
    
    if data.startswith("discount_all:"):
        # Admin: aplicar mismo descuento a todos los planes
        if not is_admin(uid):
            return await ev.answer("⛔ Sin permisos", alert=True)
        
        reseller_id = int(data.split(":")[1])
        flows[uid] = {"action": "set_discount_all", "reseller_id": reseller_id, "step": "percent"}
        
        username = get_username_display(reseller_id)
        
        msg = (
            f"🎁 *Descuento General*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"👤 Reseller: {username}\n"
            f"━━━━━━━━━━━━━━━━\n\n"
            f"📝 Envía el porcentaje de descuento para TODOS los planes\n"
            f"(0-100, ej: 15 para 15%)"
        )
        
        try:
            await ev.edit(msg, parse_mode="Markdown")
        except:
            await ev.respond(msg, parse_mode="Markdown")
        return
    
    if data == "cancel_action":
        # Cancelar y cerrar mensaje inline
        try:
            await ev.delete()
        except:
            try:
                await ev.edit("❌ Cancelado")
            except:
                await ev.answer("❌ Cancelado", alert=True)
        return
    
    if data == "back_to_menu":
        # Volver al menú principal
        try:
            await ev.delete()
        except:
            pass
        
        if is_admin(uid):
            await ev.respond("📊 *Menú Principal*", buttons=rk(ADMIN_MAIN), parse_mode="Markdown")
        elif is_reseller(uid):
            await ev.respond("📊 *Menú Reseller*", buttons=rk(RESELLER_MAIN), parse_mode="Markdown")
        else:
            await ev.respond("Usa /start para ver el menú.")
        return

@bot.on(events.NewMessage(func=lambda e: e.is_private and flows.get(e.sender_id, {}).get("action") == "auth_wizard"))
async def auth_wizard_handler(ev):
    uid = ev.sender_id
    flow = flows.get(uid, {})
    step = flow.get("step")
    
    if step == "ask_user":
        target_id = None
        target_username = None
        
        if ev.forward:
            forward = ev.forward
            from_id = None
            
            if hasattr(forward, 'from_id'):
                if hasattr(forward.from_id, 'user_id'):
                    from_id = forward.from_id.user_id
            
            if not from_id:
                return await ev.reply("❌ No se pudo obtener el ID del usuario.", parse_mode="Markdown")
            
            try:
                entity = await bot.get_entity(from_id)
                target_username = getattr(entity, "username", None)
            except:
                target_username = None
            
            target_id = from_id
        
        elif ev.raw_text:
            identifier = ev.raw_text.strip()
            user_id, username = await resolve_user_to_id(bot, identifier)
            
            if not user_id:
                return await ev.reply("❌ No se pudo resolver ese usuario. Envía @usuario, ID numérico o reenvía un mensaje.", parse_mode="Markdown")
            
            target_id = user_id
            target_username = username
        
        if target_id:
            flows[uid] = {**flow, "target_id": target_id, "target_username": target_username, "step": "ask_plan"}
            
            kb = [
                [Button.inline("🎁 Trial", f"auth_plan:plan_trial".encode())],
                [Button.inline("📦 Estándar", f"auth_plan:plan_estandar".encode()),
                 Button.inline("⭐ Plus", f"auth_plan:plan_plus".encode())],
                [Button.inline("👑 Pro", f"auth_plan:plan_pro".encode())],
                [Button.inline("❌ Cancelar", b"auth:cancel")],
            ]
            
            display = f"@{target_username}" if target_username else f"ID:{target_id}"
            return await ev.reply(
                f"👤 Usuario: {display}\n\n🗂 *Elige plan:*",
                buttons=kb,
                parse_mode="Markdown"
            )

@bot.on(events.CallbackQuery(pattern=rb"^auth_plan:"))
async def auth_plan_handler(ev):
    uid = ev.sender_id
    flow = flows.get(uid, {})
    
    if flow.get("action") != "auth_wizard":
        return
    
    data = ev.data.decode()
    plan = data.split(":")[1]
    
    flows[uid] = {**flow, "plan": plan, "step": "ask_duration"}
    
    kb = [
        [Button.inline("7 días", f"auth_duration:7".encode()),
         Button.inline("30 días", f"auth_duration:30".encode())],
        [Button.inline("90 días", f"auth_duration:90".encode()),
         Button.inline("365 días", f"auth_duration:365".encode())],
        [Button.inline("❌ Cancelar", b"auth:cancel")]
    ]
    
    try:
        await ev.edit(f"📅 *Duración* para {plan}:", buttons=kb, parse_mode="Markdown")
    except:
        await ev.respond(f"📅 *Duración* para {plan}:", buttons=kb, parse_mode="Markdown")

@bot.on(events.CallbackQuery(pattern=rb"^auth_duration:"))
async def auth_duration_handler(ev):
    uid = ev.sender_id
    flow = flows.get(uid, {})
    
    if flow.get("action") != "auth_wizard":
        return
    
    data = ev.data.decode()
    days = int(data.split(":")[1])
    
    target_id = flow.get("target_id")
    target_username = flow.get("target_username")
    plan = flow.get("plan")
    
    if not target_id or not plan:
        return await ev.answer("❌ Datos incompletos", alert=True)
    
    try:
        entity = await bot.get_entity(target_id)
        slug = uniq_slug(slugify_from_user(entity))
    except:
        slug = uniq_slug(f"tenant{target_id}")
    
    expires_at = (dt.date.today() + dt.timedelta(days=days)).isoformat()
    
    reseller_id = uid if is_reseller(uid) and not is_admin(uid) else None
    
    S.setdefault("clients", {})[slug] = {
        "owner_id": target_id,
        "plan": plan,
        "expires_at": expires_at,
        "created_at": dt.datetime.now().isoformat(timespec="seconds"),
        "reseller_id": reseller_id,
        "provisioned": False
    }
    
    if target_username:
        S.setdefault("usernames", {})[str(target_id)] = target_username
    
    save_state(S)
    flows.pop(uid, None)
    
    display = f"@{target_username}" if target_username else f"ID:{target_id}"
    
    try:
        await ev.edit(
            f"✅ *Cliente autorizado*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"👤 Usuario: {display}\n"
            f"🔧 ID: `{slug}`\n"
            f"🎫 Plan: *{plan}*\n"
            f"📅 Vence: `{expires_at}`\n"
            f"━━━━━━━━━━━━━━━━",
            parse_mode="Markdown"
        )
    except:
        await ev.respond(
            f"✅ *Cliente autorizado*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"👤 Usuario: {display}\n"
            f"🔧 ID: `{slug}`\n"
            f"🎫 Plan: *{plan}*\n"
            f"📅 Vence: `{expires_at}`\n"
            f"━━━━━━━━━━━━━━━━",
            parse_mode="Markdown"
        )
    
    try:
        await bot.send_message(
            target_id,
            f"🎉 *Has sido autorizado*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"🎫 Plan: *{plan}*\n"
            f"📅 Vence: `{expires_at}`\n"
            f"━━━━━━━━━━━━━━━━\n\n"
            f"Usa /start para comenzar.",
            parse_mode="Markdown"
        )
    except Exception as e:
        logger.error(f"Error notificando a {target_id}: {e}")

@bot.on(events.CallbackQuery(pattern=rb"^auth:cancel$"))
async def auth_cancel_handler(ev):
    flows.pop(ev.sender_id, None)
    try:
        await ev.edit("❌ Cancelado")
    except:
        await ev.respond("❌ Cancelado")

@bot.on(events.CallbackQuery(pattern=rb"^renew:cancel$"))
async def renew_cancel_handler(ev):
    try:
        await ev.edit("❌ Cancelado")
    except:
        await ev.respond("❌ Cancelado")

@bot.on(events.NewMessage(func=lambda e: e.is_private and flows.get(e.sender_id, {}).get("action") == "admin_topup"))
async def admin_topup_wizard(ev):
    uid = ev.sender_id
    flow = flows.get(uid, {})
    step = flow.get("step")
    
    if step == "amount":
        # Validar monto
        try:
            amount = float(ev.text.strip().replace("+", "").replace("$", "").replace(",", ""))
            if amount <= 0:
                return await ev.reply("❌ El monto debe ser mayor a 0. Inténtalo de nuevo:")
        except:
            return await ev.reply("❌ Formato inválido. Envía solo el número (ej: 50 o 100.50):")
        
        # Guardar monto y pedir método
        flows[uid]["amount"] = amount
        flows[uid]["step"] = "method"
        
        return await ev.reply(
            f"💳 *Monto: {fmt_money(amount)} USD*\n\n"
            f"📝 Ahora envía el método de pago (ej: transferencia, efectivo, PayPal, etc.):",
            parse_mode="Markdown"
        )
    
    elif step == "method":
        method = ev.text.strip()[:50]
        
        # Completar recarga
        reseller_id = flow.get("reseller_id")
        amount = flow.get("amount")
        
        invoice = topup_reseller(reseller_id, amount, method, f"Recarga admin")
        meta = get_reseller_meta(reseller_id)
        username = get_username_display(reseller_id)
        currency = S.get("currency", "USD")
        
        # Auto-reactivar servicios si había pausados por balance
        reactivated_slugs = []
        if meta["balance"] >= 0 and meta.get("exhausted_seen"):
            for slug, c in S.get("clients", {}).items():
                if c.get("reseller_id") == reseller_id and c.get("provisioned"):
                    svc = f"reenvio@{slug}.service"
                    status = _svc_status(svc)
                    
                    if status != "active":
                        try:
                            resume_instance_service(slug)
                            if _svc_status(svc) == "active":
                                reactivated_slugs.append(slug)
                                logger.info(f"Servicio {svc} reactivado tras topup de reseller {reseller_id}")
                        except Exception as e:
                            logger.error(f"Error reactivando {svc}: {e}")
            
            if reactivated_slugs:
                # Resetear exhausted_seen
                meta["exhausted_seen"] = False
                S["resellers_meta"][str(reseller_id)] = meta
                save_state(S)
                
                # Notificar reactivación
                await notify_service_reactivated(reseller_id, reactivated_slugs)
        
        # Limpiar flow
        flows.pop(uid, None)
        
        # Notificar admin
        reactivated_info = ""
        if reactivated_slugs:
            reactivated_info = f"\n🟢 Servicios reactivados: `{len(reactivated_slugs)}`\n"
        
        await ev.reply(
            f"✅ *Recarga Completada*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"👤 Reseller: {username}\n"
            f"💰 Monto: `{fmt_money(amount)} {currency}`\n"
            f"💳 Método: {method}\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"💼 Nuevo saldo: `{fmt_money(meta['balance'])} {currency}`\n"
            f"{reactivated_info}"
            f"📄 Invoice #`{invoice['id']}`",
            parse_mode="Markdown"
        )
        
        # Notificar al reseller
        try:
            await bot.send_message(
                reseller_id,
                f"💳 *Recarga Aplicada*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"💰 Monto: `+{fmt_money(amount)} {currency}`\n"
                f"💳 Método: {method}\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"💼 Nuevo saldo: `{fmt_money(meta['balance'])} {currency}`\n\n"
                f"Gracias por tu pago.",
                parse_mode="Markdown"
            )
        except Exception as e:
            logger.error(f"Error notificando reseller {reseller_id}: {e}")

@bot.on(events.NewMessage(func=lambda e: e.is_private and flows.get(e.sender_id, {}).get("action") == "admin_adjust"))
async def admin_adjust_wizard(ev):
    uid = ev.sender_id
    flow = flows.get(uid, {})
    step = flow.get("step")
    
    if step == "amount":
        # Validar monto (puede ser positivo o negativo)
        try:
            amount = float(ev.text.strip().replace("$", "").replace(",", ""))
        except:
            return await ev.reply("❌ Formato inválido. Envía el ajuste (ej: 50, +50, o -30):")
        
        # Guardar monto y pedir nota
        flows[uid]["amount"] = amount
        flows[uid]["step"] = "note"
        
        tipo = "sumar" if amount >= 0 else "restar"
        return await ev.reply(
            f"⚖️ *Ajuste: {'+' if amount >= 0 else ''}{fmt_money(amount)} USD*\n\n"
            f"Se va a {tipo} este monto al saldo.\n\n"
            f"📝 Envía una nota explicativa (máx 100 caracteres):",
            parse_mode="Markdown"
        )
    
    elif step == "note":
        note = ev.text.strip()[:100]
        
        # Completar ajuste
        reseller_id = flow.get("reseller_id")
        amount = flow.get("amount")
        
        invoice = adjust_reseller(reseller_id, amount, note)
        meta = get_reseller_meta(reseller_id)
        username = get_username_display(reseller_id)
        currency = S.get("currency", "USD")
        
        # Limpiar flow
        flows.pop(uid, None)
        
        # Notificar admin
        await ev.reply(
            f"✅ *Ajuste Completado*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"👤 Reseller: {username}\n"
            f"💰 Ajuste: `{'+' if amount >= 0 else ''}{fmt_money(amount)} {currency}`\n"
            f"📝 Nota: {note}\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"💼 Nuevo saldo: `{fmt_money(meta['balance'])} {currency}`\n"
            f"📄 Invoice #`{invoice['id']}`",
            parse_mode="Markdown"
        )
        
        # Notificar al reseller
        try:
            await bot.send_message(
                reseller_id,
                f"⚖️ *Ajuste de Saldo*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"💰 Ajuste: `{'+' if amount >= 0 else ''}{fmt_money(amount)} {currency}`\n"
                f"📝 Motivo: {note}\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"💼 Nuevo saldo: `{fmt_money(meta['balance'])} {currency}`",
                parse_mode="Markdown"
            )
        except Exception as e:
            logger.error(f"Error notificando reseller {reseller_id}: {e}")

@bot.on(events.NewMessage(func=lambda e: e.is_private and flows.get(e.sender_id, {}).get("action") == "change_price"))
async def change_price_wizard(ev):
    uid = ev.sender_id
    flow = flows.get(uid, {})
    step = flow.get("step")
    
    if step == "amount":
        # Validar precio
        try:
            new_price = float(ev.text.strip().replace("$", "").replace(",", ""))
            if new_price <= 0:
                return await ev.reply("❌ El precio debe ser mayor a 0. Inténtalo de nuevo:")
        except:
            return await ev.reply("❌ Formato inválido. Envía solo el número (ej: 5.50 o 10):")
        
        # Actualizar precio
        plan_name = flow.get("plan")
        old_price = S.get("prices", {}).get(plan_name, 4.0)
        
        if "prices" not in S:
            S["prices"] = {}
        
        S["prices"][plan_name] = new_price
        save_state(S)
        
        # Limpiar flow
        flows.pop(uid, None)
        
        currency = S.get("currency", "USD")
        plan_display = {
            "plan_estandar": "📦 Plan Estándar",
            "plan_plus": "⭐ Plan Plus",
            "plan_pro": "👑 Plan Pro"
        }.get(plan_name, plan_name)
        
        await ev.reply(
            f"✅ *Precio Actualizado*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"{plan_display}\n"
            f"💵 Precio anterior: `{fmt_money(old_price)} {currency}`\n"
            f"💵 Precio nuevo: `{fmt_money(new_price)} {currency}`\n"
            f"━━━━━━━━━━━━━━━━",
            parse_mode="Markdown"
        )

@bot.on(events.NewMessage(func=lambda e: e.is_private and flows.get(e.sender_id, {}).get("action") == "change_credit_limit"))
async def change_credit_limit_wizard(ev):
    uid = ev.sender_id
    flow = flows.get(uid, {})
    step = flow.get("step")
    
    if step == "amount":
        # Validar límite
        try:
            new_limit = float(ev.text.strip().replace("$", "").replace(",", ""))
            if new_limit < 0:
                return await ev.reply("❌ El límite no puede ser negativo. Inténtalo de nuevo:")
        except:
            return await ev.reply("❌ Formato inválido. Envía solo el número (ej: 50 o 100):")
        
        # Actualizar límite
        reseller_id = flow.get("reseller_id")
        meta = get_reseller_meta(reseller_id)
        old_limit = meta.get("credit_limit", 0)
        
        meta["credit_limit"] = new_limit
        S["resellers_meta"][str(reseller_id)] = meta
        save_state(S)
        
        # Limpiar flow
        flows.pop(uid, None)
        
        username = get_username_display(reseller_id)
        currency = S.get("currency", "USD")
        
        await ev.reply(
            f"✅ *Límite de Crédito Actualizado*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"👤 Reseller: {username}\n"
            f"💳 Límite anterior: `{fmt_money(old_limit)} {currency}`\n"
            f"💳 Límite nuevo: `{fmt_money(new_limit)} {currency}`\n"
            f"━━━━━━━━━━━━━━━━",
            parse_mode="Markdown"
        )
        
        # Notificar al reseller
        try:
            await bot.send_message(
                reseller_id,
                f"💳 *Límite de Crédito Actualizado*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"Tu límite de crédito ha sido actualizado\n"
                f"💳 Nuevo límite: `{fmt_money(new_limit)} {currency}`\n"
                f"━━━━━━━━━━━━━━━━",
                parse_mode="Markdown"
            )
        except Exception as e:
            logger.error(f"Error notificando reseller {reseller_id}: {e}")

@bot.on(events.NewMessage(func=lambda e: e.is_private and flows.get(e.sender_id, {}).get("action") == "set_discount"))
async def set_discount_wizard(ev):
    uid = ev.sender_id
    flow = flows.get(uid, {})
    step = flow.get("step")
    
    if step == "percent":
        # Validar porcentaje
        try:
            percent = float(ev.text.strip().replace("%", "").replace(",", ""))
            if not 0 <= percent <= 100:
                return await ev.reply("❌ El porcentaje debe estar entre 0 y 100. Inténtalo de nuevo:")
        except:
            return await ev.reply("❌ Formato inválido. Envía solo el número (ej: 10 para 10%):")
        
        # Actualizar descuento
        reseller_id = flow.get("reseller_id")
        plan_name = flow.get("plan")
        meta = get_reseller_meta(reseller_id)
        
        if "discount_pct" not in meta:
            meta["discount_pct"] = {}
        
        old_discount = meta["discount_pct"].get(plan_name, 0)
        meta["discount_pct"][plan_name] = percent
        S["resellers_meta"][str(reseller_id)] = meta
        save_state(S)
        
        # Limpiar flow
        flows.pop(uid, None)
        
        username = get_username_display(reseller_id)
        plan_display = {
            "plan_estandar": "📦 Plan Estándar",
            "plan_plus": "⭐ Plan Plus",
            "plan_pro": "👑 Plan Pro"
        }.get(plan_name, plan_name)
        
        await ev.reply(
            f"✅ *Descuento Configurado*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"👤 Reseller: {username}\n"
            f"{plan_display}\n"
            f"💸 Descuento anterior: `{old_discount}%`\n"
            f"💸 Descuento nuevo: `{percent}%`\n"
            f"━━━━━━━━━━━━━━━━",
            parse_mode="Markdown"
        )
        
        # Notificar al reseller
        try:
            await bot.send_message(
                reseller_id,
                f"🎁 *Descuento Actualizado*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"{plan_display}\n"
                f"💸 Nuevo descuento: `{percent}%`\n"
                f"━━━━━━━━━━━━━━━━\n\n"
                f"Este descuento se aplicará en las próximas renovaciones.",
                parse_mode="Markdown"
            )
        except Exception as e:
            logger.error(f"Error notificando reseller {reseller_id}: {e}")

@bot.on(events.NewMessage(func=lambda e: e.is_private and flows.get(e.sender_id, {}).get("action") == "set_discount_all"))
async def set_discount_all_wizard(ev):
    uid = ev.sender_id
    flow = flows.get(uid, {})
    step = flow.get("step")
    
    if step == "percent":
        # Validar porcentaje
        try:
            percent = float(ev.text.strip().replace("%", "").replace(",", ""))
            if not 0 <= percent <= 100:
                return await ev.reply("❌ El porcentaje debe estar entre 0 y 100. Inténtalo de nuevo:")
        except:
            return await ev.reply("❌ Formato inválido. Envía solo el número (ej: 15 para 15%):")
        
        # Actualizar descuento para todos los planes
        reseller_id = flow.get("reseller_id")
        meta = get_reseller_meta(reseller_id)
        
        if "discount_pct" not in meta:
            meta["discount_pct"] = {}
        
        meta["discount_pct"]["plan_estandar"] = percent
        meta["discount_pct"]["plan_plus"] = percent
        meta["discount_pct"]["plan_pro"] = percent
        S["resellers_meta"][str(reseller_id)] = meta
        save_state(S)
        
        # Limpiar flow
        flows.pop(uid, None)
        
        username = get_username_display(reseller_id)
        
        await ev.reply(
            f"✅ *Descuento General Configurado*\n\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"👤 Reseller: {username}\n"
            f"💸 Descuento aplicado: `{percent}%`\n"
            f"📦 Todos los planes: Estándar, Plus, Pro\n"
            f"━━━━━━━━━━━━━━━━",
            parse_mode="Markdown"
        )
        
        # Notificar al reseller
        try:
            await bot.send_message(
                reseller_id,
                f"🎁 *Descuento General Actualizado*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"💸 Nuevo descuento: `{percent}%`\n"
                f"📦 Aplicado a: TODOS los planes\n"
                f"━━━━━━━━━━━━━━━━\n\n"
                f"Este descuento se aplicará en las próximas renovaciones.",
                parse_mode="Markdown"
            )
        except Exception as e:
            logger.error(f"Error notificando reseller {reseller_id}: {e}")

@bot.on(events.NewMessage(func=lambda e: e.is_private and flows.get(e.sender_id, {}).get("action") == "provision_wizard"))
async def provision_wizard_handler(ev):
    uid = ev.sender_id
    flow = flows.get(uid, {})
    step = flow.get("step")
    
    if step == "ask_token":
        token = ev.raw_text.strip()
        slug = flow.get("slug")
        
        if not token or ":" not in token:
            return await ev.reply(
                "❌ *Token inválido*\n\n"
                "El token debe tener el formato:\n"
                "`123456789:ABC-DEF1234ghIkl-zyx57W2v1u123ew11`\n\n"
                "Obtén tu token de @BotFather y envíalo nuevamente.",
                parse_mode="Markdown"
            )
        
        c = S.get("clients", {}).get(slug)
        if not c:
            flows.pop(uid, None)
            return await ev.reply("❌ Cliente no encontrado.", parse_mode="Markdown")
        
        if c.get("owner_id") != uid and not can_manage_client(uid, slug):
            flows.pop(uid, None)
            return await ev.reply("❌ No autorizado.", parse_mode="Markdown")
        
        await ev.reply("⏳ *Provisionando...*\n\nEsto puede tardar unos segundos.", parse_mode="Markdown")
        
        workdir = CLIENTS_DIR / slug
        try:
            clone_template(c.get("plan", "default"), workdir)
            write_env(workdir, bot_token=token, owner_id=c["owner_id"], slug=slug)
            ensure_venv_and_requirements(workdir)
            force_load_dotenv_override(workdir)
            enable_instance_service(slug)
            
            c["workdir"] = str(workdir)
            c["provisioned"] = True
            c["provisioned_at"] = dt.datetime.now().isoformat(timespec="seconds")
            save_state(S)
            
            flows.pop(uid, None)
            
            await ev.reply(
                f"✅ *¡Bot provisionado exitosamente!*\n\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"🔧 Cliente: `{slug}`\n"
                f"📁 Directorio: `{workdir}`\n"
                f"🟢 Servicio: Activo\n"
                f"━━━━━━━━━━━━━━━━\n\n"
                f"Tu bot ya está en funcionamiento. Usa /status para verificar su estado.",
                parse_mode="Markdown"
            )
        except Exception as e:
            logger.error(f"Provision error {slug}: {e}")
            flows.pop(uid, None)
            await ev.reply(
                f"❌ *Error provisionando*\n\n"
                f"Detalles: `{str(e)[:120]}`\n\n"
                f"Contacta a @frankosmel si el problema persiste.",
                parse_mode="Markdown"
            )

# ============================================================================
# COMANDOS DE PAGO CON QVAPAY
# ============================================================================

@bot.on(events.NewMessage(pattern=r"^💳 Recargar saldo$"))
async def recargar_button_handler(ev):
    """Handler del botón Recargar saldo (reseller)"""
    if not is_reseller(ev.sender_id):
        return
    await recargar_saldo_cmd(ev)

async def recargar_saldo_cmd(ev):
    """Comando para resellers: recargar saldo vía QvaPay"""
    uid = ev.sender_id
    
    if not is_reseller(uid):
        return await ev.reply("❌ Este comando es solo para resellers.", parse_mode="Markdown")
    
    if not QVAPAY_APP_ID or not QVAPAY_APP_SECRET:
        return await ev.reply(
            "❌ *Pagos no disponibles*\n\n"
            "El sistema de pagos QvaPay no está configurado.\n"
            "Contacta al administrador.",
            parse_mode="Markdown"
        )
    
    flows[uid] = {"action": "qvapay_topup", "step": "ask_amount"}
    
    await ev.reply(
        "💳 *Recarga de Saldo vía QvaPay*\n\n"
        "¿Cuánto deseas recargar?\n\n"
        "Monto mínimo: `$5.00 USD`\n"
        "Envía solo el número (ejemplo: `50`)",
        parse_mode="Markdown"
    )

@bot.on(events.NewMessage(func=lambda e: e.is_private and flows.get(e.sender_id, {}).get("action") == "qvapay_topup"))
async def qvapay_topup_wizard(ev):
    """Wizard para recargas vía QvaPay"""
    uid = ev.sender_id
    flow = flows.get(uid, {})
    step = flow.get("step")
    
    if step == "ask_amount":
        try:
            amount = float(ev.raw_text.strip().replace("$", "").replace(",", ""))
            
            if amount < 5.0:
                return await ev.reply(
                    "❌ Monto mínimo: `$5.00 USD`\n\n"
                    "Envía un monto mayor o igual a $5.",
                    parse_mode="Markdown"
                )
            
            # Crear factura en QvaPay
            try:
                username = get_username_display(uid)
                remote_id = f"TOPUP_{uid}_{int(dt.datetime.now().timestamp())}"
                
                invoice = await qvapay_service.create_invoice(
                    amount=amount,
                    description=f"Recarga saldo reseller {username}",
                    remote_id=remote_id
                )
                
                transaction_uuid = invoice.get("transation_uuid")
                payment_url = invoice.get("signedUrl") or invoice.get("url")
                
                # Registrar factura pendiente
                qvapay_service.register_pending_invoice(
                    transaction_uuid=transaction_uuid,
                    user_id=uid,
                    amount=amount,
                    invoice_type="reseller_topup"
                )
                
                # Enviar link de pago
                await ev.reply(
                    f"💰 *Factura Generada*\n\n"
                    f"Monto: `${amount:.2f} USD`\n"
                    f"Transacción: `{transaction_uuid}`\n\n"
                    f"👇 **Paga aquí:**\n"
                    f"{payment_url}\n\n"
                    f"✅ Una vez completado el pago, tu saldo se actualizará automáticamente.\n"
                    f"⏱ El proceso puede tomar unos minutos.",
                    parse_mode="Markdown"
                )
                
                logger.info(f"💳 Factura QvaPay creada: {transaction_uuid} - ${amount} para reseller {uid}")
                flows.pop(uid, None)
                
            except Exception as e:
                logger.error(f"Error creando factura QvaPay: {e}")
                flows.pop(uid, None)
                await ev.reply(
                    f"❌ *Error generando factura*\n\n"
                    f"Detalles: `{str(e)[:100]}`\n\n"
                    f"Contacta al administrador.",
                    parse_mode="Markdown"
                )
        
        except ValueError:
            await ev.reply(
                "❌ Monto inválido.\n\n"
                "Envía solo números (ejemplo: `50` para $50.00 USD)",
                parse_mode="Markdown"
            )

@bot.on(events.NewMessage(pattern=r"^💳 Pagar servicio$"))
async def pagar_button_handler(ev):
    """Handler del botón Pagar servicio (cliente)"""
    uid = ev.sender_id
    
    # Verificar si es cliente (tiene un bot asignado)
    client_slug = None
    for slug, c in S.get("clients", {}).items():
        if c.get("owner_id") == uid:
            client_slug = slug
            break
    
    if not client_slug:
        return await ev.reply("❌ No tienes un servicio asignado.", parse_mode="Markdown")
    
    await pagar_servicio_cmd(ev)

async def pagar_servicio_cmd(ev):
    """Comando para clientes: pagar servicio vía QvaPay"""
    uid = ev.sender_id
    
    if not QVAPAY_APP_ID or not QVAPAY_APP_SECRET:
        return await ev.reply(
            "❌ *Pagos no disponibles*\n\n"
            "El sistema de pagos QvaPay no está configurado.\n"
            "Contacta al administrador.",
            parse_mode="Markdown"
        )
    
    flows[uid] = {"action": "qvapay_payment", "step": "ask_amount"}
    
    await ev.reply(
        "💳 *Pago de Servicio vía QvaPay*\n\n"
        "¿Cuánto deseas pagar?\n\n"
        "Precio mensual: `$4.00 USD`\n"
        "Monto mínimo: `$4.00 USD`\n\n"
        "Envía el monto a pagar (ejemplo: `4` o `12` para 3 meses)",
        parse_mode="Markdown"
    )

@bot.on(events.NewMessage(func=lambda e: e.is_private and flows.get(e.sender_id, {}).get("action") == "qvapay_payment"))
async def qvapay_payment_wizard(ev):
    """Wizard para pagos de clientes vía QvaPay"""
    uid = ev.sender_id
    flow = flows.get(uid, {})
    step = flow.get("step")
    
    if step == "ask_amount":
        try:
            amount = float(ev.raw_text.strip().replace("$", "").replace(",", ""))
            
            if amount < 4.0:
                return await ev.reply(
                    "❌ Monto mínimo: `$4.00 USD` (1 mes de servicio)\n\n"
                    "Envía un monto mayor o igual a $4.",
                    parse_mode="Markdown"
                )
            
            # Crear factura en QvaPay
            try:
                username = get_username_display(uid)
                remote_id = f"PAYMENT_{uid}_{int(dt.datetime.now().timestamp())}"
                
                invoice = await qvapay_service.create_invoice(
                    amount=amount,
                    description=f"Pago servicio bot {username}",
                    remote_id=remote_id
                )
                
                transaction_uuid = invoice.get("transation_uuid")
                payment_url = invoice.get("signedUrl") or invoice.get("url")
                
                # Registrar factura pendiente
                qvapay_service.register_pending_invoice(
                    transaction_uuid=transaction_uuid,
                    user_id=uid,
                    amount=amount,
                    invoice_type="client_payment"
                )
                
                # Enviar link de pago
                meses = int(amount / 4)
                await ev.reply(
                    f"💰 *Factura Generada*\n\n"
                    f"Monto: `${amount:.2f} USD`\n"
                    f"Equivale a: `{meses} mes{'es' if meses > 1 else ''} de servicio`\n"
                    f"Transacción: `{transaction_uuid}`\n\n"
                    f"👇 **Paga aquí:**\n"
                    f"{payment_url}\n\n"
                    f"✅ Tu servicio se activará automáticamente tras el pago.\n"
                    f"⏱ El proceso puede tomar unos minutos.",
                    parse_mode="Markdown"
                )
                
                logger.info(f"💳 Factura QvaPay creada: {transaction_uuid} - ${amount} para cliente {uid}")
                flows.pop(uid, None)
                
            except Exception as e:
                logger.error(f"Error creando factura QvaPay: {e}")
                flows.pop(uid, None)
                await ev.reply(
                    f"❌ *Error generando factura*\n\n"
                    f"Detalles: `{str(e)[:100]}`\n\n"
                    f"Contacta al administrador.",
                    parse_mode="Markdown"
                )
        
        except ValueError:
            await ev.reply(
                "❌ Monto inválido.\n\n"
                "Envía solo números (ejemplo: `12` para $12.00 USD)",
                parse_mode="Markdown"
            )

# ============================================================================
# MAIN FUNCTION
# ============================================================================

async def start_webhook_server():
    """Inicia el servidor webhook en un thread separado"""
    config_webhook = uvicorn.Config(
        webhook_app,
        host="0.0.0.0",
        port=8080,
        log_level="info"
    )
    server = uvicorn.Server(config_webhook)
    await server.serve()

async def main():
    # Verificar que no haya otra instancia corriendo
    check_single_instance()
    
    await bot.start(bot_token=BOT_TOKEN)
    logger.info("✅ Bot Manager iniciado")
    
    # Configurar APScheduler para tareas programadas
    scheduler.add_job(
        scheduled_daily_billing,
        trigger=IntervalTrigger(hours=24),
        id="daily_billing",
        name="Cobro diario automático",
        replace_existing=True,
        next_run_time=dt.datetime.now() + dt.timedelta(minutes=1)  # Primera ejecución en 1 minuto
    )
    
    scheduler.add_job(
        scheduled_expiry_checker,
        trigger=IntervalTrigger(hours=1),
        id="expiry_checker",
        name="Verificador de expiración y reactivaciones",
        replace_existing=True,
        next_run_time=dt.datetime.now() + dt.timedelta(seconds=10)  # Primera ejecución en 10 segundos
    )
    
    scheduler.start()
    logger.info("✅ APScheduler iniciado con tareas programadas")
    
    # Iniciar servidor webhook para QvaPay
    if QVAPAY_APP_ID and QVAPAY_APP_SECRET:
        asyncio.create_task(start_webhook_server())
        logger.info("✅ Servidor webhook QvaPay iniciado en puerto 8080")
    else:
        logger.warning("⚠️ Servidor webhook QvaPay NO iniciado (credenciales faltantes)")
    
    await bot.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())

