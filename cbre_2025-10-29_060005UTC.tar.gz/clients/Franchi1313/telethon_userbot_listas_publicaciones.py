print("START: Bot de Reenvío con Protección Anti-Doble Clic v2")

import os, json, asyncio, re, random, datetime as dt, time
from pathlib import Path
from typing import Dict, Any, List, Optional

from telethon import TelegramClient, events, Button, types
from telethon.tl.types import ReplyKeyboardMarkup, KeyboardButton, KeyboardButtonRow
from telethon.errors import (
    PhoneNumberInvalidError, SessionPasswordNeededError, PasswordHashInvalidError,
    PhoneCodeInvalidError, PhoneCodeExpiredError, FloodWaitError, RPCError
)

# ----- Carga de .env (forzado desde este directorio) -----
from pathlib import Path as _P
from dotenv import load_dotenv
load_dotenv(dotenv_path=_P(__file__).with_name(".env"), override=True)

# ----- Config básica -----
API_ID    = int(os.getenv("API_ID", "0"))
API_HASH  = os.getenv("API_HASH", "")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
OWNER_ID  = int(os.getenv("OWNER_ID", "0"))

# Verificar credenciales básicas
if not API_ID or not API_HASH or not BOT_TOKEN or not OWNER_ID:
    print("⚠️ CREDENCIALES NO CONFIGURADAS")
    print("📝 Configura las siguientes variables de entorno:")
    print("   • API_ID - Tu API ID de Telegram")
    print("   • API_HASH - Tu API Hash de Telegram") 
    print("   • BOT_TOKEN - Token de tu bot de @BotFather")
    print("   • OWNER_ID - Tu ID de usuario de Telegram")
    print("💡 Ejecuta el bot nuevamente después de configurar las credenciales")
    exit(1)

USER_SESSION = os.getenv("USER_SESSION", "user")
BOT_SESSION  = os.getenv("BOT_SESSION",  "panelbot")
STATE_FILE   = Path(os.getenv("STATE_FILE", "state.json"))

# Zona horaria / quiet hours
try:
    from zoneinfo import ZoneInfo
except Exception:
    ZoneInfo = None

DEFAULT_STATE: Dict[str, Any] = {
    "quiet_start": os.getenv("QUIET_START", "23:30"),
    "quiet_end":   os.getenv("QUIET_END",   "07:00"),
    "timezone":    os.getenv("TIMEZONE",    "UTC"),
    "group_lists": {},   # nombre -> [chat_id,...]
    "pubs": {},  # nombre -> cfg
    "last_runs": {},     # nombre -> ISO
    "last_seen_id": 0,
    "source_channels": {},  # SOLO UN CANAL: id -> {name, added_date, last_changed}
    "auto_forward_enabled": True,  # Si está habilitado el reenvío automático
}

state: Dict[str, Any] = {}

# ===== SISTEMA DE PROTECCIÓN CONTRA BOTONES DOBLES =====
user_cooldowns: Dict[int, Dict[str, float]] = {}
COOLDOWN_SECONDS = 2.0  # Tiempo mínimo entre clics del mismo botón

def check_cooldown(user_id: int, action: str) -> bool:
    """
    Verifica si el usuario puede ejecutar una acción (no está en cooldown)
    """
    now = time.time()
    
    if user_id not in user_cooldowns:
        user_cooldowns[user_id] = {}
    
    last_action_time = user_cooldowns[user_id].get(action, 0)
    
    if now - last_action_time < COOLDOWN_SECONDS:
        return False  # En cooldown
    
    user_cooldowns[user_id][action] = now
    return True  # Puede ejecutar

def cooldown_protection(action_name: str):
    """
    Decorador para proteger handlers contra doble clic
    """
    def decorator(func):
        async def wrapper(ev: events.NewMessage.Event):
            if not check_cooldown(ev.sender_id, action_name):
                # Usuario en cooldown, ignorar silenciosamente
                return
            return await func(ev)
        return wrapper
    return decorator

def load_state() -> Dict[str, Any]:
    if STATE_FILE.exists():
        try:
            data = json.loads(STATE_FILE.read_text())
            # Migrar estado viejo al nuevo formato si es necesario
            if "source_channels" not in data:
                data["source_channels"] = {}
            if "auto_forward_enabled" not in data:
                data["auto_forward_enabled"] = True
            return data
        except Exception:
            pass
    STATE_FILE.write_text(json.dumps(DEFAULT_STATE, ensure_ascii=False, indent=2))
    return json.loads(STATE_FILE.read_text())

def save_state(s: Dict[str, Any]):
    STATE_FILE.write_text(json.dumps(s, ensure_ascii=False, indent=2))

state = load_state()

# --- MIGRACIÓN publications -> pubs (una sola clave) ---
try:
    if state.get("publications") and not state.get("pubs"):
        state["pubs"] = state.get("publications", {})
        save_state(state)
except Exception:
    pass

# ----- Utilidades de tiempo -----
def _tz():
    tzname = state.get("timezone", "UTC")
    if ZoneInfo:
        try:
            return ZoneInfo(tzname)
        except Exception:
            return ZoneInfo("UTC")
    return None

def tznow() -> dt.datetime:
    tz = _tz()
    return dt.datetime.now(tz) if tz else dt.datetime.utcnow()

def in_quiet_hours(now_local: dt.time) -> bool:
    qs = dt.datetime.strptime(state["quiet_start"], "%H:%M").time()
    qe = dt.datetime.strptime(state["quiet_end"],   "%H:%M").time()
    if qs < qe:
        return qs <= now_local < qe
    # cruce de medianoche
    return now_local >= qs or now_local < qe

# ----- Clientes -----
user = TelegramClient(USER_SESSION, API_ID, API_HASH)
bot  = TelegramClient(BOT_SESSION,  API_ID, API_HASH)

# ===== SISTEMA DE FLUJOS PARA AUTENTICACIÓN Y ASISTENTES =====
user_flows: Dict[int, Dict[str, Any]] = {}

# ----- Decoradores / helpers UI -----
def owner_only(func):
    async def wrapper(ev: events.NewMessage.Event):
        if ev.sender_id != OWNER_ID:
            return await ev.reply("🚫 **Acceso denegado**\n\n❌ Solo el propietario puede usar este bot.")
        return await func(ev)
    return wrapper

# ----- Menús con Reply Keyboard -----
def main_menu():
    """Menú principal con opciones generales"""
    return ReplyKeyboardMarkup([
        KeyboardButtonRow([KeyboardButton("📊 Estado"), KeyboardButton("🔐 Autenticación")]),
        KeyboardButtonRow([KeyboardButton("📋 Mis Listas"), KeyboardButton("🚀 Publicaciones")]),
        KeyboardButtonRow([KeyboardButton("📺 Canal Origen"), KeyboardButton("⚙️ Configuración")]),
        KeyboardButtonRow([KeyboardButton("❓ Ayuda")])
    ], resize=True)

def auth_menu():
    """Menú de autenticación"""
    return ReplyKeyboardMarkup([
        KeyboardButtonRow([KeyboardButton("🔑 Iniciar Sesión"), KeyboardButton("📱 Mis Grupos")]),
        KeyboardButtonRow([KeyboardButton("🚪 Cerrar Sesión"), KeyboardButton("🏠 Menú Principal")])
    ], resize=True)

def lists_menu():
    """Menú de gestión de listas"""
    return ReplyKeyboardMarkup([
        KeyboardButtonRow([KeyboardButton("👀 Ver Listas"), KeyboardButton("➕ Nueva Lista")]),
        KeyboardButtonRow([KeyboardButton("📝 Agregar IDs"), KeyboardButton("✏️ Renombrar Lista")]),
        KeyboardButtonRow([KeyboardButton("🗑️ Borrar Lista"), KeyboardButton("🏠 Menú Principal")])
    ], resize=True)

def pubs_menu():
    """Menú de publicaciones"""
    return ReplyKeyboardMarkup([
        KeyboardButtonRow([KeyboardButton("📊 Ver Publicaciones"), KeyboardButton("✨ Crear Nueva")]),
        KeyboardButtonRow([KeyboardButton("✏️ Editar Publicación"), KeyboardButton("⏯️ Activar/Pausar")]),
        KeyboardButtonRow([KeyboardButton("❌ Eliminar Publicación")]),
        KeyboardButtonRow([KeyboardButton("🏠 Menú Principal")])
    ], resize=True)

def source_channels_menu():
    """Menú de gestión del canal origen único"""
    return ReplyKeyboardMarkup([
        KeyboardButtonRow([KeyboardButton("🔗 Vincular Origen"), KeyboardButton("⏯️ Toggle Auto-Reenvío")]),
        KeyboardButtonRow([KeyboardButton("🗑️ Desvincular Canal"), KeyboardButton("🏠 Menú Principal")])
    ], resize=True)

def config_menu():
    """Menú de configuración"""
    return ReplyKeyboardMarkup([
        KeyboardButtonRow([KeyboardButton("🌙 Horario Silencioso"), KeyboardButton("🌍 Zona Horaria")]),
        KeyboardButtonRow([KeyboardButton("🏠 Menú Principal")])
    ], resize=True)

# ----- Parse helpers mejorados -----
_link_re = re.compile(r"t\.me/c/(\d+)/(\d+)")

def parse_source_ref(txt: str):
    """
    Acepta:
    - Link interno: https://t.me/c/<internal>/<msg>
    - Dos enteros: <chat_id> <msg_id>
    Devuelve (chat_id, msg_id) o None.
    """
    m = _link_re.search(txt)
    if m:
        internal, msg = m.group(1), int(m.group(2))
        chat_id = int(f"-100{internal}")
        return (chat_id, msg)
    parts = re.findall(r"-?\d+", txt)
    if len(parts) >= 2:
        return (int(parts[0]), int(parts[1]))
    return None

# ----- Función mejorada para resolver entidades -----
async def resolve_entity_safely(client: TelegramClient, entity_id, retry_count: int = 3):
    """
    Intenta resolver una entidad de Telegram de forma segura con reintentos
    """
    for attempt in range(retry_count):
        try:
            # Primero intentar obtener la entidad directamente
            return await client.get_input_entity(entity_id)
        except Exception as e:
            if attempt == 0:
                # En el primer intento, intentar obtener el diálogo
                try:
                    async for dialog in client.iter_dialogs():
                        if hasattr(dialog, 'id') and dialog.id == entity_id:
                            return await client.get_input_entity(dialog.entity)
                        elif hasattr(dialog.entity, 'id') and dialog.entity.id == entity_id:
                            return await client.get_input_entity(dialog.entity)
                except Exception:
                    pass
            
            if attempt == retry_count - 1:
                # Último intento: usar el ID directamente si es un chat
                entity_id_str = str(entity_id)
                if entity_id_str.startswith('-100'):
                    return types.InputPeerChannel(
                        channel_id=int(entity_id_str[4:]),
                        access_hash=0
                    )
                elif int(entity_id) < 0:
                    return types.InputPeerChat(chat_id=-int(entity_id))
                else:
                    raise e
            
            # Esperar antes del siguiente intento
            await asyncio.sleep(1)
    
    # Si llega aquí, falló todos los intentos
    raise Exception(f"No se pudo resolver entidad {entity_id}")

async def get_message_safely(client: TelegramClient, chat_id: int, msg_id: int):
    """
    Obtiene un mensaje de forma segura con manejo mejorado de errores
    """
    try:
        # Resolver entidad de forma segura
        entity = await resolve_entity_safely(client, chat_id)
        message = await client.get_messages(entity, ids=msg_id)
        return message
    except Exception as e:
        print(f"[ERROR] No se pudo obtener mensaje {msg_id} de {chat_id}: {e}")
        return None

# ----------------- copy_as_user robusto -----------------
async def copy_as_user(client: TelegramClient, msg, target_id: int):
    """
    Copia un mensaje como usuario con manejo mejorado de errores
    """
    try:
        # Resolver destino para evitar "Could not find the input entity"
        target = await resolve_entity_safely(client, target_id)
        if not target:
            raise Exception(f"No se pudo resolver entidad {target_id}")
        
        text = getattr(msg, 'message', '') or getattr(msg, 'text', '') or getattr(msg, "caption", "") or ""
        entities = getattr(msg, 'entities', None)
        media = getattr(msg, 'media', None)

        # Si hay media: re-subir con caption
        if isinstance(media, (types.MessageMediaPhoto, types.MessageMediaDocument)):
            import tempfile
            
            with tempfile.TemporaryDirectory() as td:
                try:
                    f = await client.download_media(msg, file=td)
                except:
                    f = None
                    
                if not f:
                    try:
                        await client.send_message(target, text, formatting_entities=entities, link_preview=False)
                    except Exception:
                        await client.send_message(target, text, link_preview=False)
                    return
                
                try:
                    await client.send_file(target, f, caption=text, formatting_entities=entities)
                except Exception:
                    await client.send_file(target, f, caption=text)  # sin entities
            return

        # Solo texto
        try:
            await client.send_message(target, text, formatting_entities=entities, link_preview=False)
        except Exception as e:
            print(f"[warn] send_message entities failed: {e}; try no-entities")
            await client.send_message(target, text, link_preview=False)
    except Exception as e:
        print(f"[ERROR] copy_as_user failed para {target_id}: {e}")
        raise

# ----------------- Manejo de Conexión Automática -----------------
async def ensure_user_connected() -> bool:
    """
    Verifica que el user client esté conectado y funcionando.
    Intenta reconectar automáticamente si es necesario.
    Retorna True si está conectado y funcional, False si no se pudo conectar.
    """
    try:
        # 1. Verificar si está conectado
        if not user.is_connected():
            print("[RECONNECT] Cliente usuario desconectado, intentando reconectar...")
            await user.connect()
            await asyncio.sleep(2)  # Dar tiempo para la conexión
        
        # 2. Verificar que la conexión funcione realmente
        try:
            me = await user.get_me()
            if me:
                return True
        except Exception as test_error:
            print(f"[RECONNECT] Conexión no funcional: {test_error}")
            
            # 3. Intentar reconectar completamente
            try:
                await user.disconnect()
                await asyncio.sleep(1)
                await user.connect()
                await asyncio.sleep(3)
                
                # 4. Verificar nuevamente
                me = await user.get_me()
                if me:
                    print(f"[RECONNECT] ✅ Reconectado como @{getattr(me, 'username', '???')}")
                    return True
                else:
                    return False
                    
            except Exception as reconnect_error:
                print(f"[RECONNECT] ❌ Error en reconexión: {reconnect_error}")
                return False
                
    except Exception as e:
        print(f"[RECONNECT] ❌ Error verificando conexión: {e}")
        return False
    
    return False

# ----------------- Publicaciones programadas mejoradas -----------------
async def run_publications():
    """
    Recorre publicaciones activas, respeta quiet hours, y reenvía con copy_as_user.
    """
    print("DBG: scheduler loop start - Sistema Anti-Detección ACTIVO")
    
    # 🤖 AUTODELAYS: Delay inicial aleatorio (simula tiempo de "pensamiento" humano)
    initial_delay = random.uniform(2, 8)
    print(f"[HUMANIZE] Delay inicial: {initial_delay:.1f}s")
    await asyncio.sleep(initial_delay)
    
    # 🤖 Contador para comportamiento cíclico irregular
    cycle_count = 0
    
    while True:
        try:
            cycle_count += 1
            now = tznow()
            
            # 🔗 VERIFICACIÓN DE CONEXIÓN CRÍTICA: Antes de cualquier operación
            if not await ensure_user_connected():
                print("[PAUSE] ❌ Sin conexión válida - pausando publicaciones por 30s")
                await asyncio.sleep(30)  # Pausa más larga cuando no hay conexión
                continue
            
            # 🤖 AUTODELAYS: Pausa ocasional simulando inactividad humana
            if cycle_count % random.randint(15, 30) == 0:  # Cada 15-30 ciclos
                pause_duration = random.uniform(30, 120)  # 30-120 segundos de pausa
                print(f"[HUMANIZE] Pausa simulada de inactividad: {pause_duration:.1f}s")
                await asyncio.sleep(pause_duration)
            
            if in_quiet_hours(now.time()):
                quiet_delay = random.uniform(8, 15)  # Variación en quiet hours también
                await asyncio.sleep(quiet_delay)
                continue

            pubs = state.get("pubs", {})
            # 🤖 HUMANIZACIÓN: Orden aleatorio de procesamiento de publicaciones
            pub_items = list(pubs.items())
            random.shuffle(pub_items)
            
            for name, cfg in pub_items:
                if not cfg.get("enabled", True):
                    continue
                
                # intervalo con variación aleatoria anti-detección
                interval_min = int(cfg.get("interval_min", 30))
                delay_base   = float(cfg.get("delay_base", 2.0))
                
                # 🤖 AUTODELAYS: Variación aleatoria para evitar detección
                # Intervalo base + variación aleatoria de ±10% del intervalo + segundos aleatorios
                interval_variation = random.uniform(-0.1, 0.15)  # -10% a +15% variación
                extra_seconds = random.uniform(5, 45)  # 5-45 segundos extra aleatorios
                actual_interval = (interval_min * 60) + (interval_min * 60 * interval_variation) + extra_seconds

                # control de última ejecución con intervalo humanizado
                last = state.get("last_runs", {}).get(name)
                if last:
                    try:
                        last_dt = dt.datetime.fromisoformat(last)
                    except Exception:
                        last_dt = None
                    if last_dt and (tznow() - last_dt).total_seconds() < actual_interval:
                        continue
                
                # origen
                src_chat = int(cfg["source_chat_id"])
                src_msg  = int(cfg["source_msg_id"])
                
                # destino(s)
                target_list = cfg.get("target_list")
                if target_list == "TODOS":
                    targets = await collect_all_groups(user)
                else:
                    targets = state.get("group_lists", {}).get(target_list, [])
                
                # obtiene mensaje original con manejo mejorado
                orig = await get_message_safely(user, src_chat, src_msg)
                if not orig:
                    print(f"[ERROR] No se pudo obtener mensaje para publicación {name}")
                    continue
                    
                # Si orig es una lista, tomar el primer elemento
                if hasattr(orig, '__iter__') and not isinstance(orig, str):
                    if hasattr(orig, '__len__') and len(orig) > 0:
                        orig = orig[0]
                    elif hasattr(orig, '__getitem__'):
                        try:
                            orig = orig[0]
                        except (IndexError, TypeError):
                            pass

                # 🤖 HUMANIZACIÓN: Mezclar orden de grupos de forma más realista
                random.shuffle(targets)
                
                # 🤖 AUTODELAYS: Variable para simular comportamiento humano irregular
                group_count = 0
                total_groups = len(targets)
                
                for t in targets:
                    group_count += 1
                    
                    try:
                        await copy_as_user(user, orig, t)
                        print(f"[SEND] Enviado a grupo {group_count}/{total_groups} - ID: {t}")
                    except FloodWaitError as fw:
                        print(f"[FLOOD] {t}: wait {fw.seconds}s")
                        await asyncio.sleep(fw.seconds + 2)
                    except Exception as e:
                        print(f"[ERROR] {t}: {e}")
                    
                    # 🤖 AUTODELAYS ENTRE GRUPOS: Máximo 5 segundos como solicitaste
                    if group_count < total_groups:  # No delay después del último grupo
                        # Usar delay_base de configuración + variación aleatoria
                        base_delay = max(1.2, min(delay_base, 3.0))  # Respetar config pero limitar
                        
                        # Variación humana manteniendo el límite de 5s máximo
                        max_variation = 5.0 - base_delay
                        human_variation = random.uniform(0.2, max_variation)
                        
                        # Comportamiento ocasional: 5% chance de micro-pausa (pero dentro del límite)
                        if random.random() < 0.05:  # 5% chance de pausa reflexiva
                            extra_pause = random.uniform(1.0, min(2.0, max_variation))
                            human_variation += extra_pause
                        
                        # Asegurar que no exceda 5 segundos TOTAL
                        total_delay = min(base_delay + human_variation, 5.0)
                        
                        await asyncio.sleep(total_delay)
                        print(f"[DELAY] {total_delay:.2f}s (base:{base_delay:.1f}s) antes del siguiente grupo")

                # 🤖 HUMANIZACIÓN: Marcar ejecución con timestamp ligeramente aleatorio
                # (simula variaciones de procesamiento humano)
                execution_time = tznow()
                microsecond_variation = random.randint(0, 999999)
                execution_time = execution_time.replace(microsecond=microsecond_variation)
                
                state.setdefault("last_runs", {})[name] = execution_time.isoformat()
                save_state(state)
                
                print(f"[PUB-COMPLETE] '{name}' enviada a {len(targets)} grupos con autodelays humanizados")

            # 🤖 AUTODELAYS: Variación en el ciclo del scheduler
            # Simula comportamiento humano irregular en el monitoreo
            scheduler_delay = random.uniform(3, 12)  # 3-12 segundos en lugar de fijo 5
            await asyncio.sleep(scheduler_delay)
        except Exception as e:
            print("[scheduler_error]", e)
            # 🤖 Delay aleatorio también en errores
            error_delay = random.uniform(5, 15)
            await asyncio.sleep(error_delay)

async def collect_all_groups(client: TelegramClient) -> List[int]:
    ids: List[int] = []
    try:
        async for d in client.iter_dialogs():
            ent = d.entity
            try:
                if getattr(ent, 'megagroup', False) or ent.__class__.__name__ in ("Chat",):
                    ids.append(ent.id)
            except Exception:
                pass
    except Exception as e:
        print(f"[collect_groups_error] {e}")
    return ids

# ===== COMANDOS CON BOTONES Y PROTECCIÓN ANTI-DOBLE CLIC =====

@bot.on(events.NewMessage(pattern=r'^/start$|^🏠 Menú Principal$'))
@owner_only
@cooldown_protection("main_menu")
async def start_cmd(ev: events.NewMessage.Event):
    if not user.is_connected():
        status = "❌ **Desconectado**"
    else:
        try:
            me = await user.get_me()
            status = f"✅ **Conectado** como @{getattr(me, 'username', '???')}"
        except:
            status = "⚠️ **Estado incierto**"

    pubs = state.get("pubs", {})
    active = sum(1 for p in pubs.values() if p.get("enabled", True))
    total = len(pubs)
    
    source_channels = state.get("source_channels", {})
    has_channel = "✅ Vinculado" if source_channels else "❌ Sin vincular"

    await ev.reply(
        f"🤖 **Panel de Control**\n\n"
        f"👤 **Estado:** {status}\n"
        f"📊 **Publicaciones:** {active}/{total} activas\n"
        f"📺 **Canal origen:** {has_channel}\n\n"
        f"Selecciona una opción:",
        buttons=main_menu()
    )

# ===== MENÚ DE ESTADO =====
@bot.on(events.NewMessage(pattern=r'^📊 Estado$'))
@owner_only
@cooldown_protection("status_menu")
async def status_menu(ev: events.NewMessage.Event):
    if not user.is_connected():
        status = "❌ **Desconectado** - Usa 'Iniciar Sesión' para autenticarte"
    else:
        try:
            me = await user.get_me()
            status = f"✅ **Conectado** como @{getattr(me, 'username', '???')}"
        except:
            status = "⚠️ **Estado incierto** - Podrías necesitar reconectarte"

    pubs = state.get("pubs", {})
    active = sum(1 for p in pubs.values() if p.get("enabled", True))
    total = len(pubs)

    tz = state.get("timezone", "UTC")
    quiet_start = state.get("quiet_start", "23:30")
    quiet_end = state.get("quiet_end", "07:00")
    
    auto_forward = "✅ Habilitado" if state.get("auto_forward_enabled", True) else "❌ Deshabilitado"

    await ev.reply(
        f"📊 **Estado Detallado**\n\n"
        f"👤 **Usuario:** {status}\n"
        f"🚀 **Publicaciones:** {active}/{total} activas\n"
        f"📺 **Auto-reenvío:** {auto_forward}\n"
        f"🌍 **Zona horaria:** {tz}\n"
        f"🌙 **Horario silencioso:** {quiet_start} - {quiet_end}\n\n"
        f"✨ Usa los botones para navegar",
        buttons=main_menu()
    )

# ===== MENÚ DE CANALES ORIGEN =====
@bot.on(events.NewMessage(pattern=r'^📺 Canal Origen$'))
@owner_only
@cooldown_protection("source_channels_menu")
async def source_channels_menu_handler(ev: events.NewMessage.Event):
    source_channels = state.get("source_channels", {})
    has_channel = len(source_channels) > 0
    auto_forward = "✅ Habilitado" if state.get("auto_forward_enabled", True) else "❌ Deshabilitado"
    
    if has_channel:
        channel_id, channel_data = next(iter(source_channels.items()))
        channel_name = channel_data.get("name", f"Canal {channel_id}")
        status_msg = f"📺 **Canal vinculado:** {channel_name}\n🆔 **ID:** `{channel_id}`"
    else:
        status_msg = "📺 **No hay canal vinculado**"
    
    await ev.reply(
        f"📺 **Gestión del Canal Origen**\n\n"
        f"{status_msg}\n"
        f"🔄 **Auto-reenvío:** {auto_forward}\n\n"
        f"Selecciona una opción:",
        buttons=source_channels_menu()
    )

@bot.on(events.NewMessage(pattern=r'^🔗 Vincular Origen$'))
@owner_only
@cooldown_protection("link_source")
async def link_source_channel(ev: events.NewMessage.Event):
    if not user.is_connected():
        await ev.reply(
            "❌ **No estás autenticado**\n\n"
            "🔑 Usa 'Iniciar Sesión' primero",
            buttons=source_channels_menu()
        )
        return
    
    # Verificar si ya hay un canal vinculado
    source_channels = state.get("source_channels", {})
    if source_channels:
        channel_id, channel_data = next(iter(source_channels.items()))
        channel_name = channel_data.get("name", f"Canal {channel_id}")
        await ev.reply(
            f"⚠️ **Ya tienes un canal vinculado**\n\n"
            f"📺 **Canal actual:** {channel_name}\n"
            f"🆔 **ID:** `{channel_id}`\n\n"
            f"💡 Usa 'Desvincular Canal' primero si quieres cambiar",
            buttons=source_channels_menu()
        )
        return
    
    user_flows[ev.sender_id] = {
        "action": "link_source_channel",
        "step": "channel_input"
    }
    
    await ev.reply(
        "🔗 **Vincular Canal Origen**\n\n"
        "📝 **Puedes vincular de 2 formas:**\n\n"
        "1️⃣ **Reenviar un mensaje** del canal que quieres vincular\n"
        "2️⃣ **Enviar enlace/ID** del canal:\n"
        "   • ID directo: `-1001234567890`\n"
        "   • Username: `@nombre_canal`\n"
        "   • Enlace: `https://t.me/nombre_canal`\n\n"
        "❌ Escribe /cancel para cancelar",
        buttons=ReplyKeyboardMarkup([
            KeyboardButtonRow([KeyboardButton("❌ Cancelar")])
        ], resize=True)
    )

@bot.on(events.NewMessage(pattern=r'^🗑️ Desvincular Canal$'))
@owner_only
@cooldown_protection("unlink_source")
async def unlink_source_channel(ev: events.NewMessage.Event):
    source_channels = state.get("source_channels", {})
    if not source_channels:
        await ev.reply(
            "📂 **No hay canal vinculado**\n\n"
            "🔗 Usa 'Vincular Origen' para configurar un canal",
            buttons=source_channels_menu()
        )
        return
    
    # Eliminar el canal vinculado
    channel_id, channel_data = next(iter(source_channels.items()))
    channel_name = channel_data.get("name", f"Canal {channel_id}")
    
    state["source_channels"] = {}
    save_state(state)
    
    await ev.reply(
        f"✅ **Canal desvinculado**\n\n"
        f"🗑️ **Canal:** {channel_name}\n"
        f"🆔 **ID:** `{channel_id}`\n\n"
        f"💡 El canal ya no se usará como origen",
        buttons=source_channels_menu()
    )

@bot.on(events.NewMessage(pattern=r'^⏯️ Toggle Auto-Reenvío$'))
@owner_only
@cooldown_protection("toggle_auto_forward")
async def toggle_auto_forward(ev: events.NewMessage.Event):
    current_state = state.get("auto_forward_enabled", True)
    new_state = not current_state
    
    state["auto_forward_enabled"] = new_state
    save_state(state)
    
    status = "✅ **Habilitado**" if new_state else "❌ **Deshabilitado**"
    action = "habilitado" if new_state else "deshabilitado"
    
    msg = f"⏯️ **Auto-reenvío {action}**\n\n"
    if new_state:
        msg += "🔄 Los mensajes del canal origen se reenviarán automáticamente a los grupos\n"
        msg += "💡 También se respetan las publicaciones programadas"
    else:
        msg += "⏸️ Solo se enviarán las publicaciones programadas\n"
        msg += "💡 Los mensajes nuevos en el canal no se reenviarán automáticamente"
    
    await ev.reply(msg, buttons=source_channels_menu())

# ===== MENÚ DE AUTENTICACIÓN =====
@bot.on(events.NewMessage(pattern=r'^🔐 Autenticación$'))
@owner_only
@cooldown_protection("auth_menu")
async def auth_menu_handler(ev: events.NewMessage.Event):
    if not user.is_connected():
        status = "❌ **Desconectado**"
    else:
        try:
            me = await user.get_me()
            status = f"✅ **Conectado** como @{getattr(me, 'username', '???')}"
        except:
            status = "⚠️ **Estado incierto**"

    await ev.reply(
        f"🔐 **Gestión de Autenticación**\n\n"
        f"👤 **Estado actual:** {status}\n\n"
        f"Selecciona una opción:",
        buttons=auth_menu()
    )

@bot.on(events.NewMessage(pattern=r'^🔑 Iniciar Sesión$'))
@owner_only
@cooldown_protection("login_start")
async def login_user_start(ev: events.NewMessage.Event):
    # Verificar si ya está autenticado DE VERDAD
    if user.is_connected():
        try:
            me = await user.get_me()
            if me:  # Si puede obtener info del usuario, está realmente conectado
                await ev.reply(
                    "✅ **Ya estás autenticado**\n\n"
                    f"🔒 Conectado como @{getattr(me, 'username', '???')}\n\n"
                    f"💡 Si quieres cambiar de cuenta, usa 'Cerrar Sesión' primero",
                    buttons=auth_menu()
                )
                return
        except Exception as e:
            # Si hay error obteniendo usuario, la sesión no es válida
            print(f"[DEBUG] Error al verificar sesión: {e}")
            try:
                await user.disconnect()
                await user.connect()
            except:
                pass
    
    # Limpiar cualquier flujo anterior
    user_flows.pop(ev.sender_id, None)
    
    # Iniciar nuevo flujo de login
    user_flows[ev.sender_id] = {
        "action": "login", 
        "step": "phone"
    }
    
    await ev.reply(
        "🔐 **Proceso de Autenticación**\n\n"
        "📱 **Paso 1:** Envía tu número de teléfono\n"
        "📝 Ejemplo: +1234567890\n"
        "💡 Incluye el código de país\n\n"
        "❌ Escribe /cancel para cancelar",
        buttons=ReplyKeyboardMarkup([
            KeyboardButtonRow([KeyboardButton("❌ Cancelar Login")])
        ], resize=True)
    )

@bot.on(events.NewMessage(pattern=r'^🚪 Cerrar Sesión$'))
@owner_only
@cooldown_protection("logout")
async def logout_user(ev: events.NewMessage.Event):
    try:
        await user.log_out()
        await ev.reply(
            "✅ **Sesión cerrada exitosamente**\n\n"
            "🔐 Has sido desconectado de Telegram\n"
            "💡 Usa 'Iniciar Sesión' para conectarte nuevamente",
            buttons=auth_menu()
        )
    except Exception as e:
        await ev.reply(
            f"❌ **Error al cerrar sesión:** {str(e)}\n\n"
            "🔄 Intenta nuevamente",
            buttons=auth_menu()
        )

@bot.on(events.NewMessage(pattern=r'^📱 Mis Grupos$'))
@owner_only
@cooldown_protection("show_groups")
async def show_user_groups(ev: events.NewMessage.Event):
    if not user.is_connected():
        await ev.reply(
            "❌ **No estás autenticado**\n\n"
            "🔑 Usa 'Iniciar Sesión' primero",
            buttons=auth_menu()
        )
        return
    
    try:
        groups = await collect_all_groups(user)
        if not groups:
            await ev.reply(
                "📱 **No tienes grupos**\n\n"
                "💡 Únete a algunos grupos primero",
                buttons=auth_menu()
            )
            return
        
        group_info = []
        count = 0
        for group_id in groups[:20]:  # Limitar a 20 grupos para evitar mensaje muy largo
            try:
                entity = await user.get_entity(group_id)
                title = getattr(entity, 'title', f'Grupo {group_id}')
                group_info.append(f"• {title} (`{group_id}`)")
                count += 1
            except:
                group_info.append(f"• Grupo `{group_id}`")
                count += 1
        
        total_groups = len(groups)
        showing = min(20, total_groups)
        
        msg = f"📱 **Tus Grupos** ({showing}/{total_groups})\n\n"
        msg += "\n".join(group_info)
        
        if total_groups > 20:
            msg += f"\n\n💡 Mostrando solo los primeros 20 grupos"
        
        await ev.reply(msg, buttons=auth_menu())
        
    except Exception as e:
        await ev.reply(
            f"❌ **Error obteniendo grupos:** {str(e)}\n\n"
            "🔄 Intenta nuevamente",
            buttons=auth_menu()
        )

# ===== MENÚ DE LISTAS =====
@bot.on(events.NewMessage(pattern=r'^📋 Mis Listas$'))
@owner_only
@cooldown_protection("lists_menu")
async def lists_menu_handler(ev: events.NewMessage.Event):
    group_lists = state.get("group_lists", {})
    total_lists = len(group_lists)
    total_groups = sum(len(groups) for groups in group_lists.values())
    
    await ev.reply(
        f"📋 **Gestión de Listas**\n\n"
        f"📊 **Estadísticas:**\n"
        f"• **Listas:** {total_lists}\n"
        f"• **Grupos totales:** {total_groups}\n\n"
        f"Selecciona una opción:",
        buttons=lists_menu()
    )

@bot.on(events.NewMessage(pattern=r'^👀 Ver Listas$'))
@owner_only
@cooldown_protection("view_lists")
async def view_lists(ev: events.NewMessage.Event):
    group_lists = state.get("group_lists", {})
    
    if not group_lists:
        await ev.reply(
            "📋 **No tienes listas**\n\n"
            "➕ Usa 'Nueva Lista' para crear una",
            buttons=lists_menu()
        )
        return
    
    msg = "📋 **Tus Listas:**\n\n"
    for name, groups in group_lists.items():
        msg += f"📝 **{name}** - {len(groups)} grupos\n"
        if groups:
            # Mostrar solo los primeros 3 IDs
            preview = groups[:3]
            ids_text = ", ".join(f"`{g}`" for g in preview)
            if len(groups) > 3:
                ids_text += f" ... (+{len(groups)-3} más)"
            msg += f"   {ids_text}\n"
        msg += "\n"
    
    await ev.reply(msg, buttons=lists_menu())

@bot.on(events.NewMessage(pattern=r'^➕ Nueva Lista$'))
@owner_only
@cooldown_protection("new_list")
async def create_new_list(ev: events.NewMessage.Event):
    user_flows[ev.sender_id] = {
        "action": "create_list",
        "step": "name"
    }
    
    await ev.reply(
        "➕ **Crear Nueva Lista**\n\n"
        "📝 **Envía el nombre de la lista:**\n"
        "💡 Solo letras, números, _ y -\n"
        "📏 Máximo 50 caracteres\n\n"
        "❌ Escribe /cancel para cancelar",
        buttons=ReplyKeyboardMarkup([
            KeyboardButtonRow([KeyboardButton("❌ Cancelar")])
        ], resize=True)
    )

@bot.on(events.NewMessage(pattern=r'^📝 Agregar IDs$'))
@owner_only
@cooldown_protection("add_ids")
async def add_ids_to_list(ev: events.NewMessage.Event):
    group_lists = state.get("group_lists", {})
    
    if not group_lists:
        await ev.reply(
            "📋 **No tienes listas**\n\n"
            "➕ Crea una lista primero",
            buttons=lists_menu()
        )
        return
    
    user_flows[ev.sender_id] = {
        "action": "add_ids",
        "step": "list_selection"
    }
    
    list_names = "\n".join(f"• {name}" for name in group_lists.keys())
    
    await ev.reply(
        f"📝 **Agregar IDs a Lista**\n\n"
        f"📋 **Listas disponibles:**\n{list_names}\n\n"
        f"📝 **Envía el nombre de la lista:**",
        buttons=ReplyKeyboardMarkup([
            KeyboardButtonRow([KeyboardButton("❌ Cancelar")])
        ], resize=True)
    )

@bot.on(events.NewMessage(pattern=r'^✏️ Renombrar Lista$'))
@owner_only
@cooldown_protection("rename_list")
async def rename_list(ev: events.NewMessage.Event):
    group_lists = state.get("group_lists", {})
    
    if not group_lists:
        await ev.reply(
            "📋 **No tienes listas**\n\n"
            "➕ Crea una lista primero",
            buttons=lists_menu()
        )
        return
    
    user_flows[ev.sender_id] = {
        "action": "rename_list",
        "step": "list_selection"
    }
    
    list_names = "\n".join(f"• {name}" for name in group_lists.keys())
    
    await ev.reply(
        f"✏️ **Renombrar Lista**\n\n"
        f"📋 **Listas disponibles:**\n{list_names}\n\n"
        f"📝 **Envía el nombre de la lista a renombrar:**",
        buttons=ReplyKeyboardMarkup([
            KeyboardButtonRow([KeyboardButton("❌ Cancelar")])
        ], resize=True)
    )

@bot.on(events.NewMessage(pattern=r'^🗑️ Borrar Lista$'))
@owner_only
@cooldown_protection("delete_list")
async def delete_list(ev: events.NewMessage.Event):
    group_lists = state.get("group_lists", {})
    
    if not group_lists:
        await ev.reply(
            "📋 **No tienes listas**\n\n"
            "➕ Crea una lista primero",
            buttons=lists_menu()
        )
        return
    
    user_flows[ev.sender_id] = {
        "action": "delete_list",
        "step": "list_selection"
    }
    
    list_names = "\n".join(f"• {name}" for name in group_lists.keys())
    
    await ev.reply(
        f"🗑️ **Borrar Lista**\n\n"
        f"📋 **Listas disponibles:**\n{list_names}\n\n"
        f"⚠️ **CUIDADO:** Esta acción no se puede deshacer\n"
        f"📝 **Envía el nombre de la lista a borrar:**",
        buttons=ReplyKeyboardMarkup([
            KeyboardButtonRow([KeyboardButton("❌ Cancelar")])
        ], resize=True)
    )

# ===== MENÚ DE PUBLICACIONES =====
@bot.on(events.NewMessage(pattern=r'^🚀 Publicaciones$'))
@owner_only
@cooldown_protection("pubs_menu")
async def pubs_menu_handler(ev: events.NewMessage.Event):
    pubs = state.get("pubs", {})
    active = sum(1 for p in pubs.values() if p.get("enabled", True))
    total = len(pubs)
    
    await ev.reply(
        f"🚀 **Gestión de Publicaciones**\n\n"
        f"📊 **Estadísticas:**\n"
        f"• **Publicaciones:** {total}\n"
        f"• **Activas:** {active}\n"
        f"• **Pausadas:** {total - active}\n\n"
        f"Selecciona una opción:",
        buttons=pubs_menu()
    )

@bot.on(events.NewMessage(pattern=r'^📊 Ver Publicaciones$'))
@owner_only
@cooldown_protection("view_pubs")
async def view_publications(ev: events.NewMessage.Event):
    pubs = state.get("pubs", {})
    
    if not pubs:
        await ev.reply(
            "🚀 **No tienes publicaciones**\n\n"
            "✨ Usa 'Crear Nueva' para crear una",
            buttons=pubs_menu()
        )
        return
    
    msg = "🚀 **Tus Publicaciones:**\n\n"
    for name, cfg in pubs.items():
        status = "✅ Activa" if cfg.get("enabled", True) else "⏸️ Pausada"
        interval = cfg.get("interval_min", 30)
        target_list = cfg.get("target_list", "Sin definir")
        
        msg += f"📝 **{name}**\n"
        msg += f"   🎯 Lista: {target_list}\n"
        msg += f"   ⏰ Intervalo: {interval} min\n"
        msg += f"   📊 Estado: {status}\n\n"
    
    await ev.reply(msg, buttons=pubs_menu())

@bot.on(events.NewMessage(pattern=r'^✨ Crear Nueva$'))
@owner_only
@cooldown_protection("new_pub")
async def create_new_publication(ev: events.NewMessage.Event):
    if not user.is_connected():
        await ev.reply(
            "❌ **No estás autenticado**\n\n"
            "🔑 Usa 'Iniciar Sesión' primero",
            buttons=pubs_menu()
        )
        return
    
    user_flows[ev.sender_id] = {
        "action": "create_publication",
        "step": "name"
    }
    
    await ev.reply(
        "✨ **Crear Nueva Publicación**\n\n"
        "📝 **Paso 1:** Envía el nombre de la publicación\n"
        "💡 Solo letras, números, _ y -\n"
        "📏 Máximo 50 caracteres\n\n"
        "❌ Escribe /cancel para cancelar",
        buttons=ReplyKeyboardMarkup([
            KeyboardButtonRow([KeyboardButton("❌ Cancelar")])
        ], resize=True)
    )

@bot.on(events.NewMessage(pattern=r'^⏯️ Activar/Pausar$'))
@owner_only
@cooldown_protection("toggle_pub")
async def toggle_publication(ev: events.NewMessage.Event):
    pubs = state.get("pubs", {})
    
    if not pubs:
        await ev.reply(
            "🚀 **No tienes publicaciones**\n\n"
            "✨ Crea una publicación primero",
            buttons=pubs_menu()
        )
        return
    
    # Crear botones inline para seleccionar publicación
    pub_buttons = []
    for name, cfg in pubs.items():
        status = "✅ Activa" if cfg.get("enabled", True) else "⏸️ Pausada"
        pub_buttons.append([Button.inline(f"{status} - {name}", f"toggle_pub:{name}")])
    
    pub_buttons.append([Button.inline("❌ Cancelar", "cancel_toggle_pub")])
    
    await ev.reply(
        "⏯️ **Activar/Pausar Publicación**\n\n"
        "📝 **Selecciona la publicación:**",
        buttons=pub_buttons
    )

@bot.on(events.CallbackQuery(pattern=r'^toggle_pub:(.+)$'))
@owner_only
async def handle_toggle_pub_selection(ev: events.CallbackQuery.Event):
    if not check_cooldown(ev.sender_id, "toggle_pub_action"):
        return
    
    pub_name = ev.data.decode().split(":", 1)[1]
    pubs = state.get("pubs", {})
    
    if pub_name not in pubs:
        await ev.answer("❌ Publicación no encontrada", alert=True)
        return
    
    current_state = pubs[pub_name].get("enabled", True)
    new_state = not current_state
    pubs[pub_name]["enabled"] = new_state
    state["pubs"] = pubs
    save_state(state)
    
    status = "✅ Activada" if new_state else "⏸️ Pausada"
    action_text = "activada" if new_state else "pausada"
    
    await ev.edit(
        f"✅ **Publicación {action_text}**\n\n"
        f"📝 **Nombre:** {pub_name}\n"
        f"📊 **Estado:** {status}",
        buttons=[[Button.inline("🏠 Volver al menú", "back_to_pubs")]]
    )

@bot.on(events.CallbackQuery(pattern=r'^cancel_toggle_pub$'))
@owner_only
async def cancel_toggle_operation(ev: events.CallbackQuery.Event):
    await ev.edit(
        "❌ **Operación cancelada**\n\n"
        "🏠 Regresando al menú de publicaciones",
        buttons=[[Button.inline("🚀 Publicaciones", "back_to_pubs")]]
    )

@bot.on(events.NewMessage(pattern=r'^✏️ Editar Publicación$'))
@owner_only
@cooldown_protection("edit_pub")
async def edit_publication(ev: events.NewMessage.Event):
    pubs = state.get("pubs", {})
    
    if not pubs:
        await ev.reply(
            "🚀 **No tienes publicaciones**\n\n"
            "✨ Crea una publicación primero",
            buttons=pubs_menu()
        )
        return
    
    # Crear botones inline para seleccionar publicación
    pub_buttons = []
    for name, cfg in pubs.items():
        status = "✅" if cfg.get("enabled", True) else "⏸️"
        pub_buttons.append([Button.inline(f"{status} {name}", f"edit_pub:{name}")])
    
    pub_buttons.append([Button.inline("❌ Cancelar", "cancel_edit_pub")])
    
    await ev.reply(
        "✏️ **Editar Publicación**\n\n"
        "📝 **Selecciona la publicación a editar:**",
        buttons=pub_buttons
    )

@bot.on(events.CallbackQuery(pattern=r'^edit_pub:(.+)$'))
@owner_only
async def handle_edit_pub_selection(ev: events.CallbackQuery.Event):
    if not check_cooldown(ev.sender_id, "edit_pub_select"):
        return
    
    pub_name = ev.data.decode().split(":", 1)[1]
    pubs = state.get("pubs", {})
    
    if pub_name not in pubs:
        await ev.answer("❌ Publicación no encontrada", alert=True)
        return
    
    cfg = pubs[pub_name]
    status = "✅ Activa" if cfg.get("enabled", True) else "⏸️ Pausada"
    
    edit_buttons = [
        [Button.inline("📝 Cambiar nombre", f"edit_name:{pub_name}")],
        [Button.inline("🔢 Cambiar mensaje", f"edit_msg:{pub_name}")],
        [Button.inline("🎯 Cambiar lista destino", f"edit_list:{pub_name}")],
        [Button.inline("⏰ Cambiar intervalo", f"edit_interval:{pub_name}")],
        [Button.inline("🏠 Volver al menú", "back_to_pubs")]
    ]
    
    await ev.edit(
        f"✏️ **Editando: {pub_name}**\n\n"
        f"📊 **Estado:** {status}\n"
        f"🔢 **Mensaje ID:** {cfg.get('source_msg_id', 'N/A')}\n"
        f"🎯 **Lista:** {cfg.get('target_list', 'N/A')}\n"
        f"⏰ **Intervalo:** {cfg.get('interval_min', 30)} min\n\n"
        f"📝 **¿Qué quieres editar?**",
        buttons=edit_buttons
    )

@bot.on(events.CallbackQuery(pattern=r'^edit_name:(.+)$'))
@owner_only
async def edit_pub_name(ev: events.CallbackQuery.Event):
    if not check_cooldown(ev.sender_id, "edit_name"):
        return
    
    pub_name = ev.data.decode().split(":", 1)[1]
    
    user_flows[ev.sender_id] = {
        "action": "edit_pub_name",
        "step": "new_name",
        "old_name": pub_name
    }
    
    await ev.edit(
        f"📝 **Cambiar nombre de '{pub_name}'**\n\n"
        f"✏️ **Envía el nuevo nombre:**\n"
        f"💡 Solo letras, números, _ y -\n"
        f"📏 Máximo 50 caracteres",
        buttons=[[Button.inline("❌ Cancelar", "cancel_edit")]]
    )

@bot.on(events.CallbackQuery(pattern=r'^edit_msg:(.+)$'))
@owner_only
async def edit_pub_message(ev: events.CallbackQuery.Event):
    if not check_cooldown(ev.sender_id, "edit_msg"):
        return
    
    pub_name = ev.data.decode().split(":", 1)[1]
    
    # Verificar canal origen
    source_channels = state.get("source_channels", {})
    if not source_channels:
        await ev.answer("❌ No hay canal origen vinculado", alert=True)
        return
    
    channel_id, channel_data = next(iter(source_channels.items()))
    channel_name = channel_data.get('name', f'Canal {channel_id}')
    
    user_flows[ev.sender_id] = {
        "action": "edit_pub_message",
        "step": "new_msg_id",
        "pub_name": pub_name
    }
    
    await ev.edit(
        f"🔢 **Cambiar mensaje de '{pub_name}'**\n\n"
        f"📺 **Canal origen:** {channel_name}\n"
        f"📝 **Envía el nuevo ID del mensaje:**\n"
        f"💡 Ejemplo: Si es t.me/ejemplo/157, envía: 157",
        buttons=[[Button.inline("❌ Cancelar", "cancel_edit")]]
    )

@bot.on(events.CallbackQuery(pattern=r'^edit_list:(.+)$'))
@owner_only
async def edit_pub_list(ev: events.CallbackQuery.Event):
    if not check_cooldown(ev.sender_id, "edit_list"):
        return
    
    pub_name = ev.data.decode().split(":", 1)[1]
    group_lists = state.get("group_lists", {})
    
    list_buttons = []
    for list_name in group_lists.keys():
        list_buttons.append([Button.inline(f"📋 {list_name}", f"select_list_edit:{pub_name}:{list_name}")])
    
    list_buttons.append([Button.inline("📊 TODOS los grupos", f"select_list_edit:{pub_name}:TODOS")])
    list_buttons.append([Button.inline("❌ Cancelar", "cancel_edit")])
    
    await ev.edit(
        f"🎯 **Cambiar lista de '{pub_name}'**\n\n"
        f"📝 **Selecciona la nueva lista:**",
        buttons=list_buttons
    )

@bot.on(events.CallbackQuery(pattern=r'^edit_interval:(.+)$'))
@owner_only
async def edit_pub_interval(ev: events.CallbackQuery.Event):
    if not check_cooldown(ev.sender_id, "edit_interval"):
        return
    
    pub_name = ev.data.decode().split(":", 1)[1]
    
    user_flows[ev.sender_id] = {
        "action": "edit_pub_interval",
        "step": "new_interval",
        "pub_name": pub_name
    }
    
    await ev.edit(
        f"⏰ **Cambiar intervalo de '{pub_name}'**\n\n"
        f"📝 **Envía el nuevo intervalo en minutos:**\n"
        f"⏰ **Mínimo:** 5 minutos\n"
        f"💡 **Recomendado:** 30-60 minutos",
        buttons=[[Button.inline("❌ Cancelar", "cancel_edit")]]
    )

@bot.on(events.CallbackQuery(pattern=r'^select_list_edit:([^:]+):(.+)$'))
@owner_only
async def handle_list_edit_selection(ev: events.CallbackQuery.Event):
    if not check_cooldown(ev.sender_id, "select_list_edit"):
        return
    
    parts = ev.data.decode().split(":", 2)
    pub_name = parts[1]
    list_name = parts[2]
    
    pubs = state.get("pubs", {})
    if pub_name not in pubs:
        await ev.answer("❌ Publicación no encontrada", alert=True)
        return
    
    pubs[pub_name]["target_list"] = list_name
    state["pubs"] = pubs
    save_state(state)
    
    await ev.edit(
        f"✅ **Lista actualizada**\n\n"
        f"📝 **Publicación:** {pub_name}\n"
        f"🎯 **Nueva lista:** {list_name}",
        buttons=[[Button.inline("🏠 Volver al menú", "back_to_pubs")]]
    )

@bot.on(events.CallbackQuery(pattern=r'^cancel_edit_pub$|^cancel_edit$'))
@owner_only
async def cancel_edit_operation(ev: events.CallbackQuery.Event):
    user_flows.pop(ev.sender_id, None)
    await ev.edit(
        "❌ **Operación cancelada**\n\n"
        "🏠 Regresando al menú de publicaciones",
        buttons=[[Button.inline("🚀 Publicaciones", "back_to_pubs")]]
    )

@bot.on(events.CallbackQuery(pattern=r'^back_to_pubs$'))
@owner_only
async def back_to_publications_menu(ev: events.CallbackQuery.Event):
    pubs = state.get("pubs", {})
    active = sum(1 for p in pubs.values() if p.get("enabled", True))
    total = len(pubs)
    
    await ev.edit(
        f"🚀 **Gestión de Publicaciones**\n\n"
        f"📊 **Estadísticas:**\n"
        f"• **Publicaciones:** {total}\n"
        f"• **Activas:** {active}\n"
        f"• **Pausadas:** {total - active}\n\n"
        f"Selecciona una opción:",
        buttons=pubs_menu()
    )

@bot.on(events.NewMessage(pattern=r'^❌ Eliminar Publicación$'))
@owner_only
@cooldown_protection("delete_pub")
async def delete_publication(ev: events.NewMessage.Event):
    pubs = state.get("pubs", {})
    
    if not pubs:
        await ev.reply(
            "🚀 **No tienes publicaciones**\n\n"
            "✨ Crea una publicación primero",
            buttons=pubs_menu()
        )
        return
    
    # Crear botones inline para seleccionar publicación
    pub_buttons = []
    for name, cfg in pubs.items():
        status = "✅" if cfg.get("enabled", True) else "⏸️"
        pub_buttons.append([Button.inline(f"{status} {name}", f"delete_pub:{name}")])
    
    pub_buttons.append([Button.inline("❌ Cancelar", "cancel_delete_pub")])
    
    await ev.reply(
        "❌ **Eliminar Publicación**\n\n"
        "⚠️ **CUIDADO:** Esta acción no se puede deshacer\n"
        "📝 **Selecciona la publicación a eliminar:**",
        buttons=pub_buttons
    )

@bot.on(events.CallbackQuery(pattern=r'^delete_pub:(.+)$'))
@owner_only
async def handle_delete_pub_selection(ev: events.CallbackQuery.Event):
    if not check_cooldown(ev.sender_id, "delete_pub_confirm"):
        return
    
    pub_name = ev.data.decode().split(":", 1)[1]
    pubs = state.get("pubs", {})
    
    if pub_name not in pubs:
        await ev.answer("❌ Publicación no encontrada", alert=True)
        return
    
    del pubs[pub_name]
    state["pubs"] = pubs
    save_state(state)
    
    await ev.edit(
        f"✅ **Publicación eliminada**\n\n"
        f"🗑️ **Nombre:** {pub_name}",
        buttons=[[Button.inline("🏠 Volver al menú", "back_to_pubs")]]
    )

@bot.on(events.CallbackQuery(pattern=r'^cancel_delete_pub$'))
@owner_only
async def cancel_delete_operation(ev: events.CallbackQuery.Event):
    await ev.edit(
        "❌ **Operación cancelada**\n\n"
        "🏠 Regresando al menú de publicaciones",
        buttons=[[Button.inline("🚀 Publicaciones", "back_to_pubs")]]
    )

# ===== MENÚ DE CONFIGURACIÓN =====
@bot.on(events.NewMessage(pattern=r'^⚙️ Configuración$'))
@owner_only
@cooldown_protection("config_menu")
async def config_menu_handler(ev: events.NewMessage.Event):
    tz = state.get("timezone", "UTC")
    quiet_start = state.get("quiet_start", "23:30")
    quiet_end = state.get("quiet_end", "07:00")
    
    await ev.reply(
        f"⚙️ **Configuración del Bot**\n\n"
        f"🌍 **Zona horaria:** {tz}\n"
        f"🌙 **Horario silencioso:** {quiet_start} - {quiet_end}\n\n"
        f"Selecciona una opción:",
        buttons=config_menu()
    )

@bot.on(events.NewMessage(pattern=r'^🌙 Horario Silencioso$'))
@owner_only
@cooldown_protection("config_quiet")
async def config_quiet_hours(ev: events.NewMessage.Event):
    user_flows[ev.sender_id] = {
        "action": "config_quiet",
        "step": "hours"
    }
    
    current_start = state.get("quiet_start", "23:30")
    current_end = state.get("quiet_end", "07:00")
    
    await ev.reply(
        f"🌙 **Configurar Horario Silencioso**\n\n"
        f"🕐 **Actual:** {current_start} - {current_end}\n\n"
        f"📝 **Envía el nuevo horario:**\n"
        f"💡 Formato: HH:MM HH:MM\n"
        f"📝 Ejemplo: 23:30 07:00\n\n"
        f"❌ Escribe /cancel para cancelar",
        buttons=ReplyKeyboardMarkup([
            KeyboardButtonRow([KeyboardButton("❌ Cancelar")])
        ], resize=True)
    )

@bot.on(events.NewMessage(pattern=r'^🌍 Zona Horaria$'))
@owner_only
@cooldown_protection("config_timezone")
async def config_timezone(ev: events.NewMessage.Event):
    user_flows[ev.sender_id] = {
        "action": "config_timezone",
        "step": "timezone"
    }
    
    current_tz = state.get("timezone", "UTC")
    
    await ev.reply(
        f"🌍 **Configurar Zona Horaria**\n\n"
        f"🕐 **Actual:** {current_tz}\n\n"
        f"📝 **Envía la nueva zona horaria:**\n"
        f"💡 Ejemplos:\n"
        f"• UTC\n"
        f"• America/Havana\n"
        f"• Europe/Madrid\n"
        f"• America/New_York\n\n"
        f"❌ Escribe /cancel para cancelar",
        buttons=ReplyKeyboardMarkup([
            KeyboardButtonRow([KeyboardButton("❌ Cancelar")])
        ], resize=True)
    )

# ===== AYUDA =====
@bot.on(events.NewMessage(pattern=r'^❓ Ayuda$'))
@owner_only
@cooldown_protection("help")
async def help_menu(ev: events.NewMessage.Event):
    await ev.reply(
        "❓ **Ayuda del Bot**\n\n"
        "🤖 **Funciones principales:**\n\n"
        "📊 **Estado** - Ver información del bot\n"
        "🔐 **Autenticación** - Gestionar tu sesión\n"
        "📋 **Mis Listas** - Crear y gestionar listas de grupos\n"
        "🚀 **Publicaciones** - Programar envíos automáticos\n"
        "📺 **Canal Origen** - Configurar canal fuente\n"
        "⚙️ **Configuración** - Ajustar horarios y zona\n\n"
        "💡 **Tips:**\n"
        "• Primero auténticate con tu cuenta\n"
        "• Crea listas de grupos para organizar envíos\n"
        "• Configura un canal origen para auto-reenvío\n"
        "• Las publicaciones respetan el horario silencioso\n\n"
        "🔒 **Protección:** El bot previene doble clic automáticamente\n\n"
        "⚠️ Recuerda mantener el respeto y no hacer spam.\n\n"
        "✨ Desarrollado por Francho Shop ✨",
        buttons=[
            [Button.url("📢 Novedades", "https://t.me/ReenvioPlusNews")],
            [Button.url("💬 Soporte", "https://t.me/ReenvioPlusSupport")],
            [Button.url("📂 Canal de ayuda", "https://t.me/ayuda_bot_reenvio")],
            [Button.inline("🏠 Menú Principal", "main_menu")]
        ]
    )

# ===== HANDLERS DE CANCELACIÓN =====
@bot.on(events.NewMessage(pattern=r'^❌ Cancelar$|^❌ Cancelar Login$|^/cancel$'))
@owner_only
@cooldown_protection("cancel")
async def cancel_flow(ev: events.NewMessage.Event):
    user_flows.pop(ev.sender_id, None)
    
    await ev.reply(
        "❌ **Operación cancelada**\n\n"
        "🏠 Regresando al menú principal",
        buttons=main_menu()
    )

# ===== HANDLER DE FLUJOS DE CONVERSACIÓN =====
@bot.on(events.NewMessage())
@owner_only
async def handle_flows(ev: events.NewMessage.Event):
    user_id = ev.sender_id
    text = ev.text.strip()
    
    # Ignorar comandos de botones
    if text.startswith(('📊', '🔐', '📋', '🚀', '📺', '⚙️', '❓', '🏠', '🔑', '📱', '🚪', 
                       '👀', '➕', '📝', '✏️', '🗑️', '✨', '⏯️', '❌', '🔗', '🌙', '🌍')):
        return
    
    # Ignorar comandos /start y /cancel ya manejados
    if text.lower() in ['/start', '/cancel']:
        return
    
    flow = user_flows.get(user_id)
    if not flow:
        return
    
    action = flow.get("action")
    step = flow.get("step")
    
    # === FLUJO DE LOGIN ===
    if action == "login":
        if step == "phone":
            # Validar formato de teléfono básico
            if not re.match(r'^\+?[\d\s\-\(\)]+$', text):
                await ev.reply(
                    "❌ **Formato de teléfono inválido**\n\n"
                    "📱 Usa formato internacional\n"
                    "📝 Ejemplo: +1234567890"
                )
                return
                
            try:
                phone = re.sub(r'[\s\-\(\)]', '', text)
                if not phone.startswith('+'):
                    phone = '+' + phone
                
                flow["phone"] = phone
                flow["step"] = "code"
                
                await user.send_code_request(phone)
                await ev.reply(
                    f"📱 **Código enviado a {text}**\n\n"
                    "🔢 **Paso 2:** Envíame el código que recibiste\n"
                    "💡 Envíalo separado por espacios para mayor seguridad\n"
                    "📝 Ejemplo: Si el código es 12345, envía: 1 2 3 4 5",
                    buttons=ReplyKeyboardMarkup([
                        KeyboardButtonRow([KeyboardButton("❌ Cancelar Login")])
                    ], resize=True)
                )
                
            except Exception as e:
                user_flows.pop(user_id, None)
                await ev.reply(
                    f"❌ **Error enviando código:** {str(e)}\n\n"
                    "🔄 Intenta nuevamente",
                    buttons=auth_menu()
                )
                
        elif step == "code":
            # Procesar código separado por espacios
            code = text.replace(' ', '').replace('-', '').replace('.', '')
            if not code.isdigit():
                await ev.reply(
                    "❌ **Solo números**\n\n"
                    "🔢 Envía solo los números del código\n"
                    "💡 Puedes separarlo por espacios: 1 2 3 4 5\n"
                    "📝 O junto: 12345"
                )
                return
                
            try:
                phone = flow["phone"]
                await user.sign_in(phone, code)
                
                # Login exitoso
                user_flows.pop(user_id, None)
                me = await user.get_me()
                
                await ev.reply(
                    f"✅ **¡Autenticado exitosamente!**\n\n"
                    f"👤 **Conectado como:** @{getattr(me, 'username', '???')}\n"
                    f"🎉 Ya puedes usar todas las funciones",
                    buttons=main_menu()
                )
                
                # Iniciar publicaciones programadas
                asyncio.create_task(run_publications())
                
            except SessionPasswordNeededError:
                # Necesita 2FA
                flow["step"] = "2fa"
                await ev.reply(
                    "🔐 **Autenticación de dos factores requerida**\n\n"
                    "🔑 **Paso 3:** Envía tu contraseña de 2FA\n"
                    "💡 Es la contraseña que configuraste en Telegram",
                    buttons=ReplyKeyboardMarkup([
                        KeyboardButtonRow([KeyboardButton("❌ Cancelar Login")])
                    ], resize=True)
                )
                
            except (PhoneCodeInvalidError, PhoneCodeExpiredError):
                await ev.reply(
                    "❌ **Código incorrecto o expirado**\n\n"
                    "🔄 Intenta nuevamente desde el inicio",
                    buttons=auth_menu()
                )
                user_flows.pop(user_id, None)
                
            except Exception as e:
                user_flows.pop(user_id, None)
                await ev.reply(
                    f"❌ **Error:** {str(e)}\n\n"
                    "🔄 Intenta nuevamente",
                    buttons=auth_menu()
                )
                
        elif step == "2fa":
            try:
                await user.sign_in(password=text)
                
                # Login exitoso con 2FA
                user_flows.pop(user_id, None)
                me = await user.get_me()
                
                await ev.reply(
                    f"✅ **¡Autenticado exitosamente!**\n\n"
                    f"👤 **Conectado como:** @{getattr(me, 'username', '???')}\n"
                    f"🔐 2FA verificado correctamente\n"
                    f"🎉 Ya puedes usar todas las funciones",
                    buttons=main_menu()
                )
                
                # Iniciar publicaciones programadas
                asyncio.create_task(run_publications())
                
            except PasswordHashInvalidError:
                await ev.reply(
                    "❌ **Contraseña 2FA incorrecta**\n\n"
                    "🔄 Intenta nuevamente"
                )
                
            except Exception as e:
                user_flows.pop(user_id, None)
                await ev.reply(
                    f"❌ **Error:** {str(e)}\n\n"
                    "🔄 Intenta nuevamente",
                    buttons=auth_menu()
                )
    
    # === FLUJO DE CREAR LISTA ===
    elif action == "create_list" and step == "name":
        if len(text) > 50 or not text.replace('_', '').replace('-', '').isalnum():
            await ev.reply(
                "❌ **Nombre inválido**\n\n"
                "💡 Usa solo letras, números, _ y -\n"
                "📏 Máximo 50 caracteres"
            )
            return
        
        # Verificar si ya existe
        group_lists = state.get("group_lists", {})
        if text in group_lists:
            await ev.reply(
                f"❌ **La lista '{text}' ya existe**\n\n"
                "💡 Usa un nombre diferente"
            )
            return
        
        # Crear lista vacía
        group_lists[text] = []
        state["group_lists"] = group_lists
        save_state(state)
        
        user_flows.pop(user_id, None)
        await ev.reply(
            f"✅ **Lista creada exitosamente**\n\n"
            f"📋 **Nombre:** {text}\n"
            f"📊 **Grupos:** 0\n\n"
            f"💡 Usa 'Agregar IDs' para añadir grupos",
            buttons=lists_menu()
        )
    
    # === FLUJO DE AGREGAR IDS ===
    elif action == "add_ids":
        if step == "list_selection":
            group_lists = state.get("group_lists", {})
            if text not in group_lists:
                await ev.reply(
                    f"❌ **Lista '{text}' no encontrada**\n\n"
                    "💡 Verifica el nombre exacto"
                )
                return
            
            flow["selected_list"] = text
            flow["step"] = "ids_input"
            
            await ev.reply(
                f"📝 **Agregar IDs a '{text}'**\n\n"
                f"📊 **Grupos actuales:** {len(group_lists[text])}\n\n"
                f"💡 **Envía los IDs separados por espacios o líneas:**\n"
                f"📝 Ejemplo: -1001234567890 -1009876543210\n"
                f"🔢 También puedes enviar uno por línea"
            )
            
        elif step == "ids_input":
            # Parsear IDs del texto
            ids = []
            for line in text.split('\n'):
                for part in line.split():
                    part = part.strip()
                    if part.lstrip('-').isdigit():
                        ids.append(int(part))
            
            if not ids:
                await ev.reply(
                    "❌ **No se encontraron IDs válidos**\n\n"
                    "💡 Envía números enteros (IDs de grupos)\n"
                    "📝 Ejemplo: -1001234567890"
                )
                return
            
            list_name = flow["selected_list"]
            group_lists = state.get("group_lists", {})
            current_ids = set(group_lists[list_name])
            new_ids = [id for id in ids if id not in current_ids]
            
            if new_ids:
                group_lists[list_name].extend(new_ids)
                state["group_lists"] = group_lists
                save_state(state)
                
                user_flows.pop(user_id, None)
                await ev.reply(
                    f"✅ **IDs agregados exitosamente**\n\n"
                    f"📋 **Lista:** {list_name}\n"
                    f"➕ **Nuevos:** {len(new_ids)}\n"
                    f"📊 **Total:** {len(group_lists[list_name])}\n\n"
                    f"🆔 **Agregados:** {', '.join(f'`{id}`' for id in new_ids[:5])}"
                    f"{'...' if len(new_ids) > 5 else ''}",
                    buttons=lists_menu()
                )
            else:
                user_flows.pop(user_id, None)
                await ev.reply(
                    f"⚠️ **Todos los IDs ya estaban en la lista**\n\n"
                    f"📋 **Lista:** {list_name}\n"
                    f"📊 **Total:** {len(group_lists[list_name])}",
                    buttons=lists_menu()
                )
    
    # === FLUJO DE RENOMBRAR LISTA ===
    elif action == "rename_list":
        if step == "list_selection":
            group_lists = state.get("group_lists", {})
            if text not in group_lists:
                await ev.reply(
                    f"❌ **Lista '{text}' no encontrada**\n\n"
                    "💡 Verifica el nombre exacto"
                )
                return
            
            flow["old_name"] = text
            flow["step"] = "new_name"
            
            await ev.reply(
                f"✏️ **Renombrar '{text}'**\n\n"
                f"📝 **Envía el nuevo nombre:**\n"
                f"💡 Solo letras, números, _ y -\n"
                f"📏 Máximo 50 caracteres"
            )
            
        elif step == "new_name":
            if len(text) > 50 or not text.replace('_', '').replace('-', '').isalnum():
                await ev.reply(
                    "❌ **Nombre inválido**\n\n"
                    "💡 Usa solo letras, números, _ y -\n"
                    "📏 Máximo 50 caracteres"
                )
                return
            
            group_lists = state.get("group_lists", {})
            if text in group_lists:
                await ev.reply(
                    f"❌ **La lista '{text}' ya existe**\n\n"
                    "💡 Usa un nombre diferente"
                )
                return
            
            old_name = flow["old_name"]
            group_lists[text] = group_lists.pop(old_name)
            state["group_lists"] = group_lists
            save_state(state)
            
            user_flows.pop(user_id, None)
            await ev.reply(
                f"✅ **Lista renombrada exitosamente**\n\n"
                f"📝 **Antes:** {old_name}\n"
                f"📝 **Ahora:** {text}\n"
                f"📊 **Grupos:** {len(group_lists[text])}",
                buttons=lists_menu()
            )
    
    # === FLUJO DE BORRAR LISTA ===
    elif action == "delete_list" and step == "list_selection":
        group_lists = state.get("group_lists", {})
        if text not in group_lists:
            await ev.reply(
                f"❌ **Lista '{text}' no encontrada**\n\n"
                "💡 Verifica el nombre exacto"
            )
            return
        
        group_count = len(group_lists[text])
        del group_lists[text]
        state["group_lists"] = group_lists
        save_state(state)
        
        user_flows.pop(user_id, None)
        await ev.reply(
            f"✅ **Lista eliminada exitosamente**\n\n"
            f"🗑️ **Lista:** {text}\n"
            f"📊 **Tenía:** {group_count} grupos",
            buttons=lists_menu()
        )
    
    # === FLUJO DE CREAR PUBLICACIÓN ===
    elif action == "create_publication":
        if step == "name":
            if len(text) > 50 or not text.replace('_', '').replace('-', '').isalnum():
                await ev.reply(
                    "❌ **Nombre inválido**\n\n"
                    "💡 Usa solo letras, números, _ y -\n"
                    "📏 Máximo 50 caracteres"
                )
                return
            
            pubs = state.get("pubs", {})
            if text in pubs:
                await ev.reply(
                    f"❌ **La publicación '{text}' ya existe**\n\n"
                    "💡 Usa un nombre diferente"
                )
                return
            
            flow["pub_name"] = text
            flow["step"] = "source_message"
            
            # Verificar que hay canal origen antes de continuar
            source_channels = state.get("source_channels", {})
            if not source_channels:
                user_flows.pop(user_id, None)
                await ev.reply(
                    "❌ **No hay canal origen vinculado**\n\n"
                    "🔗 **Primero debes vincular un canal origen:**\n"
                    "1️⃣ Ve a 'Canal Origen'\n"
                    "2️⃣ Usa 'Vincular Origen'\n"
                    "3️⃣ Después regresa a crear la publicación\n\n"
                    "💡 El canal origen es de donde se tomarán los mensajes",
                    buttons=pubs_menu()
                )
                return
            
            # Obtener info del canal origen
            channel_id, channel_data = next(iter(source_channels.items()))
            channel_name = channel_data.get('name', f'Canal {channel_id}')
            
            await ev.reply(
                f"✨ **Crear '{text}'**\n\n"
                f"📝 **Paso 2:** Envía el ID del mensaje a publicar\n\n"
                f"📺 **Canal origen:** {channel_name}\n"
                f"🔢 **Solo envía el número del mensaje**\n"
                f"💡 **Ejemplo:** Si el enlace es t.me/ejemplo/157, envía: 157"
            )
            
        elif step == "source_message":
            # Verificar que hay canal origen vinculado
            source_channels = state.get("source_channels", {})
            if not source_channels:
                user_flows.pop(user_id, None)
                await ev.reply(
                    "❌ **No hay canal origen vinculado**\n\n"
                    "🔗 **Primero debes vincular un canal origen:**\n"
                    "1️⃣ Ve a 'Canal Origen'\n"
                    "2️⃣ Usa 'Vincular Origen'\n"
                    "3️⃣ Después regresa a crear la publicación\n\n"
                    "💡 El canal origen es de donde se tomarán los mensajes",
                    buttons=pubs_menu()
                )
                return
            
            # Obtener el canal origen (solo hay uno)
            channel_id, channel_data = next(iter(source_channels.items()))
            chat_id = int(channel_id)
            
            # Parsear solo el ID del mensaje
            if not text.isdigit():
                await ev.reply(
                    "❌ **Solo números**\n\n"
                    "🔢 **Envía solo el ID del mensaje**\n"
                    f"📺 **Canal origen:** {channel_data.get('name', 'Canal')}\n"
                    f"💡 **Ejemplo:** Si el enlace es t.me/ejemplo/157, envía: 157"
                )
                return
            
            msg_id = int(text)
            
            # Verificar que el mensaje existe
            test_msg = await get_message_safely(user, chat_id, msg_id)
            if not test_msg:
                await ev.reply(
                    f"❌ **Mensaje no encontrado**\n\n"
                    f"📺 **Canal:** {channel_data.get('name', 'Canal')}\n"
                    f"🆔 **Mensaje ID:** {msg_id}\n\n"
                    f"💡 **Verifica que:**\n"
                    f"• El mensaje existe en el canal\n"
                    f"• No ha sido eliminado\n"
                    f"• Tienes acceso al canal"
                )
                return
            
            flow["source_chat_id"] = chat_id
            flow["source_msg_id"] = msg_id
            flow["step"] = "target_list"
            
            # Mostrar listas disponibles con botones inline
            group_lists = state.get("group_lists", {})
            
            list_buttons = []
            for list_name in group_lists.keys():
                count = len(group_lists[list_name])
                list_buttons.append([Button.inline(f"📋 {list_name} ({count} grupos)", f"select_list_create:{list_name}")])
            
            list_buttons.append([Button.inline("📊 TODOS los grupos", f"select_list_create:TODOS")])
            list_buttons.append([Button.inline("❌ Cancelar", "cancel_create_pub")])
            
            await ev.reply(
                f"✅ **Mensaje verificado**\n\n"
                f"🆔 **Mensaje ID:** {msg_id}\n"
                f"📺 **Canal:** {channel_data.get('name', 'Canal')}\n\n"
                f"✨ **Paso 3: Selecciona lista de destino**\n\n"
                f"📝 **¿A qué lista enviar?**",
                buttons=list_buttons
            )
            
        elif step == "target_list":
            # Este paso ahora se maneja automáticamente arriba
            pass
            
        elif step == "interval":
            try:
                interval = int(text)
                if interval < 5:
                    await ev.reply(
                        "❌ **Intervalo muy corto**\n\n"
                        "⏰ Mínimo 5 minutos"
                    )
                    return
            except ValueError:
                await ev.reply(
                    "❌ **Número inválido**\n\n"
                    "🔢 Envía solo números enteros"
                )
                return
            
            # Crear publicación
            pub_name = flow["pub_name"]
            pub_config = {
                "source_chat_id": flow["source_chat_id"],
                "source_msg_id": flow["source_msg_id"],
                "target_list": flow["target_list"],
                "interval_min": interval,
                "delay_base": 2.0,
                "enabled": True,
                "created": tznow().isoformat()
            }
            
            pubs = state.get("pubs", {})
            pubs[pub_name] = pub_config
            state["pubs"] = pubs
            save_state(state)
            
            user_flows.pop(user_id, None)
            await ev.reply(
                f"✅ **Publicación creada exitosamente**\n\n"
                f"📝 **Nombre:** {pub_name}\n"
                f"🎯 **Lista:** {flow['target_list']}\n"
                f"⏰ **Intervalo:** {interval} minutos\n"
                f"📊 **Estado:** ✅ Activa\n\n"
                f"🚀 La publicación iniciará automáticamente",
                buttons=pubs_menu()
            )
    
    # === FLUJOS DE EDICIÓN DE PUBLICACIONES ===
    elif action == "edit_pub_name" and step == "new_name":
        if len(text) > 50 or not text.replace('_', '').replace('-', '').isalnum():
            await ev.reply(
                "❌ **Nombre inválido**\n\n"
                "💡 Usa solo letras, números, _ y -\n"
                "📏 Máximo 50 caracteres"
            )
            return
        
        old_name = flow["old_name"]
        pubs = state.get("pubs", {})
        
        if text in pubs and text != old_name:
            await ev.reply(
                f"❌ **La publicación '{text}' ya existe**\n\n"
                "💡 Usa un nombre diferente"
            )
            return
        
        # Renombrar publicación
        pubs[text] = pubs.pop(old_name)
        state["pubs"] = pubs
        save_state(state)
        
        user_flows.pop(user_id, None)
        await ev.reply(
            f"✅ **Nombre actualizado**\n\n"
            f"📝 **Antes:** {old_name}\n"
            f"📝 **Ahora:** {text}",
            buttons=[[Button.inline("🏠 Volver al menú", "back_to_pubs")]]
        )
    
    elif action == "edit_pub_message" and step == "new_msg_id":
        if not text.isdigit():
            await ev.reply(
                "❌ **Solo números**\n\n"
                "🔢 **Envía solo el ID del mensaje**\n"
                "💡 **Ejemplo:** Si es t.me/ejemplo/157, envía: 157"
            )
            return
        
        pub_name = flow["pub_name"]
        msg_id = int(text)
        
        # Verificar que el mensaje existe
        source_channels = state.get("source_channels", {})
        channel_id, _ = next(iter(source_channels.items()))
        chat_id = int(channel_id)
        
        test_msg = await get_message_safely(user, chat_id, msg_id)
        if not test_msg:
            await ev.reply(
                f"❌ **Mensaje no encontrado**\n\n"
                f"🆔 **Mensaje ID:** {msg_id}\n\n"
                f"💡 **Verifica que:**\n"
                f"• El mensaje existe en el canal\n"
                f"• No ha sido eliminado\n"
                f"• Tienes acceso al canal"
            )
            return
        
        # Actualizar mensaje
        pubs = state.get("pubs", {})
        pubs[pub_name]["source_msg_id"] = msg_id
        state["pubs"] = pubs
        save_state(state)
        
        user_flows.pop(user_id, None)
        await ev.reply(
            f"✅ **Mensaje actualizado**\n\n"
            f"📝 **Publicación:** {pub_name}\n"
            f"🔢 **Nuevo mensaje ID:** {msg_id}",
            buttons=[[Button.inline("🏠 Volver al menú", "back_to_pubs")]]
        )
    
    elif action == "edit_pub_interval" and step == "new_interval":
        try:
            interval = int(text)
            if interval < 5:
                await ev.reply(
                    "❌ **Intervalo muy corto**\n\n"
                    "⏰ Mínimo 5 minutos"
                )
                return
        except ValueError:
            await ev.reply(
                "❌ **Número inválido**\n\n"
                "🔢 Envía solo números enteros"
            )
            return
        
        pub_name = flow["pub_name"]
        
        # Actualizar intervalo
        pubs = state.get("pubs", {})
        pubs[pub_name]["interval_min"] = interval
        state["pubs"] = pubs
        save_state(state)
        
        user_flows.pop(user_id, None)
        await ev.reply(
            f"✅ **Intervalo actualizado**\n\n"
            f"📝 **Publicación:** {pub_name}\n"
            f"⏰ **Nuevo intervalo:** {interval} minutos",
            buttons=[[Button.inline("🏠 Volver al menú", "back_to_pubs")]]
        )
    
    # === FLUJOS DE SELECCIONES YA SE MANEJAN CON BOTONES INLINE ===
    
    # === FLUJO DE CONFIGURAR QUIET HOURS ===
    elif action == "config_quiet" and step == "hours":
        try:
            parts = text.split()
            if len(parts) != 2:
                raise ValueError("Formato incorrecto")
            
            start_time, end_time = parts
            # Validar formato HH:MM
            dt.datetime.strptime(start_time, "%H:%M")
            dt.datetime.strptime(end_time, "%H:%M")
            
            state["quiet_start"] = start_time
            state["quiet_end"] = end_time
            save_state(state)
            
            user_flows.pop(user_id, None)
            await ev.reply(
                f"✅ **Horario silencioso actualizado**\n\n"
                f"🌙 **Nuevo horario:** {start_time} - {end_time}\n\n"
                f"💡 Durante este horario no se enviarán publicaciones",
                buttons=config_menu()
            )
            
        except ValueError:
            await ev.reply(
                "❌ **Formato incorrecto**\n\n"
                "💡 Usa el formato: HH:MM HH:MM\n"
                "📝 Ejemplo: 23:30 07:00"
            )
    
    # === FLUJO DE CONFIGURAR TIMEZONE ===
    elif action == "config_timezone" and step == "timezone":
        try:
            if ZoneInfo:
                # Verificar que la zona horaria sea válida
                test_tz = ZoneInfo(text)
                state["timezone"] = text
            else:
                state["timezone"] = text
            
            save_state(state)
            
            user_flows.pop(user_id, None)
            await ev.reply(
                f"✅ **Zona horaria actualizada**\n\n"
                f"🌍 **Nueva zona:** {text}\n\n"
                f"💡 Los horarios ahora se mostrarán en esta zona",
                buttons=config_menu()
            )
            
        except Exception:
            await ev.reply(
                "❌ **Zona horaria inválida**\n\n"
                "💡 Usa formatos como:\n"
                "• UTC\n"
                "• America/Havana\n"
                "• Europe/Madrid"
            )
    
    # === FLUJO DE VINCULAR CANAL ORIGEN ===
    elif action == "link_source_channel" and step == "channel_input":
        # Verificar si es un mensaje reenviado
        if hasattr(ev.message, 'fwd_from') and ev.message.fwd_from:
            try:
                # Obtener información del mensaje reenviado
                fwd_from = ev.message.fwd_from
                
                # Obtener el chat/canal de origen
                if hasattr(fwd_from, 'from_id') and fwd_from.from_id:
                    if hasattr(fwd_from.from_id, 'channel_id'):
                        channel_id = int(f"-100{fwd_from.from_id.channel_id}")
                    elif hasattr(fwd_from.from_id, 'chat_id'):
                        channel_id = -fwd_from.from_id.chat_id
                    else:
                        raise ValueError("No se pudo obtener ID del canal")
                else:
                    raise ValueError("Mensaje reenviado sin información de origen")
                
                # Obtener información del canal
                try:
                    channel_entity = await user.get_entity(channel_id)
                    channel_title = getattr(channel_entity, 'title', f'Canal {channel_id}')
                except:
                    channel_title = f'Canal {channel_id}'
                
                # Guardar como canal único (reemplazar cualquier existente)
                state["source_channels"] = {
                    str(channel_id): {
                        "name": channel_title,
                        "added_date": tznow().isoformat(),
                        "last_changed": tznow().isoformat()
                    }
                }
                save_state(state)
                
                user_flows.pop(user_id, None)
                await ev.reply(
                    f"✅ **Canal vinculado exitosamente**\n\n"
                    f"📺 **Nombre:** {channel_title}\n"
                    f"🆔 **ID:** `{channel_id}`\n"
                    f"📅 **Fecha:** {tznow().strftime('%d/%m/%Y %H:%M')}\n\n"
                    f"🎉 El canal está listo para usar",
                    buttons=source_channels_menu()
                )
                return
                
            except Exception as e:
                await ev.reply(
                    f"❌ **Error al procesar mensaje reenviado**\n\n"
                    f"**Error:** {str(e)}\n\n"
                    f"💡 Intenta reenviar un mensaje del canal o usa un enlace/ID"
                )
                return
        
        # Si no es mensaje reenviado, procesar como enlace/ID
        try:
            channel_entity = None
            channel_id = None
            
            # Si es un ID numérico
            if text.lstrip('-').isdigit():
                channel_id = int(text)
                try:
                    channel_entity = await user.get_entity(channel_id)
                except Exception as e:
                    await ev.reply(
                        f"❌ **No se pudo acceder al canal**\n\n"
                        f"**Error:** Could not find the input entity - Canal no encontrado\n\n"
                        f"📝 Verifica que:\n"
                        f"• El ID sea correcto: `{channel_id}`\n"
                        f"• Tengas acceso al canal\n"
                        f"• El canal exista y esté activo",
                        buttons=source_channels_menu()
                    )
                    user_flows.pop(user_id, None)
                    return
            # Si es username o enlace
            elif text.startswith('@') or 'https://t.me/' in text:
                username = text.replace('@', '').replace('https://t.me/', '')
                try:
                    channel_entity = await user.get_entity(username)
                    channel_id = channel_entity.id
                except Exception as e:
                    await ev.reply(
                        f"❌ **No se pudo acceder al canal**\n\n"
                        f"**Error:** {str(e)}\n\n"
                        f"📝 Verifica que:\n"
                        f"• El username/enlace sea correcto: `{username}`\n"
                        f"• Tengas acceso al canal\n"
                        f"• El canal exista y sea público",
                        buttons=source_channels_menu()
                    )
                    user_flows.pop(user_id, None)
                    return
            else:
                await ev.reply(
                    "❌ **Formato inválido**\n\n"
                    "💡 Puedes:\n"
                    "1️⃣ **Reenviar** un mensaje del canal\n"
                    "2️⃣ **Enviar** un enlace/ID:\n"
                    "   • `-1001234567890`\n"
                    "   • `@nombre_canal`\n"
                    "   • `https://t.me/nombre_canal`"
                )
                return
            
            # Obtener información del canal
            channel_title = getattr(channel_entity, 'title', f'Canal {channel_id}')
            
            # Guardar como canal único (reemplazar cualquier existente)
            state["source_channels"] = {
                str(channel_id): {
                    "name": channel_title,
                    "added_date": tznow().isoformat(),
                    "last_changed": tznow().isoformat()
                }
            }
            save_state(state)
            
            user_flows.pop(user_id, None)
            await ev.reply(
                f"✅ **Canal vinculado exitosamente**\n\n"
                f"📺 **Nombre:** {channel_title}\n"
                f"🆔 **ID:** `{channel_id}`\n"
                f"📅 **Fecha:** {tznow().strftime('%d/%m/%Y %H:%M')}\n\n"
                f"🎉 El canal está listo para usar",
                buttons=source_channels_menu()
            )
            
        except Exception as e:
            print(f"Error en link_source_channel: {e}")
            await ev.reply(
                f"❌ **Error inesperado**\n\n"
                f"Por favor intenta nuevamente o contacta soporte",
                buttons=source_channels_menu()
            )
            user_flows.pop(user_id, None)

# ===== EVENTOS DE AUTO-FORWARD DESDE CANAL ORIGEN =====
@user.on(events.NewMessage())
async def auto_forward_handler(ev: events.NewMessage.Event):
    """
    Maneja el reenvío automático desde el canal origen configurado
    """
    try:
        # Solo procesar si el auto-forward está habilitado
        if not state.get("auto_forward_enabled", True):
            return
        
        # Verificar si es del canal origen configurado
        source_channels = state.get("source_channels", {})
        if not source_channels or str(ev.chat_id) not in source_channels:
            return
        
        # Respetar quiet hours
        now = tznow()
        if in_quiet_hours(now.time()):
            return
        
        # Obtener todos los grupos destino
        all_targets = []
        group_lists = state.get("group_lists", {})
        for group_list in group_lists.values():
            all_targets.extend(group_list)
        
        # Eliminar duplicados
        all_targets = list(set(all_targets))
        
        if not all_targets:
            return
        
        # Reenviar con delay aleatorio
        random.shuffle(all_targets)
        for target_id in all_targets:
            try:
                await copy_as_user(user, ev.message, target_id)
                await asyncio.sleep(1 + random.random())  # Delay entre envíos
            except Exception as e:
                print(f"[auto_forward_error] {target_id}: {e}")
        
        print(f"[auto_forward] Mensaje de {ev.chat_id} reenviado a {len(all_targets)} grupos")
        
    except Exception as e:
        print(f"[auto_forward_handler_error] {e}")

# ===== INICIALIZACIÓN Y MAIN =====
async def main():
    try:
        print("🤖 Iniciando bot...")
        
        # Conectar clientes
        await bot.start(bot_token=BOT_TOKEN)
        if not user.is_connected():
            await user.connect()
        
        print("✅ Bot conectado")
        print(f"📊 Publicaciones: {len(state.get('pubs', {}))}")
        has_channel = "Sí" if state.get('source_channels', {}) else "No"
        print(f"📺 Canal origen: {has_channel}")
        print(f"📋 Listas: {len(state.get('group_lists', {}))}")
        print(f"🔒 Protección anti-doble clic: ACTIVA ({COOLDOWN_SECONDS}s)")
        
        # Iniciar scheduler de publicaciones
        asyncio.create_task(run_publications())
        
        print("🚀 Sistema iniciado - Escuchando mensajes...")
        await bot.run_until_disconnected()
        
    except Exception as e:
        print(f"Error en main: {e}")
    finally:
        if user.is_connected():
            await user.disconnect()

# ===== CALLBACKS ADICIONALES =====
@bot.on(events.CallbackQuery(pattern=r'^main_menu$'))
@owner_only
async def handle_main_menu(ev: events.CallbackQuery.Event):
    await ev.edit(
        "🏠 **Menú Principal**\n\n"
        "🤖 **¡Bienvenido al Bot de Reenvío!**\n\n"
        "📊 **Opciones disponibles:**",
        buttons=[
        [Button.text("📊 Estado", resize=True), Button.text("🔐 Autenticación", resize=True)],
        [Button.text("📋 Mis Listas", resize=True), Button.text("🚀 Publicaciones", resize=True)],
        [Button.text("📺 Canal Origen", resize=True), Button.text("⚙️ Configuración", resize=True)],
        [Button.text("❓ Ayuda", resize=True)]
    ]
    )


@bot.on(events.CallbackQuery(pattern=r'^select_list_create:(.+)$'))
@owner_only
async def handle_list_create_selection(ev: events.CallbackQuery.Event):
    list_name = ev.data.decode().split(":", 1)[1]
    user_id = ev.sender_id
    
    flow = user_flows.get(user_id)
    if not flow or flow.get("action") != "create_publication":
        await ev.answer("❌ Sesión expirada", alert=True)
        return
    
    flow["target_list"] = list_name
    flow["step"] = "interval"
    user_flows[user_id] = flow
    
    await ev.edit(
        f"✨ **Lista configurada: {list_name}**\n\n"
        f"📝 **Paso 4:** Intervalo en minutos\n"
        f"⏰ **Mínimo:** 5 minutos\n"
        f"💡 **Recomendado:** 30-60 minutos\n\n"
        f"📝 **Envía el intervalo:**",
        buttons=[[Button.inline("❌ Cancelar", "cancel_create_pub")]]
    )

@bot.on(events.CallbackQuery(pattern=r'^cancel_create_pub$'))
@owner_only
async def cancel_create_publication(ev: events.CallbackQuery.Event):
    user_flows.pop(ev.sender_id, None)
    await ev.edit(
        "❌ **Creación cancelada**\n\n"
        "🏠 Regresando al menú de publicaciones",
        buttons=pubs_menu()
    )

if __name__ == "__main__":
    asyncio.run(main())