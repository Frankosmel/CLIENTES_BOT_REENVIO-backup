print("START: text-fix v2")

import os, json, asyncio, re, random, datetime as dt
from pathlib import Path
from typing import Dict, Any, List, Optional

from telethon import TelegramClient, events, Button, types
from telethon.tl.types import ReplyKeyboardMarkup, KeyboardButton, KeyboardButtonRow
from telethon.errors import (
    PhoneNumberInvalidError, SessionPasswordNeededError, PasswordHashInvalidError,
    PhoneCodeInvalidError, PhoneCodeExpiredError, FloodWaitError, RPCError
)

# ----- Carga de .env (forzado desde este directorio) -----
from pathlib import Path as _P
from dotenv import load_dotenv
load_dotenv(dotenv_path=_P(__file__).with_name(".env"), override=True)

# ----- Config básica -----
API_ID    = int(os.getenv("API_ID", "0"))
API_HASH  = os.getenv("API_HASH", "")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
OWNER_ID  = int(os.getenv("OWNER_ID", "0"))

USER_SESSION = os.getenv("USER_SESSION", "user")
BOT_SESSION  = os.getenv("BOT_SESSION",  "panelbot")
STATE_FILE   = Path(os.getenv("STATE_FILE", "state.json"))

# Zona horaria / quiet hours
try:
    from zoneinfo import ZoneInfo
except Exception:
    ZoneInfo = None

DEFAULT_STATE: Dict[str, Any] = {
    "quiet_start": os.getenv("QUIET_START", "23:30"),
    "quiet_end":   os.getenv("QUIET_END",   "07:00"),
    "timezone":    os.getenv("TIMEZONE",    "UTC"),
    "group_lists": {},   # nombre -> [chat_id,...]
    "pubs": {},  # nombre -> cfg
    "scheduled_pubs": {},  # nombre -> cfg (publicaciones por horario)
    "last_runs": {},     # nombre -> ISO
    "last_scheduled_runs": {},  # nombre -> ISO (para horarios)
    "last_seen_id": 0,
    "source_channels": {},  # SOLO UN CANAL: id -> {name, added_date, last_changed}
    "auto_forward_enabled": True,  # Si está habilitado el reenvío automático
}

state: Dict[str, Any] = {}

def load_state() -> Dict[str, Any]:
    if STATE_FILE.exists():
        try:
            data = json.loads(STATE_FILE.read_text())
            # Migrar estado viejo al nuevo formato si es necesario
            if "source_channels" not in data:
                data["source_channels"] = {}
            if "auto_forward_enabled" not in data:
                data["auto_forward_enabled"] = True
            if "scheduled_pubs" not in data:
                data["scheduled_pubs"] = {}
            if "last_scheduled_runs" not in data:
                data["last_scheduled_runs"] = {}
            return data
        except Exception:
            pass
    STATE_FILE.write_text(json.dumps(DEFAULT_STATE, ensure_ascii=False, indent=2))
    return json.loads(STATE_FILE.read_text())

def save_state(s: Dict[str, Any]):
    STATE_FILE.write_text(json.dumps(s, ensure_ascii=False, indent=2))

state = load_state()

# --- MIGRACIÓN publications -> pubs (una sola clave) ---
try:
    if state.get("publications") and not state.get("pubs"):
        state["pubs"] = state.get("publications", {})
        save_state(state)
except Exception:
    pass

# ----- Utilidades de tiempo -----
def _tz():
    tzname = state.get("timezone", "UTC")
    if ZoneInfo:
        try:
            return ZoneInfo(tzname)
        except Exception:
            return ZoneInfo("UTC")
    return None

def tznow() -> dt.datetime:
    tz = _tz()
    return dt.datetime.now(tz) if tz else dt.datetime.utcnow()

def in_quiet_hours(now_local: dt.time) -> bool:
    qs = dt.datetime.strptime(state["quiet_start"], "%H:%M").time()
    qe = dt.datetime.strptime(state["quiet_end"],   "%H:%M").time()
    if qs < qe:
        return qs <= now_local < qe
    # cruce de medianoche
    return now_local >= qs or now_local < qe

# ----- Parser de lenguaje natural para horarios -----
def parse_natural_schedule(text: str) -> Optional[Dict[str, Any]]:
    """
    Parsea frases naturales para horarios:
    - "todos los lunes a las 7" -> {type: "weekly", day: 0, hour: 7, minute: 0}
    - "hoy a las 8" -> {type: "once", datetime: ...}
    - "mañana a las 9" -> {type: "once", datetime: ...}
    - "todos los días a las 11" -> {type: "daily", hour: 11, minute: 0}
    - "cada 30 minutos" -> {type: "interval", minutes: 30}
    """
    text = text.lower().strip()
    
    # Días de la semana
    days_map = {
        "lunes": 0, "martes": 1, "miércoles": 2, "miercoles": 2,
        "jueves": 3, "viernes": 4, "sábado": 5, "sabado": 5, "domingo": 6
    }
    
    # Extraer hora (formato "a las HH" o "a las HH:MM")
    hour_match = re.search(r'a las? (\d{1,2})(?::(\d{2}))?', text)
    hour = int(hour_match.group(1)) if hour_match else 0
    minute = int(hour_match.group(2)) if hour_match and hour_match.group(2) else 0
    
    # "todos los días a las X"
    if "todos los días" in text or "todos los dias" in text or "cada día" in text or "cada dia" in text:
        if hour_match:
            return {"type": "daily", "hour": hour, "minute": minute}
    
    # "todos los [día] a las X"
    for day_name, day_num in days_map.items():
        if f"todos los {day_name}" in text or f"cada {day_name}" in text:
            if hour_match:
                return {"type": "weekly", "day": day_num, "hour": hour, "minute": minute}
    
    # "hoy a las X"
    if "hoy" in text and hour_match:
        now = tznow()
        target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if target <= now:
            target += dt.timedelta(days=1)
        return {"type": "once", "datetime": target.isoformat()}
    
    # "mañana a las X"
    if ("mañana" in text or "manana" in text) and hour_match:
        now = tznow()
        target = (now + dt.timedelta(days=1)).replace(hour=hour, minute=minute, second=0, microsecond=0)
        return {"type": "once", "datetime": target.isoformat()}
    
    # "cada X minutos"
    interval_match = re.search(r'cada (\d+) minutos?', text)
    if interval_match:
        minutes = int(interval_match.group(1))
        return {"type": "interval", "minutes": minutes}
    
    return None

def should_run_scheduled(schedule: Dict[str, Any], last_run: Optional[str]) -> bool:
    """Determina si una publicación programada debe ejecutarse ahora"""
    now = tznow()
    
    schedule_type = schedule.get("type")
    
    if schedule_type == "once":
        # Ejecutar solo una vez en la fecha/hora especificada
        target_dt = dt.datetime.fromisoformat(schedule["datetime"])
        if last_run:
            return False  # Ya se ejecutó
        return now >= target_dt
    
    elif schedule_type == "daily":
        # Ejecutar todos los días a una hora específica
        hour = schedule.get("hour", 0)
        minute = schedule.get("minute", 0)
        
        # Verificar si es la hora correcta
        if now.hour != hour or now.minute != minute:
            return False
        
        # Verificar última ejecución (no más de una vez por minuto)
        if last_run:
            try:
                last_dt = dt.datetime.fromisoformat(last_run)
                if (now - last_dt).total_seconds() < 60:
                    return False
            except:
                pass
        
        return True
    
    elif schedule_type == "weekly":
        # Ejecutar un día específico de la semana a una hora
        day = schedule.get("day", 0)
        hour = schedule.get("hour", 0)
        minute = schedule.get("minute", 0)
        
        if now.weekday() != day or now.hour != hour or now.minute != minute:
            return False
        
        # Verificar última ejecución
        if last_run:
            try:
                last_dt = dt.datetime.fromisoformat(last_run)
                if (now - last_dt).total_seconds() < 60:
                    return False
            except:
                pass
        
        return True
    
    elif schedule_type == "interval":
        # Ejecutar cada X minutos
        minutes = schedule.get("minutes", 30)
        
        if not last_run:
            return True
        
        try:
            last_dt = dt.datetime.fromisoformat(last_run)
            if (now - last_dt).total_seconds() >= minutes * 60:
                return True
        except:
            return True
        
        return False
    
    return False

# ----- Clientes -----
user = TelegramClient(USER_SESSION, API_ID, API_HASH)
bot  = TelegramClient(BOT_SESSION,  API_ID, API_HASH)

# ===== SISTEMA DE FLUJOS PARA AUTENTICACIÓN Y ASISTENTES =====
user_flows: Dict[int, Dict[str, Any]] = {}

# ----- Decoradores / helpers UI -----
def owner_only(func):
    async def wrapper(ev: events.NewMessage.Event):
        if ev.sender_id != OWNER_ID:
            return await ev.reply("🚫 **Acceso denegado**\n\n❌ Solo el propietario puede usar este bot.")
        return await func(ev)
    return wrapper

# ----- Menús con Reply Keyboard -----
def main_menu():
    """Menú principal con opciones generales"""
    return ReplyKeyboardMarkup([
        KeyboardButtonRow([KeyboardButton("📊 Estado"), KeyboardButton("🔐 Autenticación")]),
        KeyboardButtonRow([KeyboardButton("📋 Mis Listas"), KeyboardButton("🚀 Publicaciones")]),
        KeyboardButtonRow([KeyboardButton("📺 Canal Origen"), KeyboardButton("⚙️ Configuración")]),
        KeyboardButtonRow([KeyboardButton("❓ Ayuda")])
    ], resize=True)

def auth_menu():
    """Menú de autenticación"""
    return ReplyKeyboardMarkup([
        KeyboardButtonRow([KeyboardButton("🔑 Iniciar Sesión"), KeyboardButton("🚪 Cerrar Sesión")]),
        KeyboardButtonRow([KeyboardButton("🏠 Menú Principal")])
    ], resize=True)

def lists_menu():
    """Menú de gestión de listas"""
    return ReplyKeyboardMarkup([
        KeyboardButtonRow([KeyboardButton("👀 Ver Listas"), KeyboardButton("➕ Nueva Lista")]),
        KeyboardButtonRow([KeyboardButton("📝 Agregar IDs"), KeyboardButton("✏️ Renombrar Lista")]),
        KeyboardButtonRow([KeyboardButton("🗑️ Borrar Lista"), KeyboardButton("🏠 Menú Principal")])
    ], resize=True)

def pubs_menu():
    """Menú de publicaciones"""
    return ReplyKeyboardMarkup([
        KeyboardButtonRow([KeyboardButton("📊 Ver Publicaciones"), KeyboardButton("✨ Crear Nueva")]),
        KeyboardButtonRow([KeyboardButton("⏰ Crear por Horario"), KeyboardButton("📅 Ver Horarios")]),
        KeyboardButtonRow([KeyboardButton("✏️ Editar Publicación"), KeyboardButton("⏯️ Activar/Pausar")]),
        KeyboardButtonRow([KeyboardButton("❌ Eliminar Publicación")]),
        KeyboardButtonRow([KeyboardButton("🏠 Menú Principal")])
    ], resize=True)

def source_channels_menu():
    """Menú de gestión del canal origen único"""
    return ReplyKeyboardMarkup([
        KeyboardButtonRow([KeyboardButton("🔗 Vincular Origen"), KeyboardButton("⏯️ Toggle Auto-Reenvío")]),
        KeyboardButtonRow([KeyboardButton("🗑️ Desvincular Canal"), KeyboardButton("🏠 Menú Principal")])
    ], resize=True)

def config_menu():
    """Menú de configuración"""
    return ReplyKeyboardMarkup([
        KeyboardButtonRow([KeyboardButton("🌙 Horario Silencioso"), KeyboardButton("🌍 Zona Horaria")]),
        KeyboardButtonRow([KeyboardButton("🏠 Menú Principal")])
    ], resize=True)

# ----- Parse helpers mejorados -----
_link_re = re.compile(r"t\.me/c/(\d+)/(\d+)")

def parse_source_ref(txt: str):
    """
    Acepta:
    - Link interno: https://t.me/c/<internal>/<msg>
    - Dos enteros: <chat_id> <msg_id>
    Devuelve (chat_id, msg_id) o None.
    """
    m = _link_re.search(txt)
    if m:
        internal, msg = m.group(1), int(m.group(2))
        chat_id = int(f"-100{internal}")
        return (chat_id, msg)
    parts = re.findall(r"-?\d+", txt)
    if len(parts) >= 2:
        return (int(parts[0]), int(parts[1]))
    return None

# ----- Función mejorada para resolver entidades -----
async def resolve_entity_safely(client: TelegramClient, entity_id, retry_count: int = 3):
    """
    Intenta resolver una entidad de Telegram de forma segura con reintentos
    """
    for attempt in range(retry_count):
        try:
            # Primero intentar obtener la entidad directamente
            return await client.get_input_entity(entity_id)
        except Exception as e:
            if attempt == 0:
                # En el primer intento, intentar obtener el diálogo
                try:
                    async for dialog in client.iter_dialogs():
                        if hasattr(dialog, 'id') and dialog.id == entity_id:
                            return await client.get_input_entity(dialog.entity)
                        elif hasattr(dialog.entity, 'id') and dialog.entity.id == entity_id:
                            return await client.get_input_entity(dialog.entity)
                except Exception:
                    pass
            
            if attempt == retry_count - 1:
                # Último intento: usar el ID directamente si es un chat
                entity_id_str = str(entity_id)
                if entity_id_str.startswith('-100'):
                    return types.InputPeerChannel(
                        channel_id=int(entity_id_str[4:]),
                        access_hash=0
                    )
                elif int(entity_id) < 0:
                    return types.InputPeerChat(chat_id=-int(entity_id))
                else:
                    raise e
            
            # Esperar antes del siguiente intento
            await asyncio.sleep(1)

async def get_message_safely(client: TelegramClient, chat_id: int, msg_id: int):
    """
    Obtiene un mensaje de forma segura con manejo mejorado de errores
    """
    try:
        # Resolver entidad de forma segura
        entity = await resolve_entity_safely(client, chat_id)
        message = await client.get_messages(entity, ids=msg_id)
        return message
    except Exception as e:
        print(f"[ERROR] No se pudo obtener mensaje {msg_id} de {chat_id}: {e}")
        return None

# ----------------- copy_as_user robusto -----------------
async def copy_as_user(client: TelegramClient, msg, target_id: int):
    """
    Copia un mensaje como usuario con manejo mejorado de errores
    """
    try:
        # Resolver destino para evitar "Could not find the input entity"
        target = await resolve_entity_safely(client, target_id)
        
        text = getattr(msg, 'message', '') or getattr(msg, 'text', '') or getattr(msg, "caption", "") or ""
        entities = getattr(msg, 'entities', None)
        media = getattr(msg, 'media', None)

        # Si hay media: re-subir con caption
        if isinstance(media, (types.MessageMediaPhoto, types.MessageMediaDocument)):
            import tempfile
            
            with tempfile.TemporaryDirectory() as td:
                try:
                    f = await client.download_media(msg, file=td)
                except:
                    f = None
                    
                if not f:
                    try:
                        await client.send_message(target, text, formatting_entities=entities, link_preview=False)
                    except Exception:
                        await client.send_message(target, text, link_preview=False)
                    return
                
                try:
                    await client.send_file(target, f, caption=text, formatting_entities=entities)
                except Exception:
                    await client.send_file(target, f, caption=text)  # sin entities
            return

        # Solo texto
        try:
            await client.send_message(target, text, formatting_entities=entities, link_preview=False)
        except Exception as e:
            print(f"[warn] send_message entities failed: {e}; try no-entities")
            await client.send_message(target, text, link_preview=False)
    except Exception as e:
        print(f"[ERROR] copy_as_user failed para {target_id}: {e}")
        raise

# ----------------- Publicaciones programadas mejoradas -----------------
async def run_publications():
    """
    Recorre publicaciones activas, respeta quiet hours, y reenvía con copy_as_user.
    """
    print("DBG: scheduler loop start")
    while True:
        try:
            now = tznow()
            if in_quiet_hours(now.time()):
                await asyncio.sleep(10)
                continue

            pubs = state.get("pubs", {})
            for name, cfg in pubs.items():
                if not cfg.get("enabled", True):
                    continue
                
                # intervalo
                interval_min = int(cfg.get("interval_min", 30))
                delay_base   = float(cfg.get("delay_base", 2.0))

                # control de última ejecución
                last = state.get("last_runs", {}).get(name)
                if last:
                    try:
                        last_dt = dt.datetime.fromisoformat(last)
                    except Exception:
                        last_dt = None
                    if last_dt and (tznow() - last_dt).total_seconds() < interval_min * 60:
                        continue
                
                # origen
                src_chat = int(cfg["source_chat_id"])
                src_msg  = int(cfg["source_msg_id"])
                
                # destino(s)
                target_list = cfg.get("target_list")
                if target_list == "TODOS":
                    targets = await collect_all_groups(user)
                else:
                    targets = state.get("group_lists", {}).get(target_list, [])
                
                # obtiene mensaje original con manejo mejorado
                orig = await get_message_safely(user, src_chat, src_msg)
                if not orig:
                    print(f"[ERROR] No se pudo obtener mensaje para publicación {name}")
                    continue
                    
                # Si orig es una lista, tomar el primer elemento
                if hasattr(orig, '__len__') and not isinstance(orig, str) and len(orig) > 0:
                    orig = orig[0]

                random.shuffle(targets)
                for t in targets:
                    try:
                        await copy_as_user(user, orig, t)
                    except FloodWaitError as fw:
                        print(f"[flood] {t}: wait {fw.seconds}s")
                        await asyncio.sleep(fw.seconds + 2)
                    except Exception as e:
                        print(f"[send_error] {t}: {e}")
                    
                    await asyncio.sleep(delay_base + random.random())

                # marca última ejecución
                state.setdefault("last_runs", {})[name] = tznow().isoformat()
                save_state(state)

            await asyncio.sleep(5)
        except Exception as e:
            print("[scheduler_error]", e)
            await asyncio.sleep(5)

async def collect_all_groups(client: TelegramClient) -> List[int]:
    ids: List[int] = []
    try:
        async for d in client.iter_dialogs():
            ent = d.entity
            try:
                if getattr(ent, 'megagroup', False) or ent.__class__.__name__ in ("Chat",):
                    ids.append(ent.id)
            except Exception:
                pass
    except Exception as e:
        print(f"[collect_groups_error] {e}")
    return ids

# ===== COMANDOS CON BOTONES =====

@bot.on(events.NewMessage(pattern=r'^/start$|^🏠 Menú Principal$'))
@owner_only
async def start_cmd(ev: events.NewMessage.Event):
    if not user.is_connected():
        status = "❌ **Desconectado**"
    else:
        try:
            me = await user.get_me()
            status = f"✅ **Conectado** como @{getattr(me, 'username', '???')}"
        except:
            status = "⚠️ **Estado incierto**"

    pubs = state.get("pubs", {})
    active = sum(1 for p in pubs.values() if p.get("enabled", True))
    total = len(pubs)
    
    source_channels = state.get("source_channels", {})
    has_channel = "✅ Vinculado" if source_channels else "❌ Sin vincular"

    await ev.reply(
        f"🤖 **Panel de Control**\n\n"
        f"👤 **Estado:** {status}\n"
        f"📊 **Publicaciones:** {active}/{total} activas\n"
        f"📺 **Canal origen:** {has_channel}\n\n"
        f"Selecciona una opción:",
        buttons=main_menu()
    )

# ===== MENÚ DE ESTADO =====
@bot.on(events.NewMessage(pattern=r'^📊 Estado$'))
@owner_only
async def status_menu(ev: events.NewMessage.Event):
    if not user.is_connected():
        status = "❌ **Desconectado** - Usa 'Iniciar Sesión' para autenticarte"
    else:
        try:
            me = await user.get_me()
            status = f"✅ **Conectado** como @{getattr(me, 'username', '???')}"
        except:
            status = "⚠️ **Estado incierto** - Podrías necesitar reconectarte"

    pubs = state.get("pubs", {})
    active = sum(1 for p in pubs.values() if p.get("enabled", True))
    total = len(pubs)

    tz = state.get("timezone", "UTC")
    quiet_start = state.get("quiet_start", "23:30")
    quiet_end = state.get("quiet_end", "07:00")
    
    auto_forward = "✅ Habilitado" if state.get("auto_forward_enabled", True) else "❌ Deshabilitado"

    await ev.reply(
        f"📊 **Estado Detallado**\n\n"
        f"👤 **Usuario:** {status}\n"
        f"🚀 **Publicaciones:** {active}/{total} activas\n"
        f"📺 **Auto-reenvío:** {auto_forward}\n"
        f"🌍 **Zona horaria:** {tz}\n"
        f"🌙 **Horario silencioso:** {quiet_start} - {quiet_end}\n\n"
        f"✨ Usa los botones para navegar",
        buttons=main_menu()
    )

# ===== MENÚ DE CANALES ORIGEN =====
@bot.on(events.NewMessage(pattern=r'^📺 Canal Origen$'))
@owner_only
async def source_channels_menu_handler(ev: events.NewMessage.Event):
    source_channels = state.get("source_channels", {})
    has_channel = len(source_channels) > 0
    auto_forward = "✅ Habilitado" if state.get("auto_forward_enabled", True) else "❌ Deshabilitado"
    
    if has_channel:
        channel_id, channel_data = next(iter(source_channels.items()))
        channel_name = channel_data.get("name", f"Canal {channel_id}")
        status_msg = f"📺 **Canal vinculado:** {channel_name}\n🆔 **ID:** `{channel_id}`"
    else:
        status_msg = "📺 **No hay canal vinculado**"
    
    await ev.reply(
        f"📺 **Gestión del Canal Origen**\n\n"
        f"{status_msg}\n"
        f"🔄 **Auto-reenvío:** {auto_forward}\n\n"
        f"Selecciona una opción:",
        buttons=source_channels_menu()
    )

@bot.on(events.NewMessage(pattern=r'^🔗 Vincular Origen$'))
@owner_only
async def link_source_channel(ev: events.NewMessage.Event):
    if not user.is_connected():
        await ev.reply(
            "❌ **No estás autenticado**\n\n"
            "🔑 Usa 'Iniciar Sesión' primero",
            buttons=source_channels_menu()
        )
        return
    
    # Verificar si ya hay un canal vinculado
    source_channels = state.get("source_channels", {})
    if source_channels:
        channel_id, channel_data = next(iter(source_channels.items()))
        channel_name = channel_data.get("name", f"Canal {channel_id}")
        await ev.reply(
            f"⚠️ **Ya tienes un canal vinculado**\n\n"
            f"📺 **Canal actual:** {channel_name}\n"
            f"🆔 **ID:** `{channel_id}`\n\n"
            f"💡 Usa 'Desvincular Canal' primero si quieres cambiar",
            buttons=source_channels_menu()
        )
        return
    
    user_flows[ev.sender_id] = {
        "action": "link_source_channel",
        "step": "channel_input"
    }
    
    await ev.reply(
        "🔗 **Vincular Canal Origen**\n\n"
        "📝 **Puedes vincular de 2 formas:**\n\n"
        "1️⃣ **Reenviar un mensaje** del canal que quieres vincular\n"
        "2️⃣ **Enviar enlace/ID** del canal:\n"
        "   • ID directo: `-1001234567890`\n"
        "   • Username: `@nombre_canal`\n"
        "   • Enlace: `https://t.me/nombre_canal`\n\n"
        "❌ Escribe /cancel para cancelar",
        buttons=ReplyKeyboardMarkup([
            KeyboardButtonRow([KeyboardButton("❌ Cancelar")])
        ], resize=True)
    )

@bot.on(events.NewMessage(pattern=r'^🗑️ Desvincular Canal$'))
@owner_only
async def unlink_source_channel(ev: events.NewMessage.Event):
    source_channels = state.get("source_channels", {})
    if not source_channels:
        await ev.reply(
            "📂 **No hay canal vinculado**\n\n"
            "🔗 Usa 'Vincular Origen' para configurar un canal",
            buttons=source_channels_menu()
        )
        return
    
    # Eliminar el canal vinculado
    channel_id, channel_data = next(iter(source_channels.items()))
    channel_name = channel_data.get("name", f"Canal {channel_id}")
    
    state["source_channels"] = {}
    save_state(state)
    
    await ev.reply(
        f"✅ **Canal desvinculado**\n\n"
        f"🗑️ **Canal:** {channel_name}\n"
        f"🆔 **ID:** `{channel_id}`\n\n"
        f"💡 El canal ya no se usará como origen",
        buttons=source_channels_menu()
    )

@bot.on(events.NewMessage(pattern=r'^⏯️ Toggle Auto-Reenvío$'))
@owner_only
async def toggle_auto_forward(ev: events.NewMessage.Event):
    current_state = state.get("auto_forward_enabled", True)
    new_state = not current_state
    
    state["auto_forward_enabled"] = new_state
    save_state(state)
    
    status = "✅ **Habilitado**" if new_state else "❌ **Deshabilitado**"
    action = "habilitado" if new_state else "deshabilitado"
    
    msg = f"⏯️ **Auto-reenvío {action}**\n\n"
    if new_state:
        msg += "🔄 Los mensajes del canal origen se reenviarán automáticamente a los grupos\n"
        msg += "💡 También se respetan las publicaciones programadas"
    else:
        msg += "⏸️ Solo se enviarán las publicaciones programadas\n"
        msg += "💡 Los mensajes nuevos en el canal no se reenviarán automáticamente"
    
    await ev.reply(msg, buttons=source_channels_menu())

# ===== MENÚ DE AUTENTICACIÓN (SIN LOGIN AUTOMÁTICO) =====
@bot.on(events.NewMessage(pattern=r'^🔐 Autenticación$'))
@owner_only
async def auth_menu_handler(ev: events.NewMessage.Event):
    if not user.is_connected():
        status = "❌ **Desconectado**"
    else:
        try:
            me = await user.get_me()
            status = f"✅ **Conectado** como @{getattr(me, 'username', '???')}"
        except:
            status = "⚠️ **Estado incierto**"

    await ev.reply(
        f"🔐 **Gestión de Autenticación**\n\n"
        f"👤 **Estado actual:** {status}\n\n"
        f"Selecciona una opción:",
        buttons=auth_menu()
    )

@bot.on(events.NewMessage(pattern=r'^🔑 Iniciar Sesión$'))
@owner_only
async def login_user_start(ev: events.NewMessage.Event):
    # Verificar si ya está autenticado DE VERDAD
    if user.is_connected():
        try:
            me = await user.get_me()
            if me:  # Si puede obtener info del usuario, está realmente conectado
                await ev.reply(
                    "✅ **Ya estás autenticado**\n\n"
                    f"🔒 Conectado como @{getattr(me, 'username', '???')}\n\n"
                    f"💡 Si quieres cambiar de cuenta, usa 'Cerrar Sesión' primero",
                    buttons=auth_menu()
                )
                return
        except Exception as e:
            # Si hay error obteniendo usuario, la sesión no es válida
            print(f"[DEBUG] Error al verificar sesión: {e}")
            try:
                await user.disconnect()
                await user.connect()
            except:
                pass
    
    # Limpiar cualquier flujo anterior
    user_flows.pop(ev.sender_id, None)
    
    # Iniciar nuevo flujo de login
    user_flows[ev.sender_id] = {
        "action": "login", 
        "step": "phone"
    }
    
    await ev.reply(
        "🔐 **Proceso de Autenticación**\n\n"
        "📞 **Paso 1:** Envíame tu número de teléfono\n"
        "💡 **Formato:** +código_país número\n"
        "📝 **Ejemplo:** +1234567890\n\n"
        "❌ Escribe /cancel para cancelar",
        buttons=ReplyKeyboardMarkup([
            KeyboardButtonRow([KeyboardButton("❌ Cancelar Login")])
        ], resize=True)
    )

@bot.on(events.NewMessage(pattern=r'^🚪 Cerrar Sesión$'))
@owner_only
async def logout_user(ev: events.NewMessage.Event):
    try:
        # Limpiar cualquier flujo activo
        user_flows.pop(ev.sender_id, None)
        
        # Cerrar sesión de usuario
        if user.is_connected():
            try:
                await user.log_out()
                print("[DEBUG] Sesión de usuario cerrada")
            except Exception as e:
                print(f"[DEBUG] Error en logout: {e}")
                # Forzar desconexión si el logout falla
                try:
                    await user.disconnect()
                except:
                    pass
        
        # Eliminar archivos de sesión si existen
        import os
        session_files = [f"{USER_SESSION}.session", f"{USER_SESSION}.session-journal"]
        for file in session_files:
            try:
                if os.path.exists(file):
                    os.remove(file)
                    print(f"[DEBUG] Eliminado: {file}")
            except:
                pass
        
        await ev.reply(
            "✅ **Sesión cerrada correctamente**\n\n"
            "🔒 Tu cuenta ha sido desconectada del sistema\n"
            "🗑️ Archivos de sesión eliminados\n\n"
            "💡 Ahora puedes iniciar sesión con otra cuenta",
            buttons=auth_menu()
        )
        
    except Exception as e:
        print(f"[ERROR] Error al cerrar sesión: {e}")
        await ev.reply(
            f"❌ **Error al cerrar sesión:** {e}\n\n"
            "🔄 Intenta nuevamente",
            buttons=auth_menu()
        )

@bot.on(events.NewMessage(pattern=r'^📱 Mis Grupos$'))
@owner_only
async def my_groups(ev: events.NewMessage.Event):
    if not user.is_connected():
        await ev.reply(
            "❌ **No estás autenticado**\n\n"
            "🔑 Usa 'Iniciar Sesión' primero",
            buttons=auth_menu()
        )
        return
    
    try:
        groups = await collect_all_groups(user)
        if not groups:
            await ev.reply(
                "📭 **No se encontraron grupos**\n\n"
                "ℹ️ Asegúrate de estar en algunos grupos/canales",
                buttons=auth_menu()
            )
            return
        
        msg = f"📱 **Tus Grupos/Canales** ({len(groups)} encontrados)\n\n"
        for i, gid in enumerate(groups[:10], 1):  # Mostrar solo los primeros 10
            try:
                entity = await user.get_entity(gid)
                name = getattr(entity, 'title', f'Grupo {gid}')
                msg += f"{i}. **{name}** (`{gid}`)\n"
            except:
                msg += f"{i}. Grupo `{gid}`\n"
        
        if len(groups) > 10:
            msg += f"\n... y {len(groups)-10} más"
        
        await ev.reply(msg, buttons=auth_menu())
        
    except Exception as e:
        await ev.reply(
            f"❌ **Error:** {e}",
            buttons=auth_menu()
        )

# ===== MENÚ DE LISTAS =====
@bot.on(events.NewMessage(pattern=r'^📋 Mis Listas$'))
@owner_only
async def lists_menu_handler(ev: events.NewMessage.Event):
    gl = state.get("group_lists", {})
    count = len(gl)
    
    await ev.reply(
        f"📋 **Gestión de Listas**\n\n"
        f"📊 **Total de listas:** {count}\n\n"
        f"Selecciona una opción:",
        buttons=lists_menu()
    )

@bot.on(events.NewMessage(pattern=r'^👀 Ver Listas$'))
@owner_only
async def view_lists(ev: events.NewMessage.Event):
    gl = state.get("group_lists", {})
    if not gl:
        await ev.reply(
            "📂 **No hay listas creadas**\n\n"
            "➕ Usa 'Nueva Lista' para crear tu primera lista",
            buttons=lists_menu()
        )
        return
    
    msg = "📋 **Tus Listas:**\n\n"
    for name, groups in gl.items():
        count = len(groups)
        emoji = "📁" if count > 0 else "📂"
        msg += f"{emoji} **{name}** — `{count} grupos`\n"
    
    await ev.reply(msg, buttons=lists_menu())

@bot.on(events.NewMessage(pattern=r'^➕ Nueva Lista$'))
@owner_only
async def new_list(ev: events.NewMessage.Event):
    user_flows[ev.sender_id] = {
        "action": "create_list",
        "step": "name"
    }
    
    await ev.reply(
        "➕ **Crear Nueva Lista**\n\n"
        "📝 **Paso 1:** Envíame el nombre para la nueva lista\n"
        "💡 Usa un nombre descriptivo\n"
        "📝 **Ejemplo:** MisGruposVIP\n\n"
        "❌ Escribe /cancel para cancelar",
        buttons=ReplyKeyboardMarkup([
            KeyboardButtonRow([KeyboardButton("❌ Cancelar")])
        ], resize=True)
    )

# ===== MENÚ DE PUBLICACIONES =====
@bot.on(events.NewMessage(pattern=r'^🚀 Publicaciones$'))
@owner_only
async def pubs_menu_handler(ev: events.NewMessage.Event):
    pubs = state.get("pubs", {})
    active = sum(1 for p in pubs.values() if p.get("enabled", True))
    total = len(pubs)
    
    await ev.reply(
        f"🚀 **Gestión de Publicaciones**\n\n"
        f"📊 **Publicaciones:** {active}/{total} activas\n\n"
        f"Selecciona una opción:",
        buttons=pubs_menu()
    )

@bot.on(events.NewMessage(pattern=r'^📊 Ver Publicaciones$'))
@owner_only
async def view_publications(ev: events.NewMessage.Event):
    pubs = state.get("pubs", {})
    if not pubs:
        await ev.reply(
            "📭 **No hay publicaciones creadas**\n\n"
            "✨ Usa 'Crear Nueva' para crear tu primera publicación",
            buttons=pubs_menu()
        )
        return
    
    msg = "🚀 **Tus Publicaciones:**\n\n"
    for name, cfg in pubs.items():
        enabled = cfg.get("enabled", True)
        emoji = "✅" if enabled else "⏸️"
        interval = cfg.get("interval_min", 30)
        target = cfg.get("target_list", "N/A")
        msg += f"{emoji} **{name}**\n"
        msg += f"   📊 Lista: {target}\n"
        msg += f"   ⏱️ Intervalo: {interval}min\n\n"
    
    await ev.reply(msg, buttons=pubs_menu())

@bot.on(events.NewMessage(pattern=r'^✨ Crear Nueva$'))
@owner_only
async def create_publication(ev: events.NewMessage.Event):
    if not user.is_connected():
        await ev.reply(
            "❌ **No estás autenticado**\n\n"
            "🔑 Usa 'Iniciar Sesión' primero",
            buttons=pubs_menu()
        )
        return
    
    user_flows[ev.sender_id] = {
        "action": "create_publication",
        "step": "name"
    }
    
    await ev.reply(
        "✨ **Crear Nueva Publicación**\n\n"
        "📝 **Paso 1:** Envíame un nombre para la publicación\n"
        "💡 Usa un nombre descriptivo\n"
        "📝 **Ejemplo:** AnunciosVIP\n\n"
        "❌ Escribe /cancel para cancelar",
        buttons=ReplyKeyboardMarkup([
            KeyboardButtonRow([KeyboardButton("❌ Cancelar")])
        ], resize=True)
    )

# ===== PUBLICACIONES POR HORARIO =====
@bot.on(events.NewMessage(pattern=r'^⏰ Crear por Horario$'))
@owner_only
async def create_scheduled_publication(ev: events.NewMessage.Event):
    if not user.is_connected():
        await ev.reply(
            "❌ **No estás autenticado**\n\n"
            "🔑 Usa 'Iniciar Sesión' primero",
            buttons=pubs_menu()
        )
        return
    
    user_flows[ev.sender_id] = {
        "action": "create_scheduled_pub",
        "step": "name"
    }
    
    await ev.reply(
        "⏰ **Crear Publicación por Horario**\n\n"
        "📝 **Paso 1:** Envíame un nombre para la publicación\n"
        "💡 Usa un nombre descriptivo\n"
        "📝 **Ejemplo:** NoticiasLunes\n\n"
        "❌ Escribe /cancel para cancelar",
        buttons=ReplyKeyboardMarkup([
            KeyboardButtonRow([KeyboardButton("❌ Cancelar")])
        ], resize=True)
    )

@bot.on(events.NewMessage(pattern=r'^📅 Ver Horarios$'))
@owner_only
async def view_scheduled_pubs(ev: events.NewMessage.Event):
    scheduled_pubs = state.get("scheduled_pubs", {})
    if not scheduled_pubs:
        await ev.reply(
            "📭 **No hay publicaciones programadas**\n\n"
            "⏰ Usa 'Crear por Horario' para crear tu primera publicación programada",
            buttons=pubs_menu()
        )
        return
    
    msg = "📅 **Tus Publicaciones Programadas:**\n\n"
    for name, cfg in scheduled_pubs.items():
        enabled = cfg.get("enabled", True)
        emoji = "✅" if enabled else "⏸️"
        schedule = cfg.get("schedule", {})
        schedule_type = schedule.get("type", "unknown")
        
        msg += f"{emoji} **{name}**\n"
        msg += f"   📊 Lista: {cfg.get('target_list', 'N/A')}\n"
        
        if schedule_type == "daily":
            hour = schedule.get("hour", 0)
            minute = schedule.get("minute", 0)
            msg += f"   ⏰ Horario: Todos los días a las {hour:02d}:{minute:02d}\n"
        elif schedule_type == "weekly":
            days = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
            day_name = days[schedule.get("day", 0)]
            hour = schedule.get("hour", 0)
            minute = schedule.get("minute", 0)
            msg += f"   ⏰ Horario: Todos los {day_name} a las {hour:02d}:{minute:02d}\n"
        elif schedule_type == "once":
            target_dt = dt.datetime.fromisoformat(schedule["datetime"])
            msg += f"   ⏰ Horario: Una vez el {target_dt.strftime('%d/%m/%Y %H:%M')}\n"
        elif schedule_type == "interval":
            minutes = schedule.get("minutes", 30)
            msg += f"   ⏰ Horario: Cada {minutes} minutos\n"
        
        content_type = cfg.get("content_type", "channel")
        if content_type == "text":
            msg += f"   📝 Tipo: Texto directo\n"
        elif content_type == "media":
            msg += f"   🖼️ Tipo: Imagen/Álbum\n"
        else:
            msg += f"   📺 Tipo: Desde canal\n"
        
        msg += "\n"
    
    await ev.reply(msg, buttons=pubs_menu())

# ===== CALLBACKS DE BOTONES INLINE =====
@bot.on(events.CallbackQuery(pattern=r'^select_group_(\d+)_(\d+)$'))
async def callback_select_group(ev: events.CallbackQuery.Event):
    user_id = ev.sender_id
    if user_id != OWNER_ID:
        await ev.answer("⛔ Acceso denegado")
        return
    
    flow = user_flows.get(user_id)
    if not flow:
        await ev.answer("❌ Sesión expirada")
        return
    
    group_id = int(ev.pattern_match.group(1))
    page = int(ev.pattern_match.group(2))
    
    selected_groups = flow.get("selected_groups", [])
    
    if group_id in selected_groups:
        selected_groups.remove(group_id)
        await ev.answer("❌ Grupo eliminado")
    else:
        selected_groups.append(group_id)
        await ev.answer("✅ Grupo agregado")
    
    flow["selected_groups"] = selected_groups
    
    await show_groups_pagination(ev, page, flow, edit=True)

@bot.on(events.CallbackQuery(pattern=r'^groups_page_(\d+)$'))
async def callback_groups_page(ev: events.CallbackQuery.Event):
    user_id = ev.sender_id
    if user_id != OWNER_ID:
        await ev.answer()
        return
    
    flow = user_flows.get(user_id)
    if not flow:
        await ev.answer("❌ Sesión expirada")
        return
    
    page = int(ev.pattern_match.group(1))
    await show_groups_pagination(ev, page, flow, edit=True)

@bot.on(events.CallbackQuery(pattern=r'^finish_group_selection$'))
async def callback_finish_selection(ev: events.CallbackQuery.Event):
    user_id = ev.sender_id
    if user_id != OWNER_ID:
        await ev.answer("⛔ Acceso denegado")
        return
    
    flow = user_flows.get(user_id)
    if not flow:
        await ev.answer("❌ Sesión expirada")
        return
    
    selected_groups = flow.get("selected_groups", [])
    
    if not selected_groups:
        await ev.answer("❌ Selecciona al menos un grupo")
        return
    
    list_name = flow.get("list_name")
    
    group_lists = state.get("group_lists", {})
    group_lists[list_name] = selected_groups
    state["group_lists"] = group_lists
    save_state(state)
    
    user_flows.pop(user_id, None)
    
    await ev.edit(
        f"✅ **Lista creada exitosamente**\n\n"
        f"📋 **Nombre:** {list_name}\n"
        f"📊 **Grupos:** {len(selected_groups)}\n\n"
        f"💡 Lista guardada correctamente",
        buttons=None
    )
    
    await bot.send_message(user_id, "Menú:", buttons=lists_menu())

async def show_groups_pagination(ev, page: int, flow: Dict, edit: bool = False):
    """Muestra grupos con paginación y selección múltiple"""
    groups = await collect_all_groups(user)
    
    if not groups:
        if edit:
            await ev.edit(
                "📭 **No se encontraron grupos**\n\n"
                "ℹ️ Asegúrate de estar en algunos grupos/canales"
            )
        else:
            await ev.reply(
                "📭 **No se encontraron grupos**\n\n"
                "ℹ️ Asegúrate de estar en algunos grupos/canales",
                buttons=lists_menu()
            )
        return
    
    selected_groups = flow.get("selected_groups", [])
    
    per_page = 8
    total_pages = (len(groups) + per_page - 1) // per_page
    page = max(0, min(page, total_pages - 1))
    
    start = page * per_page
    end = start + per_page
    page_groups = groups[start:end]
    
    buttons_list = []
    for gid in page_groups:
        try:
            entity = await user.get_entity(gid)
            name = getattr(entity, 'title', f'Grupo {gid}')
        except:
            name = f'Grupo {gid}'
        
        is_selected = gid in selected_groups
        emoji = "✅" if is_selected else "⬜"
        buttons_list.append([Button.inline(f"{emoji} {name[:30]}", data=f"select_group_{gid}_{page}")])
    
    nav_buttons = []
    if page > 0:
        nav_buttons.append(Button.inline("◀️ Anterior", data=f"groups_page_{page-1}"))
    if page < total_pages - 1:
        nav_buttons.append(Button.inline("Siguiente ▶️", data=f"groups_page_{page+1}"))
    
    if nav_buttons:
        buttons_list.append(nav_buttons)
    
    buttons_list.append([Button.inline("✅ Finalizar Selección", data="finish_group_selection")])
    
    msg = (
        f"📱 **Selecciona tus grupos** (Página {page+1}/{total_pages})\n\n"
        f"📊 Total: {len(groups)} grupos\n"
        f"✅ Seleccionados: {len(selected_groups)}\n\n"
        f"💡 Toca un grupo para seleccionar/deseleccionar"
    )
    
    if edit:
        await ev.edit(msg, buttons=buttons_list)
    else:
        await ev.reply(msg, buttons=buttons_list)

@bot.on(events.CallbackQuery(pattern=r'^delete_pub_(.+)$'))
async def callback_delete_pub(ev: events.CallbackQuery.Event):
    user_id = ev.sender_id
    if user_id != OWNER_ID:
        await ev.answer("⛔ Acceso denegado")
        return
    
    pub_name = ev.pattern_match.group(1).decode('utf-8')
    
    pubs = state.get("pubs", {})
    scheduled_pubs = state.get("scheduled_pubs", {})
    
    if pub_name in pubs:
        del pubs[name]
        state["pubs"] = pubs
        save_state(state)
        await ev.answer(f"✅ Publicación '{pub_name}' eliminada")
    elif pub_name in scheduled_pubs:
        del scheduled_pubs[pub_name]
        state["scheduled_pubs"] = scheduled_pubs
        save_state(state)
        await ev.answer(f"✅ Publicación '{pub_name}' eliminada")
    else:
        await ev.answer("❌ Publicación no encontrada")
        return
    
    await ev.edit(
        f"✅ **Publicación eliminada**\n\n"
        f"🗑️ **Nombre:** {pub_name}",
        buttons=None
    )
    
    await bot.send_message(user_id, "Menú:", buttons=pubs_menu())

@bot.on(events.CallbackQuery(pattern=r'^delete_list_(.+)$'))
async def callback_delete_list(ev: events.CallbackQuery.Event):
    user_id = ev.sender_id
    if user_id != OWNER_ID:
        await ev.answer("⛔ Acceso denegado")
        return
    
    list_name = ev.pattern_match.group(1).decode('utf-8')
    
    group_lists = state.get("group_lists", {})
    
    if list_name not in group_lists:
        await ev.answer("❌ Lista no encontrada")
        return
    
    del group_lists[list_name]
    state["group_lists"] = group_lists
    save_state(state)
    
    await ev.answer(f"✅ Lista '{list_name}' eliminada")
    
    await ev.edit(
        f"✅ **Lista eliminada**\n\n"
        f"🗑️ **Nombre:** {list_name}",
        buttons=None
    )
    
    await bot.send_message(user_id, "Menú:", buttons=lists_menu())

# ===== MENÚ DE CONFIGURACIÓN =====
@bot.on(events.NewMessage(pattern=r'^⚙️ Configuración$'))
@owner_only
async def config_menu_handler(ev: events.NewMessage.Event):
    tz = state.get("timezone", "UTC")
    quiet_start = state.get("quiet_start", "23:30")
    quiet_end = state.get("quiet_end", "07:00")
    
    await ev.reply(
        f"⚙️ **Configuración Actual**\n\n"
        f"🌍 **Zona horaria:** {tz}\n"
        f"🌙 **Horario silencioso:** {quiet_start} - {quiet_end}\n\n"
        f"Selecciona una opción:",
        buttons=config_menu()
    )

@bot.on(events.NewMessage(pattern=r'^🌙 Horario Silencioso$'))
@owner_only
async def quiet_hours_config(ev: events.NewMessage.Event):
    current_start = state.get("quiet_start", "23:30")
    current_end = state.get("quiet_end", "07:00")
    
    user_flows[ev.sender_id] = {
        "action": "config_quiet",
        "step": "hours"
    }
    
    await ev.reply(
        f"🌙 **Configurar Horario Silencioso**\n\n"
        f"⏰ **Actual:** {current_start} - {current_end}\n\n"
        f"📝 **Envía el nuevo horario en formato:**\n"
        f"HH:MM HH:MM\n\n"
        f"💡 **Ejemplo:** 23:30 07:00\n"
        f"(Desde las 23:30 hasta las 07:00)\n\n"
        f"❌ Escribe /cancel para cancelar",
        buttons=ReplyKeyboardMarkup([
            KeyboardButtonRow([KeyboardButton("❌ Cancelar")])
        ], resize=True)
    )

@bot.on(events.NewMessage(pattern=r'^🌍 Zona Horaria$'))
@owner_only
async def timezone_config(ev: events.NewMessage.Event):
    current_tz = state.get("timezone", "UTC")
    
    user_flows[ev.sender_id] = {
        "action": "config_timezone",
        "step": "timezone"
    }
    
    await ev.reply(
        f"🌍 **Configurar Zona Horaria**\n\n"
        f"🕐 **Actual:** {current_tz}\n\n"
        f"📝 **Envía la nueva zona horaria:**\n"
        f"💡 **Ejemplos válidos:**\n"
        f"• UTC\n"
        f"• America/Havana\n"
        f"• Europe/Madrid\n"
        f"• America/New_York\n\n"
        f"❌ Escribe /cancel para cancelar",
        buttons=ReplyKeyboardMarkup([
            KeyboardButtonRow([KeyboardButton("❌ Cancelar")])
        ], resize=True)
    )

# ===== COMANDOS BÁSICOS =====
@bot.on(events.NewMessage(pattern=r'^/ping$'))
@owner_only
async def ping_cmd(ev: events.NewMessage.Event):
    await ev.reply("🏓 **Pong!**\n\n✅ El bot está funcionando correctamente")

@bot.on(events.NewMessage(pattern=r'^❓ Ayuda$|^/help$'))
@owner_only
async def help_cmd(ev: events.NewMessage.Event):
    help_msg = (
        "❓ **Ayuda - Panel de Control**\n\n"
        
        "🔧 **Navegación:**\n"
        "• Usa los **botones** para navegar fácilmente\n"
        "• 🏠 **Menú Principal** — Volver al inicio\n\n"
        
        "📊 **Estado:**\n"
        "• Ver información completa del sistema\n"
        "• Estado de conexión actual\n"
        "• Resumen de publicaciones activas\n\n"
        
        "🔐 **Autenticación:**\n"
        "• **Iniciar Sesión** — Conectar tu cuenta de Telegram\n"
        "• **Mis Grupos** — Ver grupos/canales disponibles\n"
        "• **Cerrar Sesión** — Desconectar cuenta\n\n"
        
        "📺 **Canal Origen** (UN CANAL ÚNICO):\n"
        "• **Vincular Origen** — Conectar canal fuente\n"
        "• **Toggle Auto-Reenvío** — Control automático/manual\n"
        "• **Desvincular Canal** — Quitar canal actual\n\n"
        
        "🚀 **Publicaciones:**\n"
        "• **Ver Publicaciones** — Mostrar todas las configuradas\n"
        "• **Crear Nueva** — Asistente de creación completo\n"
        "• **Activar/Pausar** — Controlar publicaciones\n\n"
        
        "📋 **Listas:**\n"
        "• **Ver Listas** — Mostrar listas de grupos\n"
        "• **Nueva Lista** — Crear lista de grupos\n"
        "• **Agregar IDs** — Añadir grupos a listas\n\n"
        
        "💡 **Comandos de respaldo:** `/start`, `/help`, `/ping`\n"
        "🔧 **Funciones:** Un canal origen, vincular por reenvío o enlace"
    )
    
    await ev.reply(help_msg, buttons=main_menu())

# ===== FLUJO PRINCIPAL DE MENSAJES =====
@bot.on(events.NewMessage())
@owner_only
async def flow_handler(ev: events.NewMessage.Event):
    user_id = ev.sender_id
    text = (ev.raw_text or "").strip()
    
    # Verificar si el usuario tiene un flujo activo
    if user_id not in user_flows:
        return
        
    flow = user_flows[user_id]
    action = flow.get("action")
    step = flow.get("step")
    
    # Comandos de cancelación
    if text in ["/cancel", "❌ Cancelar", "🏠 Menú Principal", "❌ Cancelar Login"]:
        user_flows.pop(user_id, None)
        await ev.reply(
            "❌ **Operación cancelada**",
            buttons=main_menu()
        )
        return
    
    # === FLUJO DE LOGIN ===
    if action == "login":
        if step == "phone":
            # Validar formato del número
            if not text.startswith("+") or len(text) < 10 or not text[1:].replace("+", "").isdigit():
                await ev.reply(
                    "❌ **Formato incorrecto**\n\n"
                    "📞 El número debe comenzar con + y código de país\n"
                    "💡 Ejemplo: +1234567890\n"
                    "📝 Solo números después del +"
                )
                return
                
            try:
                # Conectar y enviar código
                if not user.is_connected():
                    await user.connect()
                
                await user.send_code_request(text)
                flow["step"] = "code"
                flow["phone"] = text
                
                await ev.reply(
                    f"📱 **Código enviado a {text}**\n\n"
                    "🔢 **Paso 2:** Envíame el código que recibiste\n"
                    "💡 Solo los números, sin espacios ni guiones\n"
                    "📝 Ejemplo: 12345",
                    buttons=ReplyKeyboardMarkup([
                        KeyboardButtonRow([KeyboardButton("❌ Cancelar Login")])
                    ], resize=True)
                )
                
            except Exception as e:
                user_flows.pop(user_id, None)
                await ev.reply(
                    f"❌ **Error enviando código:** {str(e)}\n\n"
                    "🔄 Intenta nuevamente",
                    buttons=auth_menu()
                )
                
        elif step == "code":
            if not text.isdigit():
                await ev.reply(
                    "❌ **Solo números**\n\n"
                    "🔢 Envía solo los números del código\n"
                    "💡 Ejemplo: 12345"
                )
                return
                
            try:
                phone = flow["phone"]
                await user.sign_in(phone, text)
                
                # Login exitoso
                user_flows.pop(user_id, None)
                me = await user.get_me()
                
                await ev.reply(
                    f"✅ **¡Autenticado exitosamente!**\n\n"
                    f"👤 **Conectado como:** @{getattr(me, 'username', '???')}\n"
                    f"🎉 Ya puedes usar todas las funciones",
                    buttons=main_menu()
                )
                
                # Iniciar publicaciones programadas
                asyncio.create_task(run_publications())
                
            except SessionPasswordNeededError:
                # Necesita 2FA
                flow["step"] = "2fa"
                await ev.reply(
                    "🔐 **Autenticación de dos factores requerida**\n\n"
                    "🔑 **Paso 3:** Envía tu contraseña de 2FA\n"
                    "💡 Es la contraseña que configuraste en Telegram",
                    buttons=ReplyKeyboardMarkup([
                        KeyboardButtonRow([KeyboardButton("❌ Cancelar Login")])
                    ], resize=True)
                )
                
            except (PhoneCodeInvalidError, PhoneCodeExpiredError):
                await ev.reply(
                    "❌ **Código incorrecto o expirado**\n\n"
                    "🔄 Intenta nuevamente desde el inicio",
                    buttons=auth_menu()
                )
                user_flows.pop(user_id, None)
                
            except Exception as e:
                user_flows.pop(user_id, None)
                await ev.reply(
                    f"❌ **Error:** {str(e)}\n\n"
                    "🔄 Intenta nuevamente",
                    buttons=auth_menu()
                )
                
        elif step == "2fa":
            try:
                await user.sign_in(password=text)
                
                # Login exitoso con 2FA
                user_flows.pop(user_id, None)
                me = await user.get_me()
                
                await ev.reply(
                    f"✅ **¡Autenticado exitosamente!**\n\n"
                    f"👤 **Conectado como:** @{getattr(me, 'username', '???')}\n"
                    f"🔐 2FA verificado correctamente\n"
                    f"🎉 Ya puedes usar todas las funciones",
                    buttons=main_menu()
                )
                
                # Iniciar publicaciones programadas
                asyncio.create_task(run_publications())
                
            except PasswordHashInvalidError:
                await ev.reply(
                    "❌ **Contraseña 2FA incorrecta**\n\n"
                    "🔄 Intenta nuevamente"
                )
                
            except Exception as e:
                user_flows.pop(user_id, None)
                await ev.reply(
                    f"❌ **Error:** {str(e)}\n\n"
                    "🔄 Intenta nuevamente",
                    buttons=auth_menu()
                )
    
    # === FLUJO DE CREAR LISTA ===
    elif action == "create_list" and step == "name":
        if len(text) > 50 or not text.replace('_', '').replace('-', '').isalnum():
            await ev.reply(
                "❌ **Nombre inválido**\n\n"
                "💡 Usa solo letras, números, _ y -\n"
                "📏 Máximo 50 caracteres"
            )
            return
        
        # Verificar si ya existe
        group_lists = state.get("group_lists", {})
        if text in group_lists:
            await ev.reply(
                f"❌ **La lista '{text}' ya existe**\n\n"
                "💡 Usa un nombre diferente"
            )
            return
        
        # Guardar nombre y mostrar selección de grupos
        flow["list_name"] = text
        flow["step"] = "select_groups"
        flow["selected_groups"] = []
        
        if not user.is_connected():
            await ev.reply(
                "❌ **No estás autenticado**\n\n"
                "🔑 Usa 'Iniciar Sesión' primero",
                buttons=lists_menu()
            )
            user_flows.pop(user_id, None)
            return
        
        await ev.reply(
            f"📋 **Lista: {text}**\n\n"
            f"📱 **Paso 2:** Selecciona los grupos para tu lista\n\n"
            f"💡 Se mostrarán todos tus grupos disponibles",
            buttons=ReplyKeyboardMarkup([
                KeyboardButtonRow([KeyboardButton("❌ Cancelar")])
            ], resize=True)
        )
        
        # Mostrar paginación de grupos
        await show_groups_pagination(ev, 0, flow)
    
    # === FLUJO DE CONFIGURAR QUIET HOURS ===
    elif action == "config_quiet" and step == "hours":
        try:
            parts = text.split()
            if len(parts) != 2:
                raise ValueError("Formato incorrecto")
            
            start_time, end_time = parts
            # Validar formato HH:MM
            dt.datetime.strptime(start_time, "%H:%M")
            dt.datetime.strptime(end_time, "%H:%M")
            
            state["quiet_start"] = start_time
            state["quiet_end"] = end_time
            save_state(state)
            
            user_flows.pop(user_id, None)
            await ev.reply(
                f"✅ **Horario silencioso actualizado**\n\n"
                f"🌙 **Nuevo horario:** {start_time} - {end_time}\n\n"
                f"💡 Durante este horario no se enviarán publicaciones",
                buttons=config_menu()
            )
            
        except ValueError:
            await ev.reply(
                "❌ **Formato incorrecto**\n\n"
                "💡 Usa el formato: HH:MM HH:MM\n"
                "📝 Ejemplo: 23:30 07:00"
            )
    
    # === FLUJO DE CONFIGURAR TIMEZONE ===
    elif action == "config_timezone" and step == "timezone":
        try:
            if ZoneInfo:
                # Verificar que la zona horaria sea válida
                test_tz = ZoneInfo(text)
                state["timezone"] = text
            else:
                state["timezone"] = text
            
            save_state(state)
            
            user_flows.pop(user_id, None)
            await ev.reply(
                f"✅ **Zona horaria actualizada**\n\n"
                f"🌍 **Nueva zona:** {text}\n\n"
                f"💡 Los horarios ahora se mostrarán en esta zona",
                buttons=config_menu()
            )
            
        except Exception:
            await ev.reply(
                "❌ **Zona horaria inválida**\n\n"
                "💡 Usa formatos como:\n"
                "• UTC\n"
                "• America/Havana\n"
                "• Europe/Madrid"
            )
    
    # === FLUJO DE VINCULAR CANAL ORIGEN ===
    elif action == "link_source_channel" and step == "channel_input":
        # Verificar si es un mensaje reenviado
        if hasattr(ev.message, 'fwd_from') and ev.message.fwd_from:
            try:
                # Obtener información del mensaje reenviado
                fwd_from = ev.message.fwd_from
                
                # Obtener el chat/canal de origen
                if hasattr(fwd_from, 'from_id') and fwd_from.from_id:
                    if hasattr(fwd_from.from_id, 'channel_id'):
                        channel_id = int(f"-100{fwd_from.from_id.channel_id}")
                    elif hasattr(fwd_from.from_id, 'chat_id'):
                        channel_id = -fwd_from.from_id.chat_id
                    else:
                        raise ValueError("No se pudo obtener ID del canal")
                else:
                    raise ValueError("Mensaje reenviado sin información de origen")
                
                # Obtener información del canal
                try:
                    channel_entity = await user.get_entity(channel_id)
                    channel_title = getattr(channel_entity, 'title', f'Canal {channel_id}')
                except:
                    channel_title = f'Canal {channel_id}'
                
                # Guardar como canal único (reemplazar cualquier existente)
                state["source_channels"] = {
                    str(channel_id): {
                        "name": channel_title,
                        "added_date": tznow().isoformat(),
                        "last_changed": tznow().isoformat()
                    }
                }
                save_state(state)
                
                user_flows.pop(user_id, None)
                await ev.reply(
                    f"✅ **Canal vinculado exitosamente**\n\n"
                    f"📺 **Nombre:** {channel_title}\n"
                    f"🆔 **ID:** `{channel_id}`\n"
                    f"📅 **Fecha:** {tznow().strftime('%d/%m/%Y %H:%M')}\n\n"
                    f"🎉 El canal está listo para usar",
                    buttons=source_channels_menu()
                )
                return
                
            except Exception as e:
                await ev.reply(
                    f"❌ **Error al procesar mensaje reenviado**\n\n"
                    f"**Error:** {str(e)}\n\n"
                    f"💡 Intenta reenviar un mensaje del canal o usa un enlace/ID"
                )
                return
        
        # Si no es mensaje reenviado, procesar como enlace/ID
        try:
            channel_entity = None
            channel_id = None
            
            # Si es un ID numérico
            if text.lstrip('-').isdigit():
                channel_id = int(text)
                try:
                    channel_entity = await user.get_entity(channel_id)
                except Exception as e:
                    await ev.reply(
                        f"❌ **No se pudo acceder al canal**\n\n"
                        f"**Error:** Could not find the input entity - Canal no encontrado\n\n"
                        f"📝 Verifica que:\n"
                        f"• El ID sea correcto: `{channel_id}`\n"
                        f"• Tengas acceso al canal\n"
                        f"• El canal exista y esté activo",
                        buttons=source_channels_menu()
                    )
                    user_flows.pop(user_id, None)
                    return
            # Si es username o enlace
            elif text.startswith('@') or 'https://t.me/' in text:
                username = text.replace('@', '').replace('https://t.me/', '')
                try:
                    channel_entity = await user.get_entity(username)
                    channel_id = channel_entity.id
                except Exception as e:
                    await ev.reply(
                        f"❌ **No se pudo acceder al canal**\n\n"
                        f"**Error:** {str(e)}\n\n"
                        f"📝 Verifica que:\n"
                        f"• El username/enlace sea correcto: `{username}`\n"
                        f"• Tengas acceso al canal\n"
                        f"• El canal exista y sea público",
                        buttons=source_channels_menu()
                    )
                    user_flows.pop(user_id, None)
                    return
            else:
                await ev.reply(
                    "❌ **Formato inválido**\n\n"
                    "💡 Puedes:\n"
                    "1️⃣ **Reenviar** un mensaje del canal\n"
                    "2️⃣ **Enviar** un enlace/ID:\n"
                    "   • `-1001234567890`\n"
                    "   • `@nombre_canal`\n"
                    "   • `https://t.me/nombre_canal`"
                )
                return
            
            # Obtener información del canal
            channel_title = getattr(channel_entity, 'title', f'Canal {channel_id}')
            
            # Guardar como canal único (reemplazar cualquier existente)
            state["source_channels"] = {
                str(channel_id): {
                    "name": channel_title,
                    "added_date": tznow().isoformat(),
                    "last_changed": tznow().isoformat()
                }
            }
            save_state(state)
            
            user_flows.pop(user_id, None)
            await ev.reply(
                f"✅ **Canal vinculado exitosamente**\n\n"
                f"📺 **Nombre:** {channel_title}\n"
                f"🆔 **ID:** `{channel_id}`\n"
                f"📅 **Fecha:** {tznow().strftime('%d/%m/%Y %H:%M')}\n\n"
                f"🎉 El canal está listo para usar",
                buttons=source_channels_menu()
            )
            
        except Exception as e:
            print(f"Error en link_source_channel: {e}")
            await ev.reply(
                f"❌ **Error inesperado**\n\n"
                f"Por favor intenta nuevamente o contacta soporte",
                buttons=source_channels_menu()
            )
            user_flows.pop(user_id, None)
    
    # === FLUJO DE CREAR PUBLICACIÓN POR HORARIO ===
    elif action == "create_scheduled_pub":
        if step == "name":
            # Validar nombre
            if len(text) > 50 or not text.replace('_', '').replace('-', '').isalnum():
                await ev.reply(
                    "❌ **Nombre inválido**\n\n"
                    "💡 Usa solo letras, números, _ y -\n"
                    "📏 Máximo 50 caracteres"
                )
                return
            
            scheduled_pubs = state.get("scheduled_pubs", {})
            if text in scheduled_pubs:
                await ev.reply(
                    f"❌ **La publicación '{text}' ya existe**\n\n"
                    "💡 Usa un nombre diferente"
                )
                return
            
            flow["pub_name"] = text
            flow["step"] = "schedule"
            
            await ev.reply(
                f"⏰ **Publicación: {text}**\n\n"
                f"📅 **Paso 2:** Envía el horario en lenguaje natural\n\n"
                f"✨ **Ejemplos:**\n"
                f"• \"todos los lunes a las 7\"\n"
                f"• \"hoy a las 8\"\n"
                f"• \"mañana a las 9\"\n"
                f"• \"todos los días a las 11\"\n"
                f"• \"cada 30 minutos\"\n\n"
                f"💡 También puedes usar:\n"
                f"• \"todos los martes a las 14:30\"\n"
                f"• \"cada viernes a las 20\"\n\n"
                f"❌ Escribe /cancel para cancelar"
            )
        
        elif step == "schedule":
            # Parsear horario natural
            schedule = parse_natural_schedule(text)
            
            if not schedule:
                await ev.reply(
                    "❌ **No entendí el horario**\n\n"
                    "📅 Intenta con estos formatos:\n"
                    "• \"todos los días a las 11\"\n"
                    "• \"todos los lunes a las 7\"\n"
                    "• \"hoy a las 8\"\n"
                    "• \"mañana a las 9\"\n"
                    "• \"cada 30 minutos\"\n\n"
                    "💡 Asegúrate de incluir la hora"
                )
                return
            
            flow["schedule"] = schedule
            flow["step"] = "target_list"
            
            # Mostrar interpretación del horario
            schedule_type = schedule.get("type")
            if schedule_type == "daily":
                hour = schedule.get("hour", 0)
                minute = schedule.get("minute", 0)
                schedule_desc = f"Todos los días a las {hour:02d}:{minute:02d}"
            elif schedule_type == "weekly":
                days = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
                day_name = days[schedule.get("day", 0)]
                hour = schedule.get("hour", 0)
                minute = schedule.get("minute", 0)
                schedule_desc = f"Todos los {day_name} a las {hour:02d}:{minute:02d}"
            elif schedule_type == "once":
                target_dt = dt.datetime.fromisoformat(schedule["datetime"])
                schedule_desc = f"Una vez el {target_dt.strftime('%d/%m/%Y %H:%M')}"
            else:
                minutes = schedule.get("minutes", 30)
                schedule_desc = f"Cada {minutes} minutos"
            
            # Mostrar listas disponibles
            group_lists = state.get("group_lists", {})
            if not group_lists:
                await ev.reply(
                    "❌ **No hay listas creadas**\n\n"
                    "📋 Primero crea una lista de grupos",
                    buttons=pubs_menu()
                )
                user_flows.pop(user_id, None)
                return
            
            lists_msg = f"✅ **Horario:** {schedule_desc}\n\n"
            lists_msg += f"📋 **Paso 3:** Selecciona la lista de destino\n\n"
            lists_msg += "**Listas disponibles:**\n"
            for list_name in group_lists.keys():
                lists_msg += f"• {list_name}\n"
            lists_msg += "\n📝 Envía el nombre exacto de la lista\n"
            lists_msg += "💡 También puedes escribir 'TODOS' para usar todos tus grupos"
            
            await ev.reply(lists_msg)
        
        elif step == "target_list":
            group_lists = state.get("group_lists", {})
            
            if text != "TODOS" and text not in group_lists:
                await ev.reply(
                    f"❌ **Lista '{text}' no encontrada**\n\n"
                    f"📋 Listas disponibles:\n" + "\n".join(f"• {name}" for name in group_lists.keys())
                )
                return
            
            flow["target_list"] = text
            flow["step"] = "content_type"
            
            await ev.reply(
                f"📊 **Lista:** {text}\n\n"
                f"📝 **Paso 4:** ¿Qué tipo de contenido enviarás?\n\n"
                f"**Opciones:**\n"
                f"1️⃣ **texto** — Texto directo que escribirás\n"
                f"2️⃣ **canal** — Mensaje de un canal (reenvío/enlace)\n"
                f"3️⃣ **imagenes** — Fotos/álbumes que enviarás\n\n"
                f"💡 Envía: texto, canal o imagenes"
            )
        
        elif step == "content_type":
            text_lower = text.lower()
            
            if text_lower not in ["texto", "canal", "imagenes", "imágenes"]:
                await ev.reply(
                    "❌ **Opción inválida**\n\n"
                    "💡 Envía: texto, canal o imagenes"
                )
                return
            
            if text_lower == "texto":
                flow["content_type"] = "text"
                flow["step"] = "text_content"
                
                await ev.reply(
                    "📝 **Paso 5:** Envía el texto que quieres publicar\n\n"
                    "💡 Puedes usar formato Markdown\n"
                    "📝 El texto se enviará tal cual lo escribas"
                )
            
            elif text_lower == "canal":
                flow["content_type"] = "channel"
                flow["step"] = "channel_source"
                
                await ev.reply(
                    "📺 **Paso 5:** Envía la referencia del mensaje\n\n"
                    "**Opciones:**\n"
                    "1️⃣ **Reenviar** el mensaje del canal\n"
                    "2️⃣ **Link**: https://t.me/c/123456/789\n"
                    "3️⃣ **IDs**: -1001234567890 123\n\n"
                    "💡 Formato IDs: <chat_id> <msg_id>"
                )
            
            else:  # imagenes
                flow["content_type"] = "media"
                flow["step"] = "media_content"
                flow["media_ids"] = []
                
                await ev.reply(
                    "🖼️ **Paso 5:** Envía las imágenes\n\n"
                    "💡 Puedes enviar:\n"
                    "• Una imagen\n"
                    "• Varias imágenes (una por una)\n"
                    "• Un álbum\n\n"
                    "✅ Cuando termines, escribe: listo"
                )
        
        elif step == "text_content":
            flow["text_content"] = text
            flow["step"] = "delay"
            
            await ev.reply(
                f"✅ **Texto guardado** ({len(text)} caracteres)\n\n"
                f"⏱️ **Paso 6:** Delay entre envíos (segundos)\n\n"
                f"💡 Envía un número entre 1 y 30\n"
                f"📝 Recomendado: 2-5 segundos\n"
                f"🔧 Default: 2.0"
            )
        
        elif step == "channel_source":
            # Verificar si es mensaje reenviado
            if hasattr(ev.message, 'fwd_from') and ev.message.fwd_from:
                try:
                    fwd_from = ev.message.fwd_from
                    
                    if hasattr(fwd_from, 'from_id') and fwd_from.from_id:
                        if hasattr(fwd_from.from_id, 'channel_id'):
                            channel_id = int(f"-100{fwd_from.from_id.channel_id}")
                        elif hasattr(fwd_from.from_id, 'chat_id'):
                            channel_id = -fwd_from.from_id.chat_id
                        else:
                            raise ValueError("No se pudo obtener ID del canal")
                    else:
                        raise ValueError("Mensaje reenviado sin información de origen")
                    
                    msg_id = ev.message.fwd_from.channel_post
                    
                    flow["source_chat_id"] = channel_id
                    flow["source_msg_id"] = msg_id
                    flow["step"] = "delay"
                    
                    await ev.reply(
                        f"✅ **Mensaje del canal guardado**\n\n"
                        f"📺 Canal: `{channel_id}`\n"
                        f"📨 Mensaje: `{msg_id}`\n\n"
                        f"⏱️ **Paso 6:** Delay entre envíos (segundos)\n\n"
                        f"💡 Envía un número entre 1 y 30\n"
                        f"🔧 Default: 2.0"
                    )
                    return
                    
                except Exception as e:
                    await ev.reply(
                        f"❌ **Error al procesar mensaje reenviado**\n\n"
                        f"💡 Intenta con un link o IDs directos"
                    )
                    return
            
            # Parsear referencia manual
            ref = parse_source_ref(text)
            if not ref:
                await ev.reply(
                    "❌ **Formato inválido**\n\n"
                    "💡 Usa:\n"
                    "• Link: https://t.me/c/123456/789\n"
                    "• IDs: -1001234567890 123"
                )
                return
            
            flow["source_chat_id"], flow["source_msg_id"] = ref
            flow["step"] = "delay"
            
            await ev.reply(
                f"✅ **Referencia guardada**\n\n"
                f"📺 Chat: `{ref[0]}`\n"
                f"📨 Mensaje: `{ref[1]}`\n\n"
                f"⏱️ **Paso 6:** Delay entre envíos (segundos)\n\n"
                f"💡 Envía un número entre 1 y 30\n"
                f"🔧 Default: 2.0"
            )
        
        elif step == "media_content":
            # Verificar si es "listo"
            if text.lower() == "listo":
                media_ids = flow.get("media_ids", [])
                if not media_ids:
                    await ev.reply(
                        "❌ **No has enviado ninguna imagen**\n\n"
                        "🖼️ Envía al menos una imagen"
                    )
                    return
                
                flow["step"] = "delay"
                
                await ev.reply(
                    f"✅ **{len(media_ids)} imagen(es) guardada(s)**\n\n"
                    f"⏱️ **Paso 6:** Delay entre envíos (segundos)\n\n"
                    f"💡 Envía un número entre 1 y 30\n"
                    f"🔧 Default: 2.0"
                )
                return
            
            # Verificar si es imagen
            if ev.message.media:
                # Guardar el ID del mensaje para después
                media_ids = flow.get("media_ids", [])
                media_ids.append(ev.message.id)
                flow["media_ids"] = media_ids
                
                await ev.answer(
                    f"✅ Imagen {len(media_ids)} guardada\n"
                    f"🖼️ Envía más imágenes o escribe: listo"
                )
            else:
                await ev.reply(
                    "❌ **Debes enviar una imagen**\n\n"
                    "🖼️ Envía fotos o escribe: listo"
                )
        
        elif step == "delay":
            try:
                delay = float(text)
                if not 1 <= delay <= 30:
                    raise ValueError()
            except:
                await ev.reply(
                    "❌ **Valor inválido**\n\n"
                    "💡 Envía un número entre 1 y 30\n"
                    "📝 Ejemplo: 2.5"
                )
                return
            
            # Guardar todo
            pub_name = flow["pub_name"]
            schedule = flow["schedule"]
            target_list = flow["target_list"]
            content_type = flow["content_type"]
            
            scheduled_pubs = state.get("scheduled_pubs", {})
            pub_config = {
                "enabled": True,
                "schedule": schedule,
                "target_list": target_list,
                "content_type": content_type,
                "delay_base": delay
            }
            
            if content_type == "text":
                pub_config["text_content"] = flow["text_content"]
            elif content_type == "media":
                pub_config["media_ids"] = flow["media_ids"]
            else:
                pub_config["source_chat_id"] = flow["source_chat_id"]
                pub_config["source_msg_id"] = flow["source_msg_id"]
            
            scheduled_pubs[pub_name] = pub_config
            state["scheduled_pubs"] = scheduled_pubs
            save_state(state)
            
            user_flows.pop(user_id, None)
            
            # Crear resumen
            schedule_type = schedule.get("type")
            if schedule_type == "daily":
                hour = schedule.get("hour", 0)
                minute = schedule.get("minute", 0)
                schedule_desc = f"Todos los días a las {hour:02d}:{minute:02d}"
            elif schedule_type == "weekly":
                days = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
                day_name = days[schedule.get("day", 0)]
                hour = schedule.get("hour", 0)
                minute = schedule.get("minute", 0)
                schedule_desc = f"Todos los {day_name} a las {hour:02d}:{minute:02d}"
            elif schedule_type == "once":
                target_dt = dt.datetime.fromisoformat(schedule["datetime"])
                schedule_desc = f"Una vez el {target_dt.strftime('%d/%m/%Y %H:%M')}"
            else:
                minutes = schedule.get("minutes", 30)
                schedule_desc = f"Cada {minutes} minutos"
            
            content_desc = {
                "text": "Texto directo",
                "media": f"{len(flow.get('media_ids', []))} imagen(es)",
                "channel": "Desde canal"
            }.get(content_type, "")
            
            await ev.reply(
                f"✅ **¡Publicación programada creada!**\n\n"
                f"📋 **Nombre:** {pub_name}\n"
                f"⏰ **Horario:** {schedule_desc}\n"
                f"📊 **Lista:** {target_list}\n"
                f"📝 **Contenido:** {content_desc}\n"
                f"⏱️ **Delay:** {delay}s\n\n"
                f"🎉 La publicación se ejecutará automáticamente",
                buttons=pubs_menu()
            )

# ===== EVENTOS DE AUTO-FORWARD DESDE CANAL ORIGEN =====
@user.on(events.NewMessage())
async def auto_forward_handler(ev: events.NewMessage.Event):
    """
    Maneja el reenvío automático desde el canal origen configurado
    """
    try:
        # Solo procesar si el auto-forward está habilitado
        if not state.get("auto_forward_enabled", True):
            return
        
        # Verificar si es del canal origen configurado
        source_channels = state.get("source_channels", {})
        if not source_channels or str(ev.chat_id) not in source_channels:
            return
        
        # Respetar quiet hours
        now = tznow()
        if in_quiet_hours(now.time()):
            return
        
        # Obtener todos los grupos destino
        all_targets = []
        group_lists = state.get("group_lists", {})
        for group_list in group_lists.values():
            all_targets.extend(group_list)
        
        # Eliminar duplicados
        all_targets = list(set(all_targets))
        
        if not all_targets:
            return
        
        # Reenviar con delay aleatorio
        random.shuffle(all_targets)
        for target_id in all_targets:
            try:
                await copy_as_user(user, ev.message, target_id)
                await asyncio.sleep(1 + random.random())  # Delay entre envíos
            except Exception as e:
                print(f"[auto_forward_error] {target_id}: {e}")
        
        print(f"[auto_forward] Mensaje de {ev.chat_id} reenviado a {len(all_targets)} grupos")
        
    except Exception as e:
        print(f"[auto_forward_handler_error] {e}")

# ===== SCHEDULER PARA PUBLICACIONES POR HORARIO =====
async def run_scheduled_publications():
    """
    Scheduler que ejecuta publicaciones programadas según su horario
    """
    print("DBG: scheduled publications loop start")
    while True:
        try:
            now = tznow()
            if in_quiet_hours(now.time()):
                await asyncio.sleep(10)
                continue

            scheduled_pubs = state.get("scheduled_pubs", {})
            for name, cfg in scheduled_pubs.items():
                if not cfg.get("enabled", True):
                    continue
                
                schedule = cfg.get("schedule", {})
                last_run = state.get("last_scheduled_runs", {}).get(name)
                
                # Verificar si debe ejecutarse
                if not should_run_scheduled(schedule, last_run):
                    continue
                
                # Obtener destinos
                target_list = cfg.get("target_list")
                if target_list == "TODOS":
                    targets = await collect_all_groups(user)
                else:
                    targets = state.get("group_lists", {}).get(target_list, [])
                
                if not targets:
                    continue
                
                content_type = cfg.get("content_type", "channel")
                
                try:
                    random.shuffle(targets)
                    delay_base = float(cfg.get("delay_base", 2.0))
                    
                    if content_type == "text":
                        # Texto directo
                        text_content = cfg.get("text_content", "")
                        for target_id in targets:
                            try:
                                target = await resolve_entity_safely(user, target_id)
                                await user.send_message(target, text_content, link_preview=False)
                                await asyncio.sleep(delay_base + random.random())
                            except Exception as e:
                                print(f"[send_text_error] {target_id}: {e}")
                    
                    elif content_type == "media":
                        # Imágenes/álbumes almacenados
                        media_ids = cfg.get("media_ids", [])
                        if media_ids:
                            # Obtener mensajes de media
                            media_msgs = []
                            for mid in media_ids:
                                try:
                                    msg = await bot.get_messages(OWNER_ID, ids=mid)
                                    if msg:
                                        media_msgs.append(msg)
                                except:
                                    pass
                            
                            # Enviar a cada destino
                            for target_id in targets:
                                try:
                                    target = await resolve_entity_safely(user, target_id)
                                    for msg in media_msgs:
                                        await copy_as_user(user, msg, target_id)
                                        await asyncio.sleep(0.5)
                                    await asyncio.sleep(delay_base + random.random())
                                except Exception as e:
                                    print(f"[send_media_error] {target_id}: {e}")
                    
                    else:
                        # Desde canal (como antes)
                        src_chat = int(cfg["source_chat_id"])
                        src_msg  = int(cfg["source_msg_id"])
                        
                        orig = await get_message_safely(user, src_chat, src_msg)
                        if not orig:
                            print(f"[ERROR] No se pudo obtener mensaje para publicación programada {name}")
                            continue
                        
                        if hasattr(orig, '__len__') and not isinstance(orig, str) and len(orig) > 0:
                            orig = orig[0]
                        
                        for target_id in targets:
                            try:
                                await copy_as_user(user, orig, target_id)
                                await asyncio.sleep(delay_base + random.random())
                            except FloodWaitError as fw:
                                print(f"[flood] {target_id}: wait {fw.seconds}s")
                                await asyncio.sleep(fw.seconds + 2)
                            except Exception as e:
                                print(f"[send_error] {target_id}: {e}")
                    
                    # Marcar última ejecución
                    state.setdefault("last_scheduled_runs", {})[name] = tznow().isoformat()
                    save_state(state)
                    
                    print(f"[scheduled_pub] {name} ejecutado a {len(targets)} grupos")
                
                except Exception as e:
                    print(f"[scheduled_pub_error] {name}: {e}")
            
            await asyncio.sleep(5)
        except Exception as e:
            print("[scheduled_scheduler_error]", e)
            await asyncio.sleep(5)

# ===== INICIALIZACIÓN Y MAIN =====
async def main():
    try:
        print("🤖 Iniciando bot...")
        
        # Conectar clientes
        await bot.start(bot_token=BOT_TOKEN)
        if not user.is_connected():
            await user.connect()
        
        print("✅ Bot conectado")
        print(f"📊 Publicaciones: {len(state.get('pubs', {}))}")
        print(f"⏰ Publicaciones programadas: {len(state.get('scheduled_pubs', {}))}")
        has_channel = "Sí" if state.get('source_channels', {}) else "No"
        print(f"📺 Canal origen: {has_channel}")
        print(f"📋 Listas: {len(state.get('group_lists', {}))}")
        
        # Iniciar schedulers de publicaciones
        asyncio.create_task(run_publications())
        asyncio.create_task(run_scheduled_publications())
        
        print("🚀 Sistema iniciado - Escuchando mensajes...")
        await bot.run_until_disconnected()
        
    except Exception as e:
        print(f"Error en main: {e}")
    finally:
        if user.is_connected():
            await user.disconnect()

if __name__ == "__main__":
    asyncio.run(main())
